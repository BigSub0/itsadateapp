import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { io, Socket } from 'socket.io-client';
import { Deal } from '@/lib/dating-api';

// Define the types for socket events
export interface MatchFoundEvent {
  matchedUser: string;
  score: number;
  deals: Deal[];
}

// Define the context type
interface DatingSocketContextType {
  isConnected: boolean;
  matchEvents: MatchFoundEvent[];
}

// Create context with default values
const DatingSocketContext = createContext<DatingSocketContextType>({
  isConnected: false,
  matchEvents: [],
});

// Props for the context provider
interface DatingSocketProviderProps {
  children: ReactNode;
  userId?: string;
}

export const DatingSocketProvider: React.FC<DatingSocketProviderProps> = ({ children, userId }) => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [matchEvents, setMatchEvents] = useState<MatchFoundEvent[]>([]);

  // Connect to socket when component mounts
  useEffect(() => {
    // Don't connect if no userId (user not logged in)
    if (!userId) return;

    // Create socket connection
    const newSocket = io('http://localhost:3000', {
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      autoConnect: true,
      query: { userId },
    });

    // Setup event listeners
    newSocket.on('connect', () => {
      console.log('Connected to It\'s A Date server');
      setIsConnected(true);
    });

    newSocket.on('disconnect', (reason) => {
      console.log('Disconnected from It\'s A Date server:', reason);
      setIsConnected(false);
    });

    newSocket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });

    // Listen for match events
    newSocket.on('matchFound', (matchEvent: MatchFoundEvent) => {
      console.log('Match found:', matchEvent);
      setMatchEvents(prev => [...prev, matchEvent]);
    });

    // Save socket instance
    setSocket(newSocket);

    // Cleanup function
    return () => {
      newSocket.disconnect();
      setSocket(null);
    };
  }, [userId]);

  return (
    <DatingSocketContext.Provider value={{ isConnected, matchEvents }}>
      {children}
    </DatingSocketContext.Provider>
  );
};

// Custom hook to use the socket context
export const useDatingSocket = () => useContext(DatingSocketContext);