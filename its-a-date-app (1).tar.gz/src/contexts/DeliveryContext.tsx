import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { deliveryStorage, Restaurant, MenuItem, CartItem, Order } from '@/lib/delivery/localStorage';
import { useToast } from '@/components/ui/use-toast';

interface DeliveryContextType {
  // Cart state and methods
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  updateCartItem: (index: number, item: CartItem) => void;
  removeFromCart: (index: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartSubtotal: number;
  cartTax: number;
  cartDeliveryFee: number;
  
  // Orders state and methods
  orders: Order[];
  addOrder: (order: Order) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  
  // Favorites state and methods
  favorites: string[];
  addToFavorites: (restaurantId: string) => void;
  removeFromFavorites: (restaurantId: string) => void;
  isFavorite: (restaurantId: string) => boolean;
  
  // Restaurant state
  currentRestaurant: Restaurant | null;
  setCurrentRestaurant: (restaurant: Restaurant | null) => void;
}

const DeliveryContext = createContext<DeliveryContextType | undefined>(undefined);

export const DeliveryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [currentRestaurant, setCurrentRestaurant] = useState<Restaurant | null>(null);
  const { toast } = useToast();

  // Calculate cart totals
  const cartSubtotal = cart.reduce((total, item) => {
    const itemPrice = item.menuItem.price;
    const optionsPrice = item.options?.reduce((sum, opt) => sum + opt.choice.price, 0) || 0;
    return total + ((itemPrice + optionsPrice) * item.quantity);
  }, 0);
  
  const cartTax = cartSubtotal * 0.08; // 8% tax
  const cartDeliveryFee = cart.length > 0 ? 3.99 : 0; // Fixed delivery fee
  const cartTotal = cartSubtotal + cartTax + cartDeliveryFee;

  // Initialize state from localStorage on component mount
  useEffect(() => {
    setCart(deliveryStorage.getCart());
    setOrders(deliveryStorage.getOrders());
    setFavorites(deliveryStorage.getFavoriteRestaurants());
  }, []);

  // Cart methods
  const addToCart = (item: CartItem) => {
    deliveryStorage.addToCart(item);
    setCart(deliveryStorage.getCart());
    
    toast({
      title: "Added to cart",
      description: `${item.quantity} × ${item.menuItem.name} added to your cart`,
    });
  };

  const updateCartItem = (index: number, item: CartItem) => {
    deliveryStorage.updateCartItem(index, item);
    setCart(deliveryStorage.getCart());
  };

  const removeFromCart = (index: number) => {
    const itemName = cart[index]?.menuItem.name;
    deliveryStorage.removeFromCart(index);
    setCart(deliveryStorage.getCart());
    
    toast({
      title: "Item removed",
      description: `${itemName} removed from your cart`,
    });
  };

  const clearCart = () => {
    deliveryStorage.clearCart();
    setCart([]);
  };

  // Order methods
  const addOrder = (order: Order) => {
    deliveryStorage.addOrder(order);
    setOrders(deliveryStorage.getOrders());
    clearCart(); // Clear the cart after placing an order
    
    toast({
      title: "Order placed!",
      description: `Your order has been successfully placed. Order ID: ${order.id}`,
    });
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    deliveryStorage.updateOrderStatus(orderId, status);
    setOrders(deliveryStorage.getOrders());
  };

  // Favorite methods
  const addToFavorites = (restaurantId: string) => {
    deliveryStorage.addToFavorites(restaurantId);
    setFavorites(deliveryStorage.getFavoriteRestaurants());
    
    toast({
      title: "Added to favorites",
      description: "Restaurant added to your favorites",
    });
  };

  const removeFromFavorites = (restaurantId: string) => {
    deliveryStorage.removeFromFavorites(restaurantId);
    setFavorites(deliveryStorage.getFavoriteRestaurants());
    
    toast({
      title: "Removed from favorites",
      description: "Restaurant removed from your favorites",
    });
  };

  const isFavorite = (restaurantId: string) => {
    return favorites.includes(restaurantId);
  };

  const value = {
    cart,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart,
    cartTotal,
    cartSubtotal,
    cartTax,
    cartDeliveryFee,
    orders,
    addOrder,
    updateOrderStatus,
    favorites,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    currentRestaurant,
    setCurrentRestaurant,
  };

  return (
    <DeliveryContext.Provider value={value}>
      {children}
    </DeliveryContext.Provider>
  );
};

export const useDeliveryContext = () => {
  const context = useContext(DeliveryContext);
  if (context === undefined) {
    throw new Error('useDeliveryContext must be used within a DeliveryProvider');
  }
  return context;
};