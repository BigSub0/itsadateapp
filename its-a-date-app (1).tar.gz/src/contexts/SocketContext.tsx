import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { socketService, BidUpdateEvent, DriverLocationUpdateEvent } from '@/lib/socket';

// Define the context type
interface SocketContextType {
  isConnected: boolean;
  bidUpdates: BidUpdateEvent[];
  driverLocationUpdates: Record<number, DriverLocationUpdateEvent>;
  clearBidUpdates: () => void;
}

// Create context with default values
const SocketContext = createContext<SocketContextType>({
  isConnected: false,
  bidUpdates: [],
  driverLocationUpdates: {},
  clearBidUpdates: () => {},
});

// Context provider props
interface SocketProviderProps {
  children: ReactNode;
}

export const SocketProvider: React.FC<SocketProviderProps> = ({ children }) => {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [bidUpdates, setBidUpdates] = useState<BidUpdateEvent[]>([]);
  const [driverLocationUpdates, setDriverLocationUpdates] = useState<Record<number, DriverLocationUpdateEvent>>({});

  // Connect to socket when component mounts
  useEffect(() => {
    const socket = socketService.connect();
    
    // Listen for connection changes
    const handleConnect = () => setIsConnected(true);
    const handleDisconnect = () => setIsConnected(false);
    
    // Listen for bid updates
    const handleBidUpdate = (update: BidUpdateEvent) => {
      setBidUpdates(prev => [...prev, update]);
    };
    
    // Listen for driver location updates
    const handleDriverLocationUpdate = (update: DriverLocationUpdateEvent) => {
      setDriverLocationUpdates(prev => ({
        ...prev,
        [update.driverId]: update
      }));
    };
    
    // Register listeners
    socket.on('connect', handleConnect);
    socket.on('disconnect', handleDisconnect);
    socketService.onBidUpdate(handleBidUpdate);
    socketService.onDriverLocationUpdate(handleDriverLocationUpdate);
    
    // Set initial connection status
    setIsConnected(socketService.isConnected());
    
    // Cleanup function
    return () => {
      socket.off('connect', handleConnect);
      socket.off('disconnect', handleDisconnect);
      socketService.off('bidUpdate', handleBidUpdate);
      socketService.off('driverLocationUpdate', handleDriverLocationUpdate);
      socketService.disconnect();
    };
  }, []);

  // Function to clear bid updates
  const clearBidUpdates = () => {
    setBidUpdates([]);
  };

  // Context value
  const value = {
    isConnected,
    bidUpdates,
    driverLocationUpdates,
    clearBidUpdates,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};

// Custom hook to use the socket context
export const useSocket = () => useContext(SocketContext);