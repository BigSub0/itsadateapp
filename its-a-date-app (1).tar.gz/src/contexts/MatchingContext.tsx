import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { surveyService, profileService, Match, Profile, dateIdeasService, DateIdea } from '@/lib/dating-local-storage';
import { useAuth } from './AuthContext';
import { useProfile } from './ProfileContext';

interface MatchingContextType {
  userMatches: Match[];
  matchProfiles: Map<string, Profile>;
  matchScores: Map<string, number>;
  loading: boolean;
  error: string | null;
  findNewMatches: () => Promise<Match[]>;
  acceptMatch: (matchId: string) => Promise<boolean>;
  rejectMatch: (matchId: string) => Promise<boolean>;
  dateIdeas: DateIdea[];
  filteredDateIdeas: DateIdea[];
  filterDateIdeas: (category?: string, maxCost?: number) => void;
}

const MatchingContext = createContext<MatchingContextType | undefined>(undefined);

interface MatchingProviderProps {
  children: ReactNode;
}

export const MatchingProvider: React.FC<MatchingProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const { profile } = useProfile();
  
  const [userMatches, setUserMatches] = useState<Match[]>([]);
  const [matchProfiles, setMatchProfiles] = useState<Map<string, Profile>>(new Map());
  const [matchScores, setMatchScores] = useState<Map<string, number>>(new Map());
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [dateIdeas, setDateIdeas] = useState<DateIdea[]>([]);
  const [filteredDateIdeas, setFilteredDateIdeas] = useState<DateIdea[]>([]);

  // Initialize date ideas
  useEffect(() => {
    dateIdeasService.initializeDateIdeas();
    const allDateIdeas = dateIdeasService.getAllDateIdeas();
    setDateIdeas(allDateIdeas);
    setFilteredDateIdeas(allDateIdeas);
  }, []);

  // Load user matches when user changes
  useEffect(() => {
    if (!user || !profile?.completed) {
      setUserMatches([]);
      return;
    }

    loadUserMatches();
  }, [user, profile]);

  const loadUserMatches = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // Get all matches for the user
      const matches = surveyService.getUserMatches(user.id);
      setUserMatches(matches);

      // Load profiles for all matches
      const profilesMap = new Map<string, Profile>();
      const scoresMap = new Map<string, number>();

      for (const match of matches) {
        const otherUserId = match.user1Id === user.id ? match.user2Id : match.user1Id;
        const otherProfile = profileService.getProfileByUserId(otherUserId);
        
        if (otherProfile) {
          profilesMap.set(otherUserId, otherProfile);
          scoresMap.set(otherUserId, match.matchScore);
        }
      }

      setMatchProfiles(profilesMap);
      setMatchScores(scoresMap);
    } catch (err) {
      console.error('Error loading matches:', err);
      setError('Failed to load matches');
    } finally {
      setLoading(false);
    }
  };

  // Find new potential matches
  const findNewMatches = async (): Promise<Match[]> => {
    if (!user) {
      setError('No user logged in');
      return [];
    }

    setLoading(true);
    try {
      const newMatches = surveyService.findMatches(user.id);
      
      if (newMatches.length > 0) {
        await loadUserMatches(); // Reload all matches
      }
      
      return newMatches;
    } catch (err) {
      console.error('Error finding matches:', err);
      setError('Failed to find new matches');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Accept a match
  const acceptMatch = async (matchId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const success = surveyService.updateMatchStatus(matchId, 'accepted');
      
      if (success) {
        await loadUserMatches(); // Reload matches to update the UI
        return true;
      }
      
      setError('Failed to accept match');
      return false;
    } catch (err) {
      console.error('Error accepting match:', err);
      setError('An error occurred while accepting match');
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Reject a match
  const rejectMatch = async (matchId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const success = surveyService.updateMatchStatus(matchId, 'rejected');
      
      if (success) {
        await loadUserMatches(); // Reload matches to update the UI
        return true;
      }
      
      setError('Failed to reject match');
      return false;
    } catch (err) {
      console.error('Error rejecting match:', err);
      setError('An error occurred while rejecting match');
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Filter date ideas
  const filterDateIdeas = (category?: string, maxCost?: number): void => {
    let filtered = dateIdeas;
    
    if (category) {
      filtered = filtered.filter(idea => idea.category === category);
    }
    
    if (maxCost !== undefined) {
      filtered = filtered.filter(idea => idea.cost <= maxCost);
    }
    
    setFilteredDateIdeas(filtered);
  };

  const value = {
    userMatches,
    matchProfiles,
    matchScores,
    loading,
    error,
    findNewMatches,
    acceptMatch,
    rejectMatch,
    dateIdeas,
    filteredDateIdeas,
    filterDateIdeas
  };

  return <MatchingContext.Provider value={value}>{children}</MatchingContext.Provider>;
};

export const useMatching = (): MatchingContextType => {
  const context = useContext(MatchingContext);
  if (context === undefined) {
    throw new Error('useMatching must be used within a MatchingProvider');
  }
  return context;
};