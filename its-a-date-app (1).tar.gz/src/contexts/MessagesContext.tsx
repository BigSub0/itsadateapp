import React, { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

// Define the message type
export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
  read: boolean;
}

// Define the conversation type
export interface Conversation {
  id: string;
  participantId: string; // The other person's ID
  participantName: string;
  participantImage?: string;
  lastMessage?: string;
  lastMessageTimestamp?: number;
  unreadCount: number;
}

interface MessagesContextType {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  messages: Message[];
  loadingMessages: boolean;
  loadingConversations: boolean;
  error: string | null;
  selectConversation: (conversationId: string) => void;
  sendMessage: (content: string) => Promise<boolean>;
  markAsRead: (messageId: string) => void;
}

const MessagesContext = createContext<MessagesContextType | undefined>(undefined);

export const useMessages = () => {
  const context = useContext(MessagesContext);
  if (context === undefined) {
    throw new Error('useMessages must be used within a MessagesProvider');
  }
  return context;
};

// Demo data - in a real app, this would be fetched from a backend
const DEMO_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv1',
    participantId: 'user2',
    participantName: 'Emma Thompson',
    participantImage: 'https://i.pravatar.cc/150?u=emma',
    lastMessage: "I'd love to meet up this weekend!",
    lastMessageTimestamp: Date.now() - 1000 * 60 * 5, // 5 minutes ago
    unreadCount: 2
  },
  {
    id: 'conv2',
    participantId: 'user3',
    participantName: 'Michael Johnson',
    participantImage: 'https://i.pravatar.cc/150?u=michael',
    lastMessage: 'That restaurant sounds amazing!',
    lastMessageTimestamp: Date.now() - 1000 * 60 * 60, // 1 hour ago
    unreadCount: 0
  },
  {
    id: 'conv3',
    participantId: 'user4',
    participantName: 'Sophia Williams',
    participantImage: 'https://i.pravatar.cc/150?u=sophia',
    lastMessage: 'Do you like hiking?',
    lastMessageTimestamp: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
    unreadCount: 0
  }
];

const DEMO_MESSAGES: Record<string, Message[]> = {
  'conv1': [
    {
      id: 'm1',
      senderId: 'user2',
      receiverId: 'user1',
      content: 'Hey there! I noticed we matched. How are you doing today?',
      timestamp: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
      read: true
    },
    {
      id: 'm2',
      senderId: 'user1',
      receiverId: 'user2',
      content: "Hi Emma! I'm doing well, thanks for asking. I loved your profile - especially that you're into hiking too!",
      timestamp: Date.now() - 1000 * 60 * 60, // 1 hour ago
      read: true
    },
    {
      id: 'm3',
      senderId: 'user2',
      receiverId: 'user1',
      content: 'Thanks! Yes, I try to go hiking at least twice a month. Do you have any favorite trails?',
      timestamp: Date.now() - 1000 * 60 * 30, // 30 minutes ago
      read: true
    },
    {
      id: 'm4',
      senderId: 'user1',
      receiverId: 'user2',
      content: 'I love the trails at Redwood National Park. The scenery is breathtaking!',
      timestamp: Date.now() - 1000 * 60 * 15, // 15 minutes ago
      read: true
    },
    {
      id: 'm5',
      senderId: 'user2',
      receiverId: 'user1',
      content: "I've never been there but I've heard great things! Would you be interested in showing me around sometime?",
      timestamp: Date.now() - 1000 * 60 * 10, // 10 minutes ago
      read: false
    },
    {
      id: 'm6',
      senderId: 'user2',
      receiverId: 'user1',
      content: "I'd love to meet up this weekend!",
      timestamp: Date.now() - 1000 * 60 * 5, // 5 minutes ago
      read: false
    }
  ],
  'conv2': [
    {
      id: 'm7',
      senderId: 'user3',
      receiverId: 'user1',
      content: 'Hello! I saw we have a mutual interest in trying new restaurants.',
      timestamp: Date.now() - 1000 * 60 * 60 * 3, // 3 hours ago
      read: true
    },
    {
      id: 'm8',
      senderId: 'user1',
      receiverId: 'user3',
      content: "Hi Michael! Yes, I'm always looking for new places to eat. Any recommendations?",
      timestamp: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
      read: true
    },
    {
      id: 'm9',
      senderId: 'user3',
      receiverId: 'user1',
      content: "There's this new Italian place downtown called 'La Trattoria' that has amazing pasta.",
      timestamp: Date.now() - 1000 * 60 * 60 * 1, // 1 hour ago
      read: true
    },
    {
      id: 'm10',
      senderId: 'user1',
      receiverId: 'user3',
      content: 'That restaurant sounds amazing!',
      timestamp: Date.now() - 1000 * 60 * 30, // 30 minutes ago
      read: true
    }
  ],
  'conv3': [
    {
      id: 'm11',
      senderId: 'user4',
      receiverId: 'user1',
      content: 'Hi there! I noticed we both enjoy outdoor activities.',
      timestamp: Date.now() - 1000 * 60 * 60 * 25, // 25 hours ago
      read: true
    },
    {
      id: 'm12',
      senderId: 'user1',
      receiverId: 'user4',
      content: "Hey Sophia! Yes, I love spending time outdoors. What's your favorite activity?",
      timestamp: Date.now() - 1000 * 60 * 60 * 24, // 24 hours ago
      read: true
    },
    {
      id: 'm13',
      senderId: 'user4',
      receiverId: 'user1',
      content: 'Do you like hiking?',
      timestamp: Date.now() - 1000 * 60 * 60 * 23, // 23 hours ago
      read: true
    }
  ]
};

interface MessagesProviderProps {
  children: ReactNode;
}

export function MessagesProvider({ children }: MessagesProviderProps) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingConversations, setLoadingConversations] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load conversations when user changes
  useEffect(() => {
    if (user) {
      setLoadingConversations(true);
      
      // Simulate API call delay
      setTimeout(() => {
        setConversations(DEMO_CONVERSATIONS);
        setLoadingConversations(false);
      }, 500);
    } else {
      setConversations([]);
      setCurrentConversation(null);
      setMessages([]);
    }
  }, [user]);

  // Select a conversation and load its messages
  const selectConversation = (conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId);
    
    if (conversation) {
      setCurrentConversation(conversation);
      setLoadingMessages(true);
      
      // Simulate API call delay
      setTimeout(() => {
        const conversationMessages = DEMO_MESSAGES[conversationId] || [];
        setMessages(conversationMessages);
        
        // Update unread count
        if (conversation.unreadCount > 0) {
          setConversations(prevConversations =>
            prevConversations.map(c =>
              c.id === conversationId ? { ...c, unreadCount: 0 } : c
            )
          );
        }
        
        setLoadingMessages(false);
      }, 500);
    }
  };

  // Send a message
  const sendMessage = async (content: string): Promise<boolean> => {
    if (!currentConversation || !user || !content.trim()) {
      return false;
    }

    try {
      // Create new message
      const newMessage: Message = {
        id: `m${Date.now()}`,
        senderId: user.id,
        receiverId: currentConversation.participantId,
        content: content.trim(),
        timestamp: Date.now(),
        read: false
      };

      // Update messages state
      setMessages(prevMessages => [...prevMessages, newMessage]);

      // Update conversation with last message
      setConversations(prevConversations =>
        prevConversations.map(c =>
          c.id === currentConversation.id
            ? {
                ...c,
                lastMessage: content.trim(),
                lastMessageTimestamp: Date.now()
              }
            : c
        )
      );

      return true;
    } catch (err) {
      setError('Failed to send message');
      return false;
    }
  };

  // Mark a message as read
  const markAsRead = (messageId: string) => {
    setMessages(prevMessages =>
      prevMessages.map(m =>
        m.id === messageId ? { ...m, read: true } : m
      )
    );
  };

  const value = {
    conversations,
    currentConversation,
    messages,
    loadingMessages,
    loadingConversations,
    error,
    selectConversation,
    sendMessage,
    markAsRead
  };

  return <MessagesContext.Provider value={value}>{children}</MessagesContext.Provider>;
}