import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { profileService, Profile } from '@/lib/dating-local-storage';
import { useAuth } from './AuthContext';

interface ProfileContextType {
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  updateProfile: (updatedProfile: Partial<Profile>) => Promise<boolean>;
  isProfileComplete: boolean;
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

interface ProfileProviderProps {
  children: ReactNode;
}

export const ProfileProvider: React.FC<ProfileProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isProfileComplete, setIsProfileComplete] = useState<boolean>(false);

  // Load profile when user changes
  useEffect(() => {
    if (!user) {
      setProfile(null);
      setLoading(false);
      setIsProfileComplete(false);
      return;
    }

    setLoading(true);
    try {
      const userProfile = profileService.getProfileByUserId(user.id);
      setProfile(userProfile);
      setIsProfileComplete(!!userProfile?.completed);
    } catch (err) {
      console.error('Error loading profile:', err);
      setError('Failed to load profile');
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Update profile function
  const updateProfile = async (updatedProfileData: Partial<Profile>): Promise<boolean> => {
    if (!user || !profile) {
      setError('No user logged in or profile not found');
      return false;
    }

    setLoading(true);
    setError(null);

    try {
      const updatedProfile = {
        ...profile,
        ...updatedProfileData
      };

      const result = profileService.updateProfile(updatedProfile);
      
      if (result) {
        setProfile(result);
        setIsProfileComplete(!!result.completed);
        return true;
      } else {
        setError('Failed to update profile');
        return false;
      }
    } catch (err) {
      console.error('Error updating profile:', err);
      setError('An error occurred while updating profile');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    profile,
    loading,
    error,
    updateProfile,
    isProfileComplete
  };

  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
};

export const useProfile = (): ProfileContextType => {
  const context = useContext(ProfileContext);
  if (context === undefined) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }
  return context;
};