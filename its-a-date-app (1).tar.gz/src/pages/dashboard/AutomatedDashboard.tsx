import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import DriverAutoAssignment from '@/components/dashboard/DriverAutoAssignment';
import SystemAnalyticsDashboard from '@/components/dashboard/SystemAnalyticsDashboard';
import ClientPortalTracker from '@/components/dashboard/ClientPortalTracker';
import { Clock, Activity, BarChart3, Map, Bell, Settings, Users, Truck, Package } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';

const AutomatedDashboard = () => {
  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden lg:flex flex-col w-64 bg-white border-r p-4">
        <div className="flex items-center mb-6">
          <div className="font-bold text-xl text-blue-600">Vital Xpress</div>
          <Badge variant="outline" className="ml-2 bg-green-100 text-green-800 border-green-200">
            Auto
          </Badge>
        </div>
        
        <div className="space-y-1">
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <BarChart3 className="mr-2 h-4 w-4" />
            Dashboard
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Package className="mr-2 h-4 w-4" />
            Orders
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Truck className="mr-2 h-4 w-4" />
            Drivers
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Users className="mr-2 h-4 w-4" />
            Customers
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Map className="mr-2 h-4 w-4" />
            Routes
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Activity className="mr-2 h-4 w-4" />
            Analytics
          </Button>
          <Button variant="ghost" className="w-full justify-start" size="sm">
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Button>
        </div>
        
        <Separator className="my-4" />
        
        <div className="mt-auto">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-green-700">System Operational</span>
          </div>
          
          <div className="flex items-center">
            <Avatar className="h-9 w-9">
              <AvatarImage src="" />
              <AvatarFallback className="bg-blue-100 text-blue-800">VX</AvatarFallback>
            </Avatar>
            <div className="ml-2">
              <div className="text-sm font-medium">Admin User</div>
              <div className="text-xs text-muted-foreground">admin@vitalxpress.com</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top navigation */}
        <header className="bg-white border-b px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center">
            <h1 className="text-lg font-semibold">Automated Management System</h1>
            <Badge className="ml-2 bg-blue-100 text-blue-800 border-blue-200">AI-Powered</Badge>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center text-sm">
              <Clock className="mr-1 h-4 w-4" />
              <span>{new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            
            <Button size="icon" variant="ghost">
              <Bell className="h-5 w-5" />
            </Button>
            
            <Avatar className="h-8 w-8 lg:hidden">
              <AvatarFallback className="bg-blue-100 text-blue-800">VX</AvatarFallback>
            </Avatar>
          </div>
        </header>
        
        {/* Dashboard content */}
        <main className="flex-1 p-6 overflow-auto">
          {/* Overview stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Deliveries</p>
                  <h2 className="text-2xl font-bold">24</h2>
                  <p className="text-xs text-green-600">+12% from last week</p>
                </div>
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Truck className="h-5 w-5 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Available Drivers</p>
                  <h2 className="text-2xl font-bold">18</h2>
                  <p className="text-xs text-amber-600">-2 since morning</p>
                </div>
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Users className="h-5 w-5 text-amber-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">On-Time Rate</p>
                  <h2 className="text-2xl font-bold">97.3%</h2>
                  <p className="text-xs text-green-600">+4.2% from last month</p>
                </div>
                <div className="p-2 bg-green-100 rounded-lg">
                  <Activity className="h-5 w-5 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main dashboard tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid grid-cols-4 w-full max-w-lg mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="assignments">Auto Assignments</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="tracking">Order Tracking</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <DriverAutoAssignment />
                </div>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">System Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[500px] pr-4">
                      <div className="space-y-4">
                        {[...Array(10)].map((_, i) => (
                          <div key={i} className="p-3 border rounded-lg">
                            <div className="flex justify-between items-start">
                              <div className="font-medium text-sm">
                                {['Order assigned', 'Route optimized', 'Driver dispatched', 'Delivery completed', 'New order received'][i % 5]}
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {`${i} min ago`}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {[
                                'AI automatically assigned order #ORD-78452 to driver James Wilson.',
                                'Route optimization reduced trip by 2.3 miles for order #ORD-78455.',
                                'Driver Michael Chen dispatched for pickup at Piedmont Hospital.',
                                'Order #ORD-78431 delivered successfully, 15 minutes ahead of schedule.',
                                'New medical delivery request #ORD-78461 received and queued for assignment.'
                              ][i % 5]}
                            </p>
                            <div className="flex mt-2 gap-1">
                              <Badge variant="outline" className="bg-blue-100 text-blue-800 text-xs">
                                Automated
                              </Badge>
                              <Badge variant="outline" className="bg-green-100 text-green-800 text-xs">
                                Successful
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Auto Assignments Tab */}
            <TabsContent value="assignments">
              <DriverAutoAssignment />
            </TabsContent>
            
            {/* Analytics Tab */}
            <TabsContent value="analytics">
              <SystemAnalyticsDashboard />
            </TabsContent>
            
            {/* Order Tracking Tab */}
            <TabsContent value="tracking">
              <ClientPortalTracker />
            </TabsContent>
          </Tabs>
        </main>
        
        {/* Footer */}
        <footer className="bg-white border-t p-4 text-center text-sm text-muted-foreground">
          <div className="flex items-center justify-center gap-1">
            <span>Vital Xpress Automated Management System</span>
            <div className="w-1 h-1 rounded-full bg-muted-foreground mx-1"></div>
            <span>Version 2.0.3</span>
          </div>
          <div className="text-xs mt-1">
            AI-Powered • Self-Optimizing • Real-Time
          </div>
        </footer>
      </div>
    </div>
  );
}

export default AutomatedDashboard;