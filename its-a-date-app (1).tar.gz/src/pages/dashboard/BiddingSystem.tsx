import React, { useState, useEffect } from 'react';
import { useSocket } from '@/contexts/SocketContext';
import { apiService, PlaceBidRequest, LoadLocation } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { AlertCircle, CheckCircle2, TruckIcon } from 'lucide-react';

export default function BiddingSystem() {
  // Socket context for real-time updates
  const { isConnected, bidUpdates } = useSocket();
  
  // Form state
  const [loadId, setLoadId] = useState<string>('');
  const [pickup, setPickup] = useState<LoadLocation>({ lat: 40.7128, lng: -74.0060 }); // Default to NYC
  const [dropoff, setDropoff] = useState<LoadLocation>({ lat: 40.7589, lng: -73.9851 }); // Default nearby
  const [isMedical, setIsMedical] = useState<boolean>(false);
  const [isLongHaul, setIsLongHaul] = useState<boolean>(false);
  const [estimatedBid, setEstimatedBid] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  // Display the latest bid updates at the top
  const sortedBidUpdates = [...bidUpdates].reverse();

  // Calculate estimated bid when form values change
  useEffect(() => {
    const calculateBid = () => {
      const bid = apiService.calculateEstimatedBid(pickup, dropoff, isMedical, isLongHaul);
      setEstimatedBid(bid);
    };
    
    calculateBid();
  }, [pickup, dropoff, isMedical, isLongHaul]);
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loadId.trim()) {
      toast.error("Please enter a load ID");
      return;
    }
    
    const bidRequest: PlaceBidRequest = {
      loadId,
      pickupLocation: pickup,
      dropoffLocation: dropoff,
      isMedical,
      isLongHaul
    };
    
    try {
      setIsSubmitting(true);
      const response = await apiService.placeBid(bidRequest);
      toast.success(`Bid placed successfully! Assigned to ${response.assignedDriver}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to place bid';
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle coordinate input changes
  const handleCoordinateChange = (
    type: 'pickup' | 'dropoff',
    field: 'lat' | 'lng',
    value: string
  ) => {
    const numValue = parseFloat(value);
    
    if (isNaN(numValue)) return;
    
    if (type === 'pickup') {
      setPickup(prev => ({ ...prev, [field]: numValue }));
    } else {
      setDropoff(prev => ({ ...prev, [field]: numValue }));
    }
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Vital Xpress Bidding System</h1>
        <Badge 
          variant={isConnected ? "default" : "destructive"}
          className="text-xs"
        >
          {isConnected ? 'Connected' : 'Disconnected'}
        </Badge>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bidding Form */}
        <Card>
          <CardHeader>
            <CardTitle>Place New Bid</CardTitle>
            <CardDescription>
              Enter load details to calculate and place a bid
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="loadId">Load ID</Label>
                <Input 
                  id="loadId"
                  value={loadId}
                  onChange={(e) => setLoadId(e.target.value)}
                  placeholder="Enter load identifier"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Pickup Location</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Input
                        value={pickup.lat}
                        onChange={(e) => handleCoordinateChange('pickup', 'lat', e.target.value)}
                        placeholder="Latitude"
                      />
                    </div>
                    <div>
                      <Input
                        value={pickup.lng}
                        onChange={(e) => handleCoordinateChange('pickup', 'lng', e.target.value)}
                        placeholder="Longitude"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Dropoff Location</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Input
                        value={dropoff.lat}
                        onChange={(e) => handleCoordinateChange('dropoff', 'lat', e.target.value)}
                        placeholder="Latitude"
                      />
                    </div>
                    <div>
                      <Input
                        value={dropoff.lng}
                        onChange={(e) => handleCoordinateChange('dropoff', 'lng', e.target.value)}
                        placeholder="Longitude"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="medical"
                    checked={isMedical}
                    onCheckedChange={setIsMedical}
                  />
                  <Label htmlFor="medical">Medical Transport</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="longHaul" 
                    checked={isLongHaul}
                    onCheckedChange={setIsLongHaul}
                  />
                  <Label htmlFor="longHaul">Long Haul</Label>
                </div>
              </div>
              
              <div className="bg-muted p-4 rounded-md text-center">
                <p className="text-sm text-muted-foreground">Estimated Bid</p>
                <p className="text-2xl font-bold">${estimatedBid.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Includes 20% profit margin
                </p>
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleSubmit} 
              className="w-full"
              disabled={isSubmitting || !isConnected}
            >
              {isSubmitting ? 'Processing...' : 'Place Bid'}
            </Button>
          </CardFooter>
        </Card>
        
        {/* Bid Updates */}
        <Card>
          <CardHeader>
            <CardTitle>Real-Time Bid Updates</CardTitle>
            <CardDescription>
              Live updates from the Vital Xpress bidding system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedBidUpdates.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <TruckIcon className="mx-auto h-12 w-12 mb-2 opacity-20" />
                  <p>No bid updates yet</p>
                  <p className="text-sm">Place a bid to see real-time updates</p>
                </div>
              ) : (
                sortedBidUpdates.map((update, index) => (
                  <div 
                    key={index} 
                    className="p-4 border rounded-md space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {update.status.includes('Error') || update.status === 'Bid rejected' ? (
                          <AlertCircle className="h-5 w-5 text-destructive" />
                        ) : (
                          <CheckCircle2 className="h-5 w-5 text-success" />
                        )}
                        <span className="font-medium">Load ID: {update.loadId}</span>
                      </div>
                      <Badge
                        variant={
                          update.status.includes('Error') || update.status === 'Bid rejected'
                            ? 'destructive'
                            : 'outline'
                        }
                      >
                        {update.status}
                      </Badge>
                    </div>
                    
                    {update.bidPrice && (
                      <p className="text-sm">
                        Bid Amount: <span className="font-semibold">${update.bidPrice.toFixed(2)}</span>
                      </p>
                    )}
                    
                    {update.assignedDriver && (
                      <p className="text-sm">
                        Driver: <span className="font-semibold">{update.assignedDriver}</span>
                      </p>
                    )}
                    
                    {update.distance && (
                      <p className="text-sm">
                        Distance: <span className="font-semibold">{update.distance.toFixed(2)} miles</span>
                      </p>
                    )}
                    
                    {update.error && (
                      <p className="text-sm text-destructive">{update.error}</p>
                    )}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}