import React, { useState } from 'react';
import DashboardNavigation from '@/components/layout/DashboardNavigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import DriverMap from '@/components/dashboard/DriverMap';
import { Badge } from '@/components/ui/badge';
import { Phone, Mail, MapPin, AlertCircle, CheckCircle, UserPlus, FilterIcon } from 'lucide-react';

// Sample driver data
const drivers = [
  {
    id: 'd1',
    name: 'James Wilson',
    phone: '(404) 555-1234',
    email: 'james.w@example.com',
    status: 'active',
    location: {
      lat: 33.748997,
      lng: -84.387985,
      lastUpdate: '2 min ago',
      address: 'Downtown Atlanta'
    },
    vehicle: 'Sedan',
    medicalCertified: true,
    completedDeliveries: 128,
    rating: 4.9
  },
  {
    id: 'd2',
    name: 'Sarah Johnson',
    phone: '(404) 555-2345',
    email: 'sarah.j@example.com',
    status: 'delivering',
    location: {
      lat: 33.762909,
      lng: -84.422675,
      lastUpdate: '5 min ago',
      address: 'Midtown Atlanta'
    },
    vehicle: 'SUV',
    medicalCertified: true,
    completedDeliveries: 95,
    rating: 4.8
  },
  {
    id: 'd3',
    name: 'Michael Brown',
    phone: '(404) 555-3456',
    email: 'michael.b@example.com',
    status: 'offline',
    location: {
      lat: 33.857476,
      lng: -84.362996,
      lastUpdate: '3 hrs ago',
      address: 'Buckhead'
    },
    vehicle: 'Box Truck',
    medicalCertified: false,
    completedDeliveries: 67,
    rating: 4.6
  },
  {
    id: 'd4',
    name: 'Emily Davis',
    phone: '(404) 555-4567',
    email: 'emily.d@example.com',
    status: 'available',
    location: {
      lat: 33.939465,
      lng: -84.520388,
      lastUpdate: '10 min ago',
      address: 'Marietta'
    },
    vehicle: 'Sedan',
    medicalCertified: true,
    completedDeliveries: 112,
    rating: 4.9
  },
  {
    id: 'd5',
    name: 'David Martinez',
    phone: '(404) 555-5678',
    email: 'david.m@example.com',
    status: 'available',
    location: {
      lat: 33.684944,
      lng: -84.449476,
      lastUpdate: '7 min ago',
      address: 'College Park'
    },
    vehicle: 'SUV',
    medicalCertified: false,
    completedDeliveries: 73,
    rating: 4.7
  }
];

export default function DriverManagement() {
  const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('all');
  const [filterOpen, setFilterOpen] = useState(false);
  
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'delivering': return 'bg-blue-100 text-blue-800';
      case 'available': return 'bg-emerald-100 text-emerald-800';
      case 'offline': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getStatusText = (status: string) => {
    switch(status) {
      case 'active': return 'Active';
      case 'delivering': return 'On Delivery';
      case 'available': return 'Available';
      case 'offline': return 'Offline';
      default: return status;
    }
  };
  
  const filteredDrivers = drivers.filter(driver => {
    if (activeTab === 'all') return true;
    if (activeTab === 'medical') return driver.medicalCertified;
    if (activeTab === 'available') return driver.status === 'available';
    if (activeTab === 'delivering') return driver.status === 'delivering';
    return true;
  });
  
  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardNavigation />
      
      <div className="container mx-auto p-6">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-blue-800">Driver Management</h1>
              <p className="text-gray-600">Track and manage your courier fleet</p>
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setFilterOpen(!filterOpen)}>
                <FilterIcon className="h-4 w-4 mr-2" />
                Filters
              </Button>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                <UserPlus className="h-4 w-4 mr-2" />
                Add Driver
              </Button>
            </div>
          </div>
        </header>
        
        {filterOpen && (
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Vehicle Type</label>
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="sedan">Sedan</SelectItem>
                      <SelectItem value="suv">SUV</SelectItem>
                      <SelectItem value="box_truck">Box Truck</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Certification</label>
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="All" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="medical">Medical Certified</SelectItem>
                      <SelectItem value="non_medical">Non-Medical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Min. Rating</label>
                  <Select defaultValue="4.0">
                    <SelectTrigger>
                      <SelectValue placeholder="Min Rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any Rating</SelectItem>
                      <SelectItem value="4.5">4.5+</SelectItem>
                      <SelectItem value="4.0">4.0+</SelectItem>
                      <SelectItem value="3.5">3.5+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Apply Filters</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 order-2 lg:order-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Driver Fleet</CardTitle>
                <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid grid-cols-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="available">Available</TabsTrigger>
                    <TabsTrigger value="delivering">On Delivery</TabsTrigger>
                    <TabsTrigger value="medical">Medical</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent className="p-0">
                <div className="px-4 py-2 bg-gray-50 border-y">
                  <Input placeholder="Search drivers..." className="max-w-full" />
                </div>
                <div className="max-h-[600px] overflow-auto">
                  <Table>
                    <TableBody>
                      {filteredDrivers.map((driver) => (
                        <TableRow 
                          key={driver.id} 
                          className={`cursor-pointer ${selectedDriverId === driver.id ? 'bg-blue-50' : ''}`}
                          onClick={() => setSelectedDriverId(driver.id)}
                        >
                          <TableCell className="py-3">
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                <span className="text-blue-600 font-medium">
                                  {driver.name.split(' ').map(n => n[0]).join('')}
                                </span>
                              </div>
                              <div>
                                <div className="font-medium">{driver.name}</div>
                                <div className="text-sm text-muted-foreground">{driver.vehicle}</div>
                                <div className="mt-1">
                                  <Badge variant="outline" className={getStatusColor(driver.status)}>
                                    {getStatusText(driver.status)}
                                  </Badge>
                                  {driver.medicalCertified && (
                                    <Badge variant="outline" className="bg-red-100 text-red-800 ml-1">
                                      Medical
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredDrivers.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={1} className="text-center py-10 text-muted-foreground">
                            No drivers match the current filters
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="lg:col-span-2 order-1 lg:order-2">
            <Card>
              <CardHeader>
                <CardTitle>Driver Locations</CardTitle>
                <CardDescription>Real-time location tracking of your courier fleet</CardDescription>
              </CardHeader>
              <CardContent className="p-0 h-[500px]">
                <DriverMap 
                  drivers={drivers} 
                  selectedDriverId={selectedDriverId}
                  onDriverSelect={setSelectedDriverId}
                  center={{ lat: 33.748997, lng: -84.387985 }} // Atlanta coordinates
                />
              </CardContent>
            </Card>
            
            {selectedDriverId && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Driver Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {drivers.filter(d => d.id === selectedDriverId).map(driver => (
                    <div key={driver.id}>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                            <span className="text-blue-600 text-xl font-medium">
                              {driver.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h3 className="text-xl font-medium">{driver.name}</h3>
                            <div className="flex items-center">
                              <Badge variant="outline" className={getStatusColor(driver.status)}>
                                {getStatusText(driver.status)}
                              </Badge>
                              {driver.medicalCertified ? (
                                <Badge variant="outline" className="bg-red-100 text-red-800 ml-2">
                                  Medical Certified <CheckCircle className="h-3 w-3 ml-1" />
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-amber-100 text-amber-800 ml-2">
                                  Non-Medical <AlertCircle className="h-3 w-3 ml-1" />
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Phone className="h-4 w-4 mr-2" />
                            Call
                          </Button>
                          <Button size="sm" variant="outline">
                            <Mail className="h-4 w-4 mr-2" />
                            Email
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <div className="text-sm font-medium text-blue-600 mb-1">Vehicle Type</div>
                          <div className="font-medium">{driver.vehicle}</div>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                          <div className="text-sm font-medium text-green-600 mb-1">Completed Deliveries</div>
                          <div className="font-medium">{driver.completedDeliveries}</div>
                        </div>
                        <div className="p-4 bg-amber-50 rounded-lg">
                          <div className="text-sm font-medium text-amber-600 mb-1">Rating</div>
                          <div className="font-medium">{driver.rating}/5.0</div>
                        </div>
                      </div>
                      
                      <div className="border-t pt-4">
                        <div className="flex items-center mb-2">
                          <MapPin className="h-4 w-4 text-blue-600 mr-2" />
                          <div className="text-sm font-medium">Current Location</div>
                        </div>
                        <div className="mb-1">{driver.location.address}</div>
                        <div className="text-xs text-muted-foreground">Last updated {driver.location.lastUpdate}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}