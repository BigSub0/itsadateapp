import React, { useState } from 'react';
import DashboardNavigation from '@/components/layout/DashboardNavigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import LoadBoardTable from '@/components/dashboard/LoadBoardTable';
import BiddingPanel from '@/components/dashboard/BiddingPanel';
import { FilterIcon, RefreshCw, Clock, Settings } from 'lucide-react';

// Sample data for load boards
const loadBoards = [
  { id: 'dat', name: 'DAT', count: 127, connected: true },
  { id: 'loadsmart', name: 'LoadSmart', count: 86, connected: true },
  { id: 'chrobinson', name: 'C.H. Robinson', count: 53, connected: true },
  { id: 'goshare', name: 'GoShare', count: 42, connected: false },
];

export default function LoadBoard() {
  const [activeBoard, setActiveBoard] = useState('dat');
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedLoad, setSelectedLoad] = useState<string | null>(null);
  
  const handleLoadSelect = (loadId: string) => {
    setSelectedLoad(loadId);
  };
  
  const handleBidSubmit = () => {
    // In a real implementation, this would submit the bid via API
    setSelectedLoad(null);
    // Show success notification, etc.
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardNavigation />
      
      <div className="container mx-auto p-6">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-blue-800">Load Board</h1>
              <p className="text-gray-600">Discover and bid on available loads</p>
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setFilterOpen(!filterOpen)}>
                <FilterIcon className="h-4 w-4 mr-2" />
                Filters
              </Button>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </header>
        
        {filterOpen && (
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Freight Type</label>
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="medical">Medical</SelectItem>
                      <SelectItem value="general">General</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Distance</label>
                  <Select defaultValue="50">
                    <SelectTrigger>
                      <SelectValue placeholder="Distance" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="25">Within 25 miles</SelectItem>
                      <SelectItem value="50">Within 50 miles</SelectItem>
                      <SelectItem value="100">Within 100 miles</SelectItem>
                      <SelectItem value="all">Any Distance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Min. Rate</label>
                  <Input type="number" placeholder="Min $" />
                </div>
                
                <div className="flex items-end">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Apply Filters</Button>
                </div>
              </div>
              
              <div className="mt-4 flex flex-wrap gap-2">
                <div className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full flex items-center">
                  Medical Freight
                  <button className="ml-2 text-blue-500 hover:text-blue-700">×</button>
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full flex items-center">
                  Within 50 miles
                  <button className="ml-2 text-blue-500 hover:text-blue-700">×</button>
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full flex items-center">
                  Min $20/hour
                  <button className="ml-2 text-blue-500 hover:text-blue-700">×</button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="grid grid-cols-12 gap-6">
          <div className={`${selectedLoad ? 'col-span-12 lg:col-span-7' : 'col-span-12'}`}>
            <Card>
              <CardHeader className="border-b pb-3">
                <div className="flex justify-between">
                  <div>
                    <CardTitle>Available Loads</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Last updated: 2 minutes ago</span>
                    </CardDescription>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
                <Tabs value={activeBoard} onValueChange={setActiveBoard} className="mt-3">
                  <TabsList className="grid grid-cols-4">
                    {loadBoards.map((board) => (
                      <TabsTrigger key={board.id} value={board.id} disabled={!board.connected}>
                        {board.name} ({board.count})
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent className="p-0">
                <LoadBoardTable 
                  boardId={activeBoard} 
                  onLoadSelect={handleLoadSelect} 
                  selectedLoadId={selectedLoad}
                />
              </CardContent>
            </Card>
          </div>
          
          {selectedLoad && (
            <div className="col-span-12 lg:col-span-5">
              <BiddingPanel 
                loadId={selectedLoad} 
                onClose={() => setSelectedLoad(null)}
                onBidSubmit={handleBidSubmit}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}