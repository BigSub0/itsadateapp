import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import DashboardNavigation from '@/components/layout/DashboardNavigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AreaChart } from '@/components/ui/area-chart';
import { BarChart } from '@/components/ui/bar-chart';
import { Activity, Package, Clock, DollarSign, CalendarDays, TrendingUp, Users } from 'lucide-react';

// Sample data for charts
const dailyBidsData = [
  { name: 'Mon', bids: 14, won: 8 },
  { name: 'Tue', bids: 18, won: 12 },
  { name: 'Wed', bids: 16, won: 9 },
  { name: 'Thu', bids: 22, won: 15 },
  { name: 'Fri', bids: 20, won: 13 },
  { name: 'Sat', bids: 10, won: 7 },
  { name: 'Sun', bids: 8, won: 4 },
];

const revenueData = [
  { name: 'Week 1', medical: 4800, general: 2400 },
  { name: 'Week 2', medical: 5200, general: 2600 },
  { name: 'Week 3', medical: 5800, general: 3000 },
  { name: 'Week 4', medical: 6200, general: 3200 },
];

export default function DashboardIndex() {
  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardNavigation />
      
      <div className="container mx-auto p-6">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-blue-800">Vital Xpress Dashboard</h1>
          <p className="text-gray-600">Medical Courier Services Management</p>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Summary Cards */}
          <Card>
            <CardContent className="p-6 flex flex-col space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm font-medium">Active Loads</span>
                <span className="bg-blue-100 p-2 rounded-full">
                  <Package className="h-4 w-4 text-blue-600" />
                </span>
              </div>
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold">24</span>
                <span className="text-green-500 text-sm font-medium">+12%</span>
              </div>
              <span className="text-xs text-muted-foreground">From last week</span>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex flex-col space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm font-medium">Bids Won</span>
                <span className="bg-green-100 p-2 rounded-full">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </span>
              </div>
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold">68</span>
                <span className="text-green-500 text-sm font-medium">+8%</span>
              </div>
              <span className="text-xs text-muted-foreground">This month</span>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex flex-col space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm font-medium">Active Drivers</span>
                <span className="bg-amber-100 p-2 rounded-full">
                  <Users className="h-4 w-4 text-amber-600" />
                </span>
              </div>
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold">15</span>
                <span className="text-amber-500 text-sm font-medium">+2</span>
              </div>
              <span className="text-xs text-muted-foreground">Since last month</span>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 flex flex-col space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm font-medium">Revenue</span>
                <span className="bg-indigo-100 p-2 rounded-full">
                  <DollarSign className="h-4 w-4 text-indigo-600" />
                </span>
              </div>
              <div className="flex items-baseline space-x-2">
                <span className="text-3xl font-bold">$9,284</span>
                <span className="text-green-500 text-sm font-medium">+11%</span>
              </div>
              <span className="text-xs text-muted-foreground">This month</span>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Chart Cards */}
          <Card>
            <CardHeader>
              <CardTitle>Bid Performance</CardTitle>
              <CardDescription>Bids placed vs bids won this week</CardDescription>
            </CardHeader>
            <CardContent>
              <BarChart 
                data={dailyBidsData}
                index="name"
                categories={["bids", "won"]}
                colors={["sky", "blue"]}
                valueFormatter={(value) => `${value} bids`}
                className="h-72"
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Revenue by Service Type</CardTitle>
              <CardDescription>Medical vs general courier revenue</CardDescription>
            </CardHeader>
            <CardContent>
              <AreaChart 
                data={revenueData}
                index="name"
                categories={["medical", "general"]}
                colors={["red", "blue"]}
                valueFormatter={(value) => `$${value}`}
                className="h-72"
              />
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 gap-6 mb-8">
          {/* Recent Activity */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest system events and notifications</CardDescription>
              </div>
              <Tabs defaultValue="all">
                <TabsList className="grid grid-cols-3 w-[300px]">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="bids">Bids</TabsTrigger>
                  <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Bid #8294 won for medical specimen delivery</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>5 minutes ago</span>
                      <span className="mx-2">•</span>
                      <span>$85.50 • 18.7 miles</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Package className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Load #7129 delivered successfully</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>23 minutes ago</span>
                      <span className="mx-2">•</span>
                      <span>Driver: James Wilson</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-amber-100 p-2 rounded-full">
                    <Activity className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="font-medium">New load posted on DAT matching your criteria</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>42 minutes ago</span>
                      <span className="mx-2">•</span>
                      <span>Medical freight • Priority</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-indigo-100 p-2 rounded-full">
                    <CalendarDays className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-medium">Scheduled pickup for recurring client LabCorp</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>1 hour ago</span>
                      <span className="mx-2">•</span>
                      <span>Today at 4:30 PM</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}