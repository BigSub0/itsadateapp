import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, MessageCircle, Calendar, User, ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="flex flex-col items-center text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent mb-6">
            It's A Date
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 max-w-2xl mb-10">
            Find your perfect match and discover exciting date ideas with exclusive local discounts
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/dating/auth">
              <Button size="lg" className="bg-pink-500 hover:bg-pink-600">
                Get Started
              </Button>
            </Link>
            <Link to="/dating/date-ideas">
              <Button size="lg" variant="outline">
                Browse Date Ideas
              </Button>
            </Link>
          </div>
        </div>

        {/* App Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="mx-auto bg-pink-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-2">
                <Heart className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle>Find Matches</CardTitle>
              <CardDescription>Connect with people who share your interests</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Create your profile, share your interests, and we'll suggest compatible matches in your area.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Link to="/dating/dashboard">
                <Button variant="ghost" className="text-pink-500 flex items-center gap-2">
                  <span>Discover Matches</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="mx-auto bg-pink-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-2">
                <Calendar className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle>Date Ideas</CardTitle>
              <CardDescription>Discover perfect date spots with special offers</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Browse curated date ideas from local businesses offering exclusive discounts to our users.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Link to="/dating/date-ideas">
                <Button variant="ghost" className="text-pink-500 flex items-center gap-2">
                  <span>Browse Date Ideas</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="mx-auto bg-pink-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-2">
                <User className="h-6 w-6 text-pink-500" />
              </div>
              <CardTitle>Build Profile</CardTitle>
              <CardDescription>Create a profile that reflects the real you</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Set up your profile with photos, interests, and preferences to help us find your perfect match.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Link to="/dating/profile">
                <Button variant="ghost" className="text-pink-500 flex items-center gap-2">
                  <span>Create Profile</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>

        {/* How it Works */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-10">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: '1',
                title: 'Create Account',
                description: 'Sign up and verify your email to get started',
                icon: <User className="h-6 w-6 text-white" />
              },
              {
                step: '2',
                title: 'Build Profile',
                description: 'Add your details, photos, and interests',
                icon: <User className="h-6 w-6 text-white" />
              },
              {
                step: '3',
                title: 'Find Matches',
                description: 'Discover people who share your interests',
                icon: <Heart className="h-6 w-6 text-white" />
              },
              {
                step: '4',
                title: 'Plan Dates',
                description: 'Use our suggestions to plan the perfect date',
                icon: <Calendar className="h-6 w-6 text-white" />
              }
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="font-bold text-xl mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-pink-500 to-purple-600 rounded-xl p-8 md:p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to find your perfect match?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of happy couples who found each other through It's A Date
          </p>
          <Link to="/dating/auth">
            <Button size="lg" variant="secondary" className="bg-white text-pink-600 hover:bg-gray-100">
              Create Your Account Now
            </Button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 bg-white mt-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold text-pink-500">It's A Date</h2>
            </div>
            <div className="flex gap-6">
              <Link to="/dating/auth" className="text-gray-600 hover:text-pink-500">Sign In</Link>
              <Link to="/dating/date-ideas" className="text-gray-600 hover:text-pink-500">Date Ideas</Link>
              <Link to="#" className="text-gray-600 hover:text-pink-500">About</Link>
              <Link to="#" className="text-gray-600 hover:text-pink-500">Contact</Link>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-6 pt-6 text-center text-gray-500 text-sm">
            © 2023 It's A Date. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}