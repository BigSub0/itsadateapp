import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, Calendar, Search, User, CheckCircle2 } from 'lucide-react';

export default function WelcomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50">
      {/* Hero Section */}
      <header className="container mx-auto py-16 px-4 md:py-24 flex flex-col items-center text-center">
        <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
          It's A Date
        </h1>
        <p className="text-xl md:text-2xl max-w-2xl text-muted-foreground mb-8 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          Find meaningful connections based on shared interests, values, and compatibility
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
          <Link to="/dating/auth?tab=register">
            <Button size="lg" className="bg-pink-600 hover:bg-pink-700">
              Get Started
            </Button>
          </Link>
          <Link to="/dating/auth?tab=login">
            <Button size="lg" variant="outline" className="border-pink-200 text-pink-600 hover:text-pink-700">
              Sign In
            </Button>
          </Link>
        </div>
      </header>

      {/* Features Section */}
      <section className="container mx-auto py-12 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">How It Works</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our unique approach to dating focuses on meaningful connections and compatibility
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="border-pink-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-8 text-center">
              <div className="bg-pink-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Create Your Profile</h3>
              <p className="text-muted-foreground">
                Share your interests, preferences, and what makes you unique
              </p>
            </CardContent>
          </Card>

          <Card className="border-pink-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-8 text-center">
              <div className="bg-pink-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Find Your Match</h3>
              <p className="text-muted-foreground">
                Our algorithm identifies people who share your values and interests
              </p>
            </CardContent>
          </Card>

          <Card className="border-pink-100 hover:shadow-md transition-shadow">
            <CardContent className="pt-8 text-center">
              <div className="bg-pink-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-pink-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Connect & Date</h3>
              <p className="text-muted-foreground">
                Chat with your matches and find perfect date ideas for your first meeting
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Match Showcase Section */}
      <section className="bg-gradient-to-r from-pink-50 to-purple-50 py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Discover Your Perfect Match</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our compatibility quiz helps you find people who truly match with your personality
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Example Match Cards */}
            {[
              { name: 'Sarah', age: 28, location: 'New York', interests: ['Travel', 'Photography', 'Cooking'], matchScore: 92 },
              { name: 'Michael', age: 32, location: 'San Francisco', interests: ['Hiking', 'Music', 'Technology'], matchScore: 88 },
              { name: 'Emma', age: 26, location: 'Chicago', interests: ['Reading', 'Art', 'Fitness'], matchScore: 95 },
            ].map((profile, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="h-40 bg-gradient-to-r from-pink-200 to-purple-200 flex items-center justify-center">
                  <Avatar className="h-24 w-24">
                    <AvatarFallback>{profile.name[0]}</AvatarFallback>
                  </Avatar>
                </div>
                <CardContent className="pt-4">
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-pink-600">
                      {profile.matchScore}% Match
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-semibold">{profile.name}</h3>
                      <p className="text-muted-foreground">
                        {profile.age} • {profile.location}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mt-3">
                    {profile.interests.map((interest, i) => (
                      <Badge key={i} variant="outline" className="bg-muted text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/dating/auth?tab=register">
              <Button size="lg" className="bg-pink-600 hover:bg-pink-700">
                Find Your Match
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Date Ideas Section */}
      <section className="container mx-auto py-16 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Unique Date Ideas</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Browse our collection of creative date suggestions for every interest and budget
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {/* Example Date Idea Cards */}
          <Card className="overflow-hidden hover:shadow-md transition-shadow">
            <div className="h-48 bg-gradient-to-r from-amber-100 to-amber-200 flex items-center justify-center text-amber-800 text-xl font-medium">
              Food & Cuisine
            </div>
            <CardContent className="pt-4">
              <h3 className="text-xl font-semibold mb-2">Cooking Class Adventure</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Learn to cook a new cuisine together and enjoy the meal you've prepared.
              </p>
              <div className="flex items-center text-muted-foreground">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Perfect for food lovers</span>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden hover:shadow-md transition-shadow">
            <div className="h-48 bg-gradient-to-r from-green-100 to-green-200 flex items-center justify-center text-green-800 text-xl font-medium">
              Outdoors
            </div>
            <CardContent className="pt-4">
              <h3 className="text-xl font-semibold mb-2">Sunset Picnic</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Pack a basket with favorite snacks and enjoy a beautiful sunset together.
              </p>
              <div className="flex items-center text-muted-foreground">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Perfect for nature lovers</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Link to="/dating/date-ideas">
            <Button variant="outline" className="border-pink-200 text-pink-600 hover:text-pink-700">
              Explore All Date Ideas
            </Button>
          </Link>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-gradient-to-r from-pink-50 to-purple-50 py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Success Stories</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Hear from couples who found each other through our app
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-pink-100 hover:shadow-md transition-shadow">
              <CardContent className="pt-8">
                <div className="flex items-center mb-4">
                  <div className="flex -space-x-4 mr-4">
                    <Avatar className="border-2 border-white">
                      <AvatarFallback>J</AvatarFallback>
                    </Avatar>
                    <Avatar className="border-2 border-white">
                      <AvatarFallback>M</AvatarFallback>
                    </Avatar>
                  </div>
                  <div>
                    <h3 className="font-medium">James & Maria</h3>
                    <p className="text-sm text-muted-foreground">Matched 8 months ago</p>
                  </div>
                </div>
                <p className="text-muted-foreground italic">
                  "We would have never met without this app! Our compatibility score was 94% and it turns out
                  we were truly perfect for each other. Thank you for bringing us together!"
                </p>
              </CardContent>
            </Card>

            <Card className="border-pink-100 hover:shadow-md transition-shadow">
              <CardContent className="pt-8">
                <div className="flex items-center mb-4">
                  <div className="flex -space-x-4 mr-4">
                    <Avatar className="border-2 border-white">
                      <AvatarFallback>D</AvatarFallback>
                    </Avatar>
                    <Avatar className="border-2 border-white">
                      <AvatarFallback>A</AvatarFallback>
                    </Avatar>
                  </div>
                  <div>
                    <h3 className="font-medium">David & Ashley</h3>
                    <p className="text-sm text-muted-foreground">Matched 1 year ago</p>
                  </div>
                </div>
                <p className="text-muted-foreground italic">
                  "The compatibility quiz matched us because we both love hiking and board games. Our first date
                  was a picnic followed by a board game at a local café. Now we're engaged!"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto py-16 px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Ready to Find Your Perfect Match?</h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Join thousands of singles who have found meaningful relationships through It's A Date
        </p>

        <ul className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8 mb-8">
          <li className="flex items-center justify-center gap-2">
            <CheckCircle2 className="text-pink-600 h-5 w-5" />
            <span>Free to join</span>
          </li>
          <li className="flex items-center justify-center gap-2">
            <CheckCircle2 className="text-pink-600 h-5 w-5" />
            <span>Compatibility focused</span>
          </li>
          <li className="flex items-center justify-center gap-2">
            <CheckCircle2 className="text-pink-600 h-5 w-5" />
            <span>Date suggestions included</span>
          </li>
        </ul>

        <Link to="/dating/auth?tab=register">
          <Button size="lg" className="bg-pink-600 hover:bg-pink-700">
            Create Your Free Profile
          </Button>
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col items-center justify-center">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-2">
              It's A Date
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              Find your perfect match today
            </p>
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} It's A Date. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}