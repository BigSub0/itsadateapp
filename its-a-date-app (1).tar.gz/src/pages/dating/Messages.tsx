import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useMessages } from '@/contexts/MessagesContext';
import DatingNavigation from '@/components/layout/DatingNavigation';
import MessageList from '@/components/dating/MessageList';
import MessageInput from '@/components/dating/MessageInput';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Users, MessageSquare } from 'lucide-react';
import AnimatedPage from '@/components/AnimatedPage';

export default function Messages() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { 
    conversations,
    currentConversation,
    messages,
    loadingConversations,
    loadingMessages,
    selectConversation,
    sendMessage
  } = useMessages();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/dating/auth');
    }
  }, [user, navigate]);

  // Handle new message submission
  const handleSendMessage = async (content: string) => {
    return await sendMessage(content);
  };

  // Back to conversation list view
  const handleBackToConversations = () => {
    selectConversation('');
  };

  return (
    <AnimatedPage>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
        <DatingNavigation />
        
        <div className="container max-w-4xl mx-auto pt-8">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-pink-600 mb-2">Messages</h1>
            <p className="text-muted-foreground">
              Connect with your matches
            </p>
          </div>
          
          <Card className="overflow-hidden">
            {/* Mobile back button (only when viewing a conversation) */}
            {currentConversation && (
              <div className="block lg:hidden p-3 border-b">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleBackToConversations}
                  className="flex items-center text-sm"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to conversations
                </Button>
              </div>
            )}
            
            <div className="grid grid-cols-1 lg:grid-cols-3 h-[600px]">
              {/* Conversation List - Hide on mobile when viewing a conversation */}
              <div className={`border-r ${currentConversation ? 'hidden lg:block' : 'block'}`}>
                <div className="p-4 border-b">
                  <div className="flex items-center space-x-2 font-semibold text-pink-600">
                    <Users className="h-5 w-5" />
                    <h2>Conversations</h2>
                  </div>
                </div>
                
                <ScrollArea className="h-[540px]">
                  {loadingConversations ? (
                    <div className="p-4 text-center text-muted-foreground">
                      Loading conversations...
                    </div>
                  ) : conversations.length === 0 ? (
                    <div className="p-4 text-center text-muted-foreground">
                      No conversations yet. Match with someone to start chatting!
                    </div>
                  ) : (
                    conversations.map((conversation) => (
                      <React.Fragment key={conversation.id}>
                        <div
                          className={`p-4 hover:bg-muted cursor-pointer ${
                            currentConversation?.id === conversation.id ? 'bg-muted' : ''
                          }`}
                          onClick={() => selectConversation(conversation.id)}
                        >
                          <div className="flex items-start gap-3">
                            <div className="relative">
                              <img
                                src={conversation.participantImage || 'https://via.placeholder.com/40'}
                                alt={conversation.participantName}
                                className="w-10 h-10 rounded-full object-cover"
                              />
                              {conversation.unreadCount > 0 && (
                                <span className="absolute -top-1 -right-1 bg-pink-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                                  {conversation.unreadCount}
                                </span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex justify-between items-center">
                                <h3 className="font-medium truncate">{conversation.participantName}</h3>
                                {conversation.lastMessageTimestamp && (
                                  <span className="text-xs text-muted-foreground">
                                    {new Date(conversation.lastMessageTimestamp).toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </span>
                                )}
                              </div>
                              {conversation.lastMessage && (
                                <p className={`text-sm truncate ${conversation.unreadCount > 0 ? 'font-medium' : 'text-muted-foreground'}`}>
                                  {conversation.lastMessage}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        <Separator />
                      </React.Fragment>
                    ))
                  )}
                </ScrollArea>
              </div>
              
              {/* Message Thread - Show on mobile only when a conversation is selected */}
              <div className={`col-span-2 flex flex-col ${currentConversation ? 'block' : 'hidden lg:flex'}`}>
                {currentConversation ? (
                  <>
                    <div className="p-4 border-b flex items-center space-x-3">
                      <img
                        src={currentConversation.participantImage || 'https://via.placeholder.com/40'}
                        alt={currentConversation.participantName}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <h3 className="font-medium">{currentConversation.participantName}</h3>
                      </div>
                    </div>
                    
                    <MessageList 
                      messages={messages} 
                      loading={loadingMessages} 
                      currentUserId={user?.id || ''} 
                    />
                    
                    <MessageInput onSendMessage={handleSendMessage} />
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center p-4">
                    <div className="bg-muted rounded-full p-6 mb-4">
                      <MessageSquare className="h-12 w-12 text-pink-600 opacity-70" />
                    </div>
                    <h3 className="text-xl font-medium mb-2">Your Messages</h3>
                    <p className="text-muted-foreground max-w-xs">
                      Select a conversation from the list to view your messages
                    </p>
                  </div>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </AnimatedPage>
  );
}