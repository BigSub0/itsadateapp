import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import DatingNavigation from '@/components/layout/DatingNavigation';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, Calendar, UserRound, Sparkles, ArrowRight } from 'lucide-react';
import GameLink from '@/components/games/GameLink';

export default function Home() {
  const { user, logout } = useAuth();
  const { profile, isProfileComplete } = useProfile();
  const navigate = useNavigate();
  
  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/dating/auth');
    }
  }, [user, navigate]);

  const handleCompleteProfile = () => {
    navigate('/dating/profile');
  };
  
  const handleStartSurvey = () => {
    navigate('/dating/survey');
  };
  
  const handleViewMatches = () => {
    navigate('/dating/matches');
  };
  
  const handleExploreIdeas = () => {
    navigate('/dating/date-ideas');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <DatingNavigation />
      
      <div className="container max-w-4xl mx-auto pt-8 pb-20">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-pink-600 mb-2">Welcome to It's A Date</h1>
          {user && (
            <p className="text-xl font-medium">
              Hi, {user.name}!
            </p>
          )}
        </div>
        
        {profile && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Your Profile</CardTitle>
              {!profile.completed && (
                <CardDescription>Complete your profile to start matching</CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <div className="flex items-start gap-4">
                <Avatar className="h-16 w-16 border-2 border-pink-500">
                  {profile.imageUrl ? (
                    <AvatarImage src={profile.imageUrl} alt={profile.name} />
                  ) : (
                    <AvatarFallback><UserRound className="h-8 w-8" /></AvatarFallback>
                  )}
                </Avatar>
                <div className="flex-1">
                  <h3 className="text-lg font-medium">{profile.name}</h3>
                  
                  {profile.completed ? (
                    <>
                      <div className="text-muted-foreground flex flex-wrap gap-2 items-center mt-1 mb-2">
                        <span>{profile.age} years</span>
                        <span>•</span>
                        <span>{profile.location}</span>
                        {profile.gender && (
                          <>
                            <span>•</span>
                            <span>{profile.gender}</span>
                          </>
                        )}
                      </div>
                      
                      {profile.interests && profile.interests.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {profile.interests.slice(0, 5).map((interest, i) => (
                            <Badge key={i} variant="outline" className="bg-muted text-xs">
                              {interest}
                            </Badge>
                          ))}
                          {profile.interests.length > 5 && (
                            <Badge variant="outline" className="bg-muted text-xs">
                              +{profile.interests.length - 5} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <p className="text-muted-foreground mt-1 mb-2">
                      Your profile is incomplete. Add more details to improve your matches.
                    </p>
                  )}
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleCompleteProfile}
                    className="mt-2"
                  >
                    {profile.completed ? 'Edit Profile' : 'Complete Profile'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <GameLink />
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Heart className="mr-2 h-5 w-5 text-pink-500" />
                Find Matches
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                {isProfileComplete 
                  ? "Discover people who share your interests and might be your perfect match."
                  : "Complete your profile and take the compatibility quiz to find matches."
                }
              </p>
              <Button 
                onClick={handleViewMatches}
                className="w-full bg-pink-600 hover:bg-pink-700"
                disabled={!isProfileComplete}
              >
                View Matches
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-pink-500" />
                Date Ideas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Browse our collection of date ideas for inspiration on your next adventure together.
              </p>
              <Button 
                onClick={handleExploreIdeas}
                className="w-full bg-pink-600 hover:bg-pink-700"
              >
                Explore Date Ideas
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {!isProfileComplete && (
          <Card className="mb-8 border-pink-200 bg-pink-50">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Sparkles className="mr-2 h-5 w-5 text-pink-500" />
                Get Started
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-4 list-decimal ml-5">
                <li>
                  <p className="font-medium">Complete your profile</p>
                  <p className="text-muted-foreground">
                    Add photos and details about yourself to stand out
                  </p>
                </li>
                <li>
                  <p className="font-medium">Take the compatibility quiz</p>
                  <p className="text-muted-foreground">
                    Answer questions to help us find your perfect match
                  </p>
                </li>
                <li>
                  <p className="font-medium">Start matching</p>
                  <p className="text-muted-foreground">
                    Discover people who share your interests and values
                  </p>
                </li>
              </ol>
              
              <div className="mt-6">
                <Button 
                  onClick={handleCompleteProfile}
                  className="bg-pink-600 hover:bg-pink-700 w-full"
                >
                  Complete Your Profile
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {isProfileComplete && !profile?.completed && (
          <Card className="mb-8 border-pink-200 bg-pink-50">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Sparkles className="mr-2 h-5 w-5 text-pink-500" />
                Take the Compatibility Quiz
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Answer a few simple questions to help us find your perfect match based on compatibility.
              </p>
              <Button 
                onClick={handleStartSurvey}
                className="bg-pink-600 hover:bg-pink-700 w-full"
              >
                Start Quiz
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        )}
        
        <div className="text-center mt-12">
          <p className="text-sm text-muted-foreground mb-2">
            Not {user?.name}? Or want to start fresh?
          </p>
          <Button variant="ghost" size="sm" onClick={logout}>
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}