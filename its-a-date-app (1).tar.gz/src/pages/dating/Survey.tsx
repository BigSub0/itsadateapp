import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import SurveyQuestions from '@/components/dating/SurveyQuestions';
import DatingNavigation from '@/components/layout/DatingNavigation';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';

export default function Survey() {
  const { user } = useAuth();
  const { profile, isProfileComplete } = useProfile();
  const navigate = useNavigate();
  
  // Redirect if not logged in or profile not completed
  useEffect(() => {
    if (!user) {
      navigate('/dating/auth');
    } else if (!profile || !isProfileComplete) {
      navigate('/dating/profile');
    }
  }, [user, profile, isProfileComplete, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <DatingNavigation />
      
      <div className="container max-w-4xl mx-auto pt-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-pink-600 mb-2">Compatibility Quiz</h1>
          <p className="text-muted-foreground">
            Answer a few questions to help us find your perfect match
          </p>
        </div>
        
        <SurveyQuestions />
      </div>
    </div>
  );
}