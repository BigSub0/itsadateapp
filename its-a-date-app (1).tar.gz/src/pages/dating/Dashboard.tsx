import React, { useState, useEffect } from 'react';
import DatingNavigation from '@/components/layout/DatingNavigation';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import ProfileCard from '@/components/dating/ProfileCard';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Search, Filter, MapPin } from 'lucide-react';

// Sample data for user profiles
const sampleProfiles = [
  {
    id: '1',
    name: 'Jessica, 28',
    bio: 'Adventure seeker, coffee enthusiast, and amateur photographer. Looking for someone who enjoys exploring the outdoors.',
    location: 'Seattle, WA',
    distance: '5 miles away',
    interests: ['Travel', 'Photography', 'Hiking', 'Coffee'],
    photoUrl: '/assets/images/profile1.jpg',
    match: 85
  },
  {
    id: '2',
    name: 'Michael, 32',
    bio: 'Software developer by day, musician by night. I love trying new restaurants and going to live music events.',
    location: 'Portland, OR',
    distance: '8 miles away',
    interests: ['Music', 'Coding', 'Foodie', 'Concerts'],
    photoUrl: '/assets/images/profile2.jpg',
    match: 78
  },
  {
    id: '3',
    name: 'Emma, 26',
    bio: 'Book lover and yoga instructor. Looking for someone to share quiet evenings and deep conversations with.',
    location: 'Vancouver, WA',
    distance: '12 miles away',
    interests: ['Reading', 'Yoga', 'Meditation', 'Art'],
    photoUrl: '/assets/images/profile3.jpg',
    match: 92
  },
  {
    id: '4',
    name: 'Daniel, 30',
    bio: 'Avid runner and craft beer enthusiast. I work in finance and enjoy weekend getaways to the mountains.',
    location: 'Seattle, WA',
    distance: '3 miles away',
    interests: ['Running', 'Craft Beer', 'Hiking', 'Finance'],
    photoUrl: '/assets/images/profile4.jpg',
    match: 65
  },
  {
    id: '5',
    name: 'Olivia, 27',
    bio: 'Veterinarian who loves animals and nature. Looking for someone who shares my passion for the outdoors.',
    location: 'Bellevue, WA',
    distance: '10 miles away',
    interests: ['Animals', 'Nature', 'Veterinary', 'Camping'],
    photoUrl: '/assets/images/profile5.jpg',
    match: 88
  },
];

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [profiles, setProfiles] = useState(sampleProfiles);
  const [filteredProfiles, setFilteredProfiles] = useState(sampleProfiles);
  const [activeTab, setActiveTab] = useState('discover');
  
  // Filter profiles based on search term
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProfiles(profiles);
    } else {
      const filtered = profiles.filter(profile => 
        profile.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        profile.bio.toLowerCase().includes(searchTerm.toLowerCase()) ||
        profile.interests.some(interest => interest.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      setFilteredProfiles(filtered);
    }
  }, [searchTerm, profiles]);

  return (
    <div className="min-h-screen bg-gray-50">
      <DatingNavigation />
      
      <div className="container mx-auto p-4 md:p-6 mt-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
              {activeTab === 'discover' && 'Discover Matches'}
              {activeTab === 'matches' && 'Your Matches'}
              {activeTab === 'messages' && 'Conversations'}
            </h1>
            <p className="text-gray-600">
              {activeTab === 'discover' && 'Find people who share your interests'}
              {activeTab === 'matches' && 'People who liked you back'}
              {activeTab === 'messages' && 'Chat with your connections'}
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 w-full md:w-auto">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-10 pr-4 py-2 w-full md:w-[300px]"
                placeholder="Search by name, interests..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="border-b">
            <TabsList className="w-full justify-start h-12 bg-transparent p-0">
              <TabsTrigger 
                value="discover" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-pink-500 data-[state=active]:text-pink-500 rounded-none h-12 px-8"
              >
                Discover
              </TabsTrigger>
              <TabsTrigger 
                value="matches" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-pink-500 data-[state=active]:text-pink-500 rounded-none h-12 px-8"
              >
                Matches
              </TabsTrigger>
              <TabsTrigger 
                value="messages" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-pink-500 data-[state=active]:text-pink-500 rounded-none h-12 px-8"
              >
                Messages
              </TabsTrigger>
            </TabsList>
          </div>
          
          <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-pink-500" />
                <span className="text-sm text-gray-600">Seattle, WA • 25 miles</span>
              </div>
              
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span>Filters</span>
              </Button>
            </div>
            
            <TabsContent value="discover" className="mt-0 p-0 border-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProfiles.map(profile => (
                  <ProfileCard key={profile.id} profile={profile} />
                ))}
                
                {filteredProfiles.length === 0 && (
                  <div className="col-span-full py-12 text-center">
                    <div className="text-5xl mb-4">🔍</div>
                    <h3 className="text-xl font-medium mb-2">No matches found</h3>
                    <p className="text-gray-500">Try adjusting your filters or search terms</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="matches" className="mt-0 p-0 border-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProfiles
                  .filter(profile => profile.match > 80)
                  .map(profile => (
                    <ProfileCard key={profile.id} profile={profile} isMatch={true} />
                  ))
                }
                
                {filteredProfiles.filter(profile => profile.match > 80).length === 0 && (
                  <div className="col-span-full py-12 text-center">
                    <div className="text-5xl mb-4">💘</div>
                    <h3 className="text-xl font-medium mb-2">No matches yet</h3>
                    <p className="text-gray-500">Keep discovering to find your match</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="messages" className="mt-0 p-0 border-0">
              <Card>
                <CardContent className="p-6">
                  <div className="py-12 text-center">
                    <div className="text-5xl mb-4">💌</div>
                    <h3 className="text-xl font-medium mb-2">No messages yet</h3>
                    <p className="text-gray-500 mb-4">Start a conversation with one of your matches</p>
                    <Button onClick={() => setActiveTab('matches')} className="bg-pink-500 hover:bg-pink-600">
                      Go to Matches
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}