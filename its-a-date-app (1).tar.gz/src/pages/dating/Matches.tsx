import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DatingNavigation from '@/components/layout/DatingNavigation';
import MatchCard from '@/components/dating/MatchCard';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';
import { useMatching } from '@/contexts/MatchingContext';
import { Button } from '@/components/ui/button';
import { ArrowRight, SearchIcon, UserRoundX } from 'lucide-react';
import { Match, Profile } from '@/lib/dating-local-storage';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Matches() {
  const { user } = useAuth();
  const { profile, isProfileComplete } = useProfile();
  const { userMatches, matchProfiles, matchScores, findNewMatches, acceptMatch, rejectMatch, loading } = useMatching();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string>('potential');
  const [isSearching, setIsSearching] = useState(false);
  
  // Redirect if not logged in or profile not completed
  useEffect(() => {
    if (!user) {
      navigate('/dating/auth');
    } else if (!profile || !isProfileComplete) {
      navigate('/dating/profile');
    }
  }, [user, profile, isProfileComplete, navigate]);

  // Filter matches by status
  const pendingMatches = userMatches.filter(match => match.status === 'pending');
  const acceptedMatches = userMatches.filter(match => match.status === 'accepted');
  
  const handleSearch = async () => {
    setIsSearching(true);
    try {
      await findNewMatches();
    } finally {
      setIsSearching(false);
    }
  };

  const handleAccept = async (matchId: string) => {
    await acceptMatch(matchId);
  };

  const handleReject = async (matchId: string) => {
    await rejectMatch(matchId);
  };

  const handleMessage = (userId: string) => {
    // In a real app, this would open a chat with the user
    alert(`Chat functionality would open with user ${userId} in a real app.`);
  };

  // Get profile for a match
  const getProfileForMatch = (match: Match): Profile | null => {
    if (!user) return null;
    const otherUserId = match.user1Id === user.id ? match.user2Id : match.user1Id;
    return matchProfiles.get(otherUserId) || null;
  };

  // Get score for a profile
  const getScoreForProfile = (userId: string): number => {
    return matchScores.get(userId) || 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <DatingNavigation />
      
      <div className="container max-w-4xl mx-auto pt-8 pb-20">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-pink-600 mb-2">Your Matches</h1>
          <p className="text-muted-foreground">
            Discover people who might be your perfect match
          </p>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-8">
          <div className="flex justify-center">
            <TabsList>
              <TabsTrigger value="potential">
                Potential Matches ({pendingMatches.length})
              </TabsTrigger>
              <TabsTrigger value="accepted">
                Connected ({acceptedMatches.length})
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="potential" className="mt-6">
            {pendingMatches.length === 0 ? (
              <div className="text-center py-12">
                <UserRoundX className="mx-auto h-12 w-12 text-muted-foreground opacity-40 mb-4" />
                <h3 className="text-lg font-medium mb-2">No potential matches yet</h3>
                <p className="text-muted-foreground mb-6">
                  Click the button below to find new potential matches based on your profile and survey answers.
                </p>
                <Button 
                  onClick={handleSearch}
                  className="bg-pink-600 hover:bg-pink-700"
                  disabled={isSearching || loading}
                >
                  <SearchIcon className="mr-2 h-4 w-4" />
                  {isSearching ? 'Searching...' : 'Find New Matches'}
                </Button>
              </div>
            ) : (
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {pendingMatches.map(match => {
                    const profile = getProfileForMatch(match);
                    if (!profile) return null;
                    
                    return (
                      <MatchCard 
                        key={match.id}
                        profile={profile}
                        matchScore={match.matchScore}
                        match={match}
                        onAccept={handleAccept}
                        onReject={handleReject}
                      />
                    );
                  })}
                </div>
                <div className="mt-8 text-center">
                  <Button 
                    onClick={handleSearch}
                    variant="outline"
                    disabled={isSearching || loading}
                  >
                    <SearchIcon className="mr-2 h-4 w-4" />
                    {isSearching ? 'Searching...' : 'Find More Matches'}
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="accepted" className="mt-6">
            {acceptedMatches.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium mb-2">No connections yet</h3>
                <p className="text-muted-foreground mb-6">
                  When you and someone else both accept each other, you'll connect and can start chatting.
                </p>
                <Button 
                  onClick={() => setActiveTab('potential')} 
                  variant="outline"
                  className="border-pink-200 text-pink-600 hover:text-pink-700"
                >
                  View Potential Matches
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {acceptedMatches.map(match => {
                  const profile = getProfileForMatch(match);
                  if (!profile) return null;
                  
                  return (
                    <MatchCard 
                      key={match.id}
                      profile={profile}
                      matchScore={match.matchScore}
                      match={match}
                      isAccepted={true}
                      onMessage={handleMessage}
                    />
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}