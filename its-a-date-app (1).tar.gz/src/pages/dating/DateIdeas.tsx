import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DatingNavigation from '@/components/layout/DatingNavigation';
import DateIdeaCard from '@/components/dating/DateIdeaCard';
import EnhancedDateIdeaCard from '@/components/dating/EnhancedDateIdeaCard';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';
import { useMatching } from '@/contexts/MatchingContext';
import { DateIdea } from '@/lib/dating-local-storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FilterIcon, SearchIcon } from 'lucide-react';

export default function DateIdeas() {
  const { user } = useAuth();
  const { profile } = useProfile();
  const { filteredDateIdeas, filterDateIdeas, dateIdeas } = useMatching();
  const navigate = useNavigate();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedCost, setSelectedCost] = useState<number | undefined>(undefined);
  const [showFilters, setShowFilters] = useState(false);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/dating/auth');
    }
  }, [user, navigate]);
  
  // Apply filters
  useEffect(() => {
    filterDateIdeas(selectedCategory || undefined, selectedCost);
  }, [selectedCategory, selectedCost, filterDateIdeas]);
  
  // Get unique categories from date ideas
  const categories = Array.from(new Set(dateIdeas.map(idea => idea.category)));
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality here
  };
  
  const handlePlanDate = (dateIdea: DateIdea) => {
    // In a real app, this would allow scheduling the date with a match
    alert(`In a real app, you would be able to schedule "${dateIdea.title}" with one of your matches.`);
  };
  
  // Filter date ideas by search term
  const displayDateIdeas = searchTerm
    ? filteredDateIdeas.filter(idea => 
        idea.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        idea.description.toLowerCase().includes(searchTerm.toLowerCase()))
    : filteredDateIdeas;

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <DatingNavigation />
      
      <div className="container max-w-6xl mx-auto pt-8 pb-20">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-pink-600 mb-2">Date Ideas</h1>
          <p className="text-muted-foreground">
            Find inspiration for your next adventure together
          </p>
        </div>
        
        <div className="mb-6">
          <form onSubmit={handleSearch} className="flex gap-2 mb-4">
            <Input
              placeholder="Search date ideas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/80"
            />
            <Button type="submit" variant="ghost" size="icon">
              <SearchIcon className="h-4 w-4" />
            </Button>
            <Button 
              type="button" 
              variant="ghost" 
              size="icon"
              onClick={() => setShowFilters(!showFilters)}
              className={showFilters ? "bg-pink-100 text-pink-700" : ""}
            >
              <FilterIcon className="h-4 w-4" />
            </Button>
          </form>
          
          {showFilters && (
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Category</label>
                    <Select 
                      value={selectedCategory} 
                      onValueChange={setSelectedCategory}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All categories</SelectItem>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Price Range</label>
                    <Select 
                      value={selectedCost?.toString() || ''} 
                      onValueChange={(value) => setSelectedCost(value ? parseInt(value, 10) : undefined)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Any price" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any price</SelectItem>
                        <SelectItem value="1">$ (Budget friendly)</SelectItem>
                        <SelectItem value="2">$$ (Mid-range)</SelectItem>
                        <SelectItem value="3">$$$ (Luxury)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  {selectedCategory && (
                    <Badge variant="outline" className="bg-muted">
                      Category: {selectedCategory}
                      <button 
                        className="ml-2 text-muted-foreground hover:text-foreground"
                        onClick={() => setSelectedCategory('')}
                      >
                        ✕
                      </button>
                    </Badge>
                  )}
                  
                  {selectedCost !== undefined && (
                    <Badge variant="outline" className="bg-muted">
                      Price: {'$'.repeat(selectedCost)}
                      <button 
                        className="ml-2 text-muted-foreground hover:text-foreground"
                        onClick={() => setSelectedCost(undefined)}
                      >
                        ✕
                      </button>
                    </Badge>
                  )}
                  
                  {(selectedCategory || selectedCost !== undefined) && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => {
                        setSelectedCategory('');
                        setSelectedCost(undefined);
                      }}
                      className="text-xs text-muted-foreground hover:text-foreground"
                    >
                      Clear all
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        {displayDateIdeas.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium mb-2">No date ideas found</h3>
            <p className="text-muted-foreground mb-4">
              Try adjusting your filters or search terms.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('');
                setSelectedCost(undefined);
              }}
            >
              Clear filters
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayDateIdeas.map(dateIdea => (
              <EnhancedDateIdeaCard 
                key={dateIdea.id}
                dateIdea={dateIdea}
                onSelect={() => handlePlanDate(dateIdea)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}