import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import RegisterForm from '@/components/dating/RegisterForm';
import LoginForm from '@/components/dating/LoginForm';
import { useAuth } from '@/contexts/AuthContext';
import DatingNavigation from '@/components/layout/DatingNavigation';

export default function Auth() {
  const [activeTab, setActiveTab] = useState<string>('login');
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // Check if user is already logged in
  useEffect(() => {
    if (user) {
      navigate('/dating');
    }
  }, [user, navigate]);
  
  // Set active tab based on URL params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get('tab');
    if (tab === 'register' || tab === 'login') {
      setActiveTab(tab);
    }
  }, [location]);
  
  // Update URL when tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    navigate(`/dating/auth?tab=${value}`);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <div className="container max-w-md mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-pink-600 mb-2">It's A Date</h1>
          <p className="text-muted-foreground">Your journey to meaningful connections begins here</p>
        </div>
        
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          <TabsContent value="login">
            <LoginForm />
          </TabsContent>
          <TabsContent value="register">
            <RegisterForm />
          </TabsContent>
        </Tabs>
      </div>
      
      <Card className="mt-8 max-w-md mx-auto p-4 bg-white/80 backdrop-blur-sm">
        <div className="text-sm text-center text-muted-foreground">
          <p>By continuing, you agree to our Terms of Service and Privacy Policy.</p>
          <p className="mt-2">
            All user data is stored locally in your browser for this demo.
          </p>
        </div>
      </Card>
    </div>
  );
}