import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import MatchingCardGame from '@/components/games/MatchingCardGame';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Heart } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const MemoryGame: React.FC = () => {
  // Game settings
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [theme, setTheme] = useState<'love' | 'dating' | 'couples'>('love');
  const [gameActive, setGameActive] = useState<boolean>(false);
  
  // High scores
  const [highScores, setHighScores] = useState<Array<{
    score: number;
    time: number;
    difficulty: string;
    date: string;
  }>>([]);

  const handleDifficultyChange = (value: string) => {
    setDifficulty(value as 'easy' | 'medium' | 'hard');
  };

  const handleThemeChange = (value: string) => {
    setTheme(value as 'love' | 'dating' | 'couples');
  };

  const startGame = () => {
    setGameActive(true);
  };

  const handleGameComplete = (score: number, time: number) => {
    const newScore = {
      score,
      time,
      difficulty,
      date: new Date().toLocaleDateString()
    };
    
    // Add to high scores and sort
    const updatedScores = [...highScores, newScore]
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
    
    setHighScores(updatedScores);
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <Helmet>
        <title>Memory Game | It's A Date</title>
      </Helmet>
      
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Memory Match Game</h1>
        <p className="text-muted-foreground mt-2">
          Test your memory while you wait for your next match
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="shadow-lg">
            <CardHeader className="bg-gradient-to-r from-pink-100 to-purple-100">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Heart className="h-5 w-5 mr-2 text-pink-500" /> 
                  Memory Match
                </CardTitle>
                {!gameActive && (
                  <Button onClick={startGame}>Start Game</Button>
                )}
              </div>
              <CardDescription>
                Find all matching pairs to win. The faster you complete with fewer moves, the higher your score!
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              {!gameActive ? (
                <div className="flex flex-col items-center space-y-6">
                  <div className="w-full max-w-md space-y-4">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Select Difficulty</h3>
                      <RadioGroup 
                        defaultValue={difficulty} 
                        onValueChange={handleDifficultyChange}
                        className="flex flex-col space-y-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="easy" id="easy" />
                          <Label htmlFor="easy">Easy (6 pairs)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="medium" id="medium" />
                          <Label htmlFor="medium">Medium (8 pairs)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="hard" id="hard" />
                          <Label htmlFor="hard">Hard (12 pairs)</Label>
                        </div>
                      </RadioGroup>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Select Theme</h3>
                      <Select 
                        defaultValue={theme} 
                        onValueChange={handleThemeChange}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a theme" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="love">Hearts & Love</SelectItem>
                          <SelectItem value="dating">Dating Activities</SelectItem>
                          <SelectItem value="couples">Couples</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="pt-4">
                      <Button onClick={startGame} className="w-full">Start Game</Button>
                    </div>
                  </div>
                  
                  <div className="w-full max-w-md my-8">
                    <h3 className="text-lg font-medium mb-2">How to Play</h3>
                    <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                      <li>Click on a card to flip it over</li>
                      <li>Try to find the matching pair for each card</li>
                      <li>When you find a pair, they'll stay flipped</li>
                      <li>Complete the game by finding all pairs</li>
                      <li>Fewer moves and less time result in higher scores</li>
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="py-4">
                  <MatchingCardGame
                    difficulty={difficulty}
                    theme={theme}
                    onGameComplete={handleGameComplete}
                  />
                  
                  <div className="mt-6 text-center">
                    <Button variant="outline" onClick={() => setGameActive(false)}>
                      Back to Options
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-1">
          <Tabs defaultValue="highscores">
            <TabsList className="w-full">
              <TabsTrigger value="highscores" className="flex-1">High Scores</TabsTrigger>
              <TabsTrigger value="rewards" className="flex-1">Rewards</TabsTrigger>
            </TabsList>
            <TabsContent value="highscores">
              <Card>
                <CardHeader>
                  <CardTitle>Your High Scores</CardTitle>
                  <CardDescription>
                    Beat your previous records
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {highScores.length > 0 ? (
                    <div className="space-y-4">
                      {highScores.map((score, index) => (
                        <div key={index} className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">{score.score} points</div>
                            <div className="text-sm text-muted-foreground">
                              {score.difficulty} • {score.date}
                            </div>
                          </div>
                          <div className="text-sm">
                            {Math.floor(score.time / 60)}:{(score.time % 60).toString().padStart(2, '0')}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Complete a game to see your scores here!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="rewards">
              <Card>
                <CardHeader>
                  <CardTitle>Game Rewards</CardTitle>
                  <CardDescription>
                    Earn points for your dating profile
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-3 rounded-md">
                      <div className="font-medium">Complete 5 games</div>
                      <div className="text-sm text-muted-foreground">
                        Earn the "Fun & Games" badge on your profile
                      </div>
                    </div>
                    <Separator />
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-3 rounded-md">
                      <div className="font-medium">Score over 500 points</div>
                      <div className="text-sm text-muted-foreground">
                        Boost your profile visibility for 24 hours
                      </div>
                    </div>
                    <Separator />
                    <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-3 rounded-md">
                      <div className="font-medium">Top the leaderboard</div>
                      <div className="text-sm text-muted-foreground">
                        Get a free premium date idea suggestion
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default MemoryGame;