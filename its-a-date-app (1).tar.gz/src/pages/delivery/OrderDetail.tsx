import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { ChevronLeft, MapPin, Clock, Package, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import MainNavigation from '@/components/layout/MainNavigation';
import { useDelivery } from '@/hooks/useDelivery';
import { Order } from '@/lib/delivery/localStorage';
import OrderItem from '@/components/delivery/OrderItem';

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { orders, updateOrderStatus } = useDelivery();
  const { toast } = useToast();
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (id) {
      const foundOrder = orders.find(o => o.id === id);
      if (foundOrder) {
        setOrder(foundOrder);
      } else {
        toast({
          title: "Order Not Found",
          description: "We couldn't find the order you're looking for",
          variant: "destructive",
        });
        navigate('/delivery');
      }
    }
  }, [id, orders, navigate, toast]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
    }).format(date);
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'preparing':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'out-for-delivery':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'canceled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'confirmed':
        return 'Order Confirmed';
      case 'preparing':
        return 'Preparing Your Food';
      case 'out-for-delivery':
        return 'Out for Delivery';
      case 'delivered':
        return 'Delivered';
      case 'canceled':
        return 'Canceled';
      default:
        return status;
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle2 className="h-5 w-5 mr-2" />;
      case 'out-for-delivery':
        return <MapPin className="h-5 w-5 mr-2" />;
      case 'preparing':
        return <Package className="h-5 w-5 mr-2" />;
      case 'canceled':
        return <XCircle className="h-5 w-5 mr-2" />;
      case 'pending':
        return <AlertCircle className="h-5 w-5 mr-2" />;
      default:
        return <Clock className="h-5 w-5 mr-2" />;
    }
  };

  const handleCancelOrder = () => {
    if (!order) return;
    
    // Only allow cancellation for pending or confirmed orders
    if (order.status !== 'pending' && order.status !== 'confirmed') {
      toast({
        title: "Cannot Cancel Order",
        description: "This order is already being prepared or delivered.",
        variant: "destructive",
      });
      return;
    }
    
    updateOrderStatus(order.id, 'canceled');
    
    toast({
      title: "Order Canceled",
      description: "Your order has been successfully canceled.",
    });
  };

  // For demo purposes, let's add a function to update the order status
  const handleUpdateOrderStatus = (newStatus: Order['status']) => {
    if (!order) return;
    updateOrderStatus(order.id, newStatus);
    
    toast({
      title: "Order Updated",
      description: `Order status updated to ${getStatusText(newStatus)}`,
    });
  };

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MainNavigation currentApp="delivery" />
        <div className="container mx-auto py-12 px-4">
          <div className="text-center">
            <p className="text-gray-500">Loading order details...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNavigation currentApp="delivery" />
      
      <div className="container mx-auto py-6 px-4">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate('/delivery')}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Orders
        </Button>
        
        {/* Order Status */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Order #{order.id}</h1>
          <div className="flex flex-wrap items-center gap-4">
            <Badge 
              className={`${getStatusColor(order.status)} px-3 py-1 text-sm flex items-center`}
              variant="outline"
            >
              {getStatusIcon(order.status)}
              {getStatusText(order.status)}
            </Badge>
            <span className="text-gray-500">
              Placed on {formatDate(order.placedAt)}
            </span>
          </div>
        </div>
        
        {/* Order Progress - Only show for active orders */}
        {order.status !== 'delivered' && order.status !== 'canceled' && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="font-semibold text-lg mb-6">Order Status</h2>
              <div className="relative">
                {/* Progress bar */}
                <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-gray-200" />
                
                {/* Status steps */}
                <div className="space-y-8">
                  <div className="flex items-start relative">
                    <div className={`rounded-full h-14 w-14 flex items-center justify-center z-10 ${
                      ['confirmed', 'preparing', 'out-for-delivery', 'delivered'].includes(order.status)
                        ? 'bg-green-100 text-green-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      <CheckCircle2 className="h-6 w-6" />
                    </div>
                    <div className="ml-6">
                      <h3 className="font-medium">Order Confirmed</h3>
                      <p className="text-sm text-gray-500">
                        {order.status === 'confirmed' 
                          ? 'Your order has been received and is being processed.' 
                          : 'Your order has been confirmed.'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start relative">
                    <div className={`rounded-full h-14 w-14 flex items-center justify-center z-10 ${
                      ['preparing', 'out-for-delivery', 'delivered'].includes(order.status)
                        ? 'bg-blue-100 text-blue-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      <Package className="h-6 w-6" />
                    </div>
                    <div className="ml-6">
                      <h3 className="font-medium">Preparing Your Food</h3>
                      <p className="text-sm text-gray-500">
                        {order.status === 'preparing' 
                          ? 'The restaurant is preparing your order now.' 
                          : order.status === 'pending' || order.status === 'confirmed' 
                            ? 'Your food will be prepared soon.' 
                            : 'Your food has been prepared.'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start relative">
                    <div className={`rounded-full h-14 w-14 flex items-center justify-center z-10 ${
                      ['out-for-delivery', 'delivered'].includes(order.status)
                        ? 'bg-purple-100 text-purple-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      <MapPin className="h-6 w-6" />
                    </div>
                    <div className="ml-6">
                      <h3 className="font-medium">Out for Delivery</h3>
                      <p className="text-sm text-gray-500">
                        {order.status === 'out-for-delivery' 
                          ? 'Your order is on the way!' 
                          : order.status === 'delivered' 
                            ? 'Your order has been delivered.' 
                            : 'Your order will be delivered soon.'}
                      </p>
                      {order.status === 'out-for-delivery' && (
                        <p className="text-sm font-medium mt-1">
                          Estimated delivery by {formatDate(order.estimatedDelivery)}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-start relative">
                    <div className={`rounded-full h-14 w-14 flex items-center justify-center z-10 ${
                      order.status === 'delivered'
                        ? 'bg-green-100 text-green-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      <CheckCircle2 className="h-6 w-6" />
                    </div>
                    <div className="ml-6">
                      <h3 className="font-medium">Delivered</h3>
                      <p className="text-sm text-gray-500">
                        {order.status === 'delivered' 
                          ? 'Your order has been delivered. Enjoy your meal!' 
                          : 'Your order will be delivered soon.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Order Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Items */}
            <Card>
              <CardContent className="p-6">
                <h2 className="font-semibold text-lg mb-4">Order Items</h2>
                <div className="space-y-4">
                  {order.items.map((item, index) => (
                    <div key={index} className="pb-4">
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <div className="flex items-center">
                            <span className="font-medium">{item.quantity}×</span>
                            <h3 className="ml-2 font-medium">{item.menuItem.name}</h3>
                          </div>
                          
                          {/* Options */}
                          {item.options && item.options.length > 0 && (
                            <div className="ml-6 text-sm text-gray-500 mt-1">
                              {item.options.map((option, i) => (
                                <div key={i}>
                                  {option.name}: {option.choice.name}
                                  {option.choice.price > 0 && ` (+$${option.choice.price.toFixed(2)})`}
                                </div>
                              ))}
                            </div>
                          )}
                          
                          {/* Special instructions */}
                          {item.specialInstructions && (
                            <div className="ml-6 mt-1 text-xs italic text-gray-500">
                              "{item.specialInstructions}"
                            </div>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="font-medium">
                            ${((item.menuItem.price * item.quantity) + 
                              ((item.options?.reduce((sum, opt) => sum + opt.choice.price, 0) || 0) * item.quantity)).toFixed(2)}
                          </p>
                        </div>
                      </div>
                      {index < order.items.length - 1 && <Separator className="mt-4" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Restaurant Info */}
            <Card>
              <CardContent className="p-6">
                <h2 className="font-semibold text-lg mb-4">Restaurant</h2>
                <div className="flex items-center">
                  <div className="h-12 w-12 rounded-md bg-orange-100 flex items-center justify-center text-orange-500 mr-3">
                    {order.restaurantName.substring(0, 1)}
                  </div>
                  <div>
                    <p className="font-medium">{order.restaurantName}</p>
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-orange-500"
                      onClick={() => navigate(`/delivery/restaurant/${order.restaurantId}`)}
                    >
                      View Restaurant
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Actions */}
            {(order.status === 'pending' || order.status === 'confirmed') && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="font-semibold text-lg mb-4">Order Actions</h2>
                  <div className="flex flex-wrap gap-4">
                    <Button 
                      variant="destructive" 
                      onClick={handleCancelOrder}
                    >
                      Cancel Order
                    </Button>
                    
                    {/* For demo purposes only - buttons to update order status */}
                    <div className="hidden">
                      <Button onClick={() => handleUpdateOrderStatus('preparing')}>
                        Mark as Preparing
                      </Button>
                      <Button onClick={() => handleUpdateOrderStatus('out-for-delivery')}>
                        Mark as Out for Delivery
                      </Button>
                      <Button onClick={() => handleUpdateOrderStatus('delivered')}>
                        Mark as Delivered
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          {/* Order Summary */}
          <div>
            <Card className="sticky top-6">
              <CardContent className="p-6">
                <h2 className="font-semibold text-lg mb-4">Order Summary</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>${order.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax</span>
                    <span>${order.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Delivery Fee</span>
                    <span>${order.deliveryFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tip</span>
                    <span>${order.tip.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>${order.total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Delivery Address */}
            <Card className="mt-6">
              <CardContent className="p-6">
                <h2 className="font-semibold text-lg mb-4">Delivery Address</h2>
                <div className="flex">
                  <MapPin className="h-5 w-5 text-gray-500 mr-2 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-600">
                    {order.address.street}, {order.address.city}, {order.address.state} {order.address.zipCode}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Payment Method */}
            <Card className="mt-6">
              <CardContent className="p-6">
                <h2 className="font-semibold text-lg mb-4">Payment Method</h2>
                <div className="flex items-center">
                  {order.paymentMethod.type === 'credit' && (
                    <div className="h-9 w-14 bg-blue-100 rounded flex items-center justify-center text-blue-700 mr-3">
                      CC
                    </div>
                  )}
                  {order.paymentMethod.type === 'debit' && (
                    <div className="h-9 w-14 bg-green-100 rounded flex items-center justify-center text-green-700 mr-3">
                      DB
                    </div>
                  )}
                  {order.paymentMethod.type === 'paypal' && (
                    <div className="h-9 w-14 bg-blue-100 rounded flex items-center justify-center text-blue-700 mr-3">
                      PP
                    </div>
                  )}
                  {order.paymentMethod.type === 'cash' && (
                    <div className="h-9 w-14 bg-gray-100 rounded flex items-center justify-center text-gray-700 mr-3">
                      💵
                    </div>
                  )}
                  <div>
                    <p>
                      {order.paymentMethod.type === 'credit' && 'Credit Card'}
                      {order.paymentMethod.type === 'debit' && 'Debit Card'}
                      {order.paymentMethod.type === 'paypal' && 'PayPal'}
                      {order.paymentMethod.type === 'cash' && 'Cash on Delivery'}
                    </p>
                    {order.paymentMethod.last4 && (
                      <p className="text-sm text-gray-500">
                        **** **** **** {order.paymentMethod.last4}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}