import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { ChevronLeft, Star, Clock, Heart, Package, Search, Plus, Minus } from 'lucide-react';
import MainNavigation from '@/components/layout/MainNavigation';
import { useDelivery } from '@/hooks/useDelivery';
import { MenuItem, Restaurant } from '@/lib/delivery/localStorage';
import CartPanel from '@/components/delivery/CartPanel';

// Mock data for restaurants and menu items
const mockRestaurants: Record<string, Restaurant> = {
  '1': {
    id: '1',
    name: 'Burger Palace',
    cuisine: 'American',
    rating: 4.5,
    deliveryTime: '15-25 min',
    deliveryFee: '$2.99',
    imageUrl: '/assets/restaurants/burger.jpg',
    tags: ['Burgers', 'Fast Food', 'American']
  },
  '2': {
    id: '2',
    name: 'Pizza Heaven',
    cuisine: 'Italian',
    rating: 4.7,
    deliveryTime: '20-30 min',
    deliveryFee: '$1.99',
    imageUrl: '/assets/restaurants/pizza.jpg',
    tags: ['Pizza', 'Italian', 'Vegetarian options']
  },
  '3': {
    id: '3',
    name: 'Sushi Express',
    cuisine: 'Japanese',
    rating: 4.8,
    deliveryTime: '25-35 min',
    deliveryFee: '$3.99',
    imageUrl: '/assets/restaurants/sushi.jpg',
    tags: ['Sushi', 'Japanese', 'Healthy']
  },
  '4': {
    id: '4',
    name: 'Taco Fiesta',
    cuisine: 'Mexican',
    rating: 4.3,
    deliveryTime: '15-25 min',
    deliveryFee: '$2.49',
    imageUrl: '/assets/restaurants/taco.jpg',
    tags: ['Mexican', 'Tacos', 'Spicy']
  }
};

// Mock menu items for restaurants
const mockMenuItems: Record<string, MenuItem[]> = {
  '1': [
    {
      id: 'burger1',
      restaurantId: '1',
      name: 'Classic Cheeseburger',
      description: 'Angus beef patty with cheddar cheese, lettuce, tomato, and special sauce',
      price: 8.99,
      imageUrl: '/assets/menu/cheeseburger.jpg',
      category: 'Burgers',
      popular: true,
      options: [
        {
          name: 'Size',
          choices: [
            { name: 'Regular', price: 0 },
            { name: 'Double Patty', price: 3 }
          ]
        },
        {
          name: 'Add-ons',
          choices: [
            { name: 'Bacon', price: 1.5 },
            { name: 'Avocado', price: 2 },
            { name: 'Fried Egg', price: 1 }
          ]
        }
      ]
    },
    {
      id: 'burger2',
      restaurantId: '1',
      name: 'BBQ Bacon Burger',
      description: 'Angus beef patty with smoked bacon, BBQ sauce, cheddar cheese, and onion rings',
      price: 10.99,
      imageUrl: '/assets/menu/bbq-burger.jpg',
      category: 'Burgers',
      popular: true,
      options: [
        {
          name: 'Size',
          choices: [
            { name: 'Regular', price: 0 },
            { name: 'Double Patty', price: 3 }
          ]
        }
      ]
    },
    {
      id: 'fries1',
      restaurantId: '1',
      name: 'French Fries',
      description: 'Crispy golden fries with sea salt',
      price: 3.99,
      imageUrl: '/assets/menu/fries.jpg',
      category: 'Sides',
      options: [
        {
          name: 'Size',
          choices: [
            { name: 'Regular', price: 0 },
            { name: 'Large', price: 1.5 }
          ]
        },
        {
          name: 'Seasoning',
          choices: [
            { name: 'Plain', price: 0 },
            { name: 'Cajun', price: 0.5 },
            { name: 'Garlic Parmesan', price: 0.5 }
          ]
        }
      ]
    },
    {
      id: 'shake1',
      restaurantId: '1',
      name: 'Chocolate Shake',
      description: 'Rich and creamy chocolate milkshake topped with whipped cream',
      price: 4.99,
      imageUrl: '/assets/menu/chocolate-shake.jpg',
      category: 'Drinks',
      options: [
        {
          name: 'Size',
          choices: [
            { name: 'Regular', price: 0 },
            { name: 'Large', price: 1 }
          ]
        }
      ]
    }
  ],
  // Add menu items for other restaurants as needed
  '2': [
    {
      id: 'pizza1',
      restaurantId: '2',
      name: 'Margherita Pizza',
      description: 'Classic pizza with tomato sauce, mozzarella, and basil',
      price: 12.99,
      imageUrl: '/assets/menu/margherita.jpg',
      category: 'Pizzas',
      vegetarian: true,
      options: [
        {
          name: 'Size',
          choices: [
            { name: 'Medium (12")', price: 0 },
            { name: 'Large (16")', price: 4 }
          ]
        },
        {
          name: 'Crust',
          choices: [
            { name: 'Regular', price: 0 },
            { name: 'Thin Crust', price: 0 },
            { name: 'Stuffed Crust', price: 2.5 }
          ]
        }
      ]
    }
  ]
};

export default function RestaurantDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, { name: string; price: number }>>({});
  const [quantity, setQuantity] = useState<number>(1);
  const [specialInstructions, setSpecialInstructions] = useState<string>('');
  
  const { addToCart, isFavorite, addToFavorites, removeFromFavorites, cart, getCartItemCount, setCurrentRestaurant } = useDelivery();
  const { toast } = useToast();

  // Fetch restaurant and menu items
  useEffect(() => {
    if (id) {
      const foundRestaurant = mockRestaurants[id];
      if (foundRestaurant) {
        setRestaurant(foundRestaurant);
        setCurrentRestaurant(foundRestaurant);
        
        const foundMenuItems = mockMenuItems[id] || [];
        setMenuItems(foundMenuItems);
        
        // Set the first category as active if we have menu items
        if (foundMenuItems.length > 0) {
          const categories = Array.from(new Set(foundMenuItems.map(item => item.category)));
          setActiveCategory(categories[0]);
        }
      } else {
        // Restaurant not found
        toast({
          title: "Restaurant Not Found",
          description: "We couldn't find the restaurant you're looking for",
          variant: "destructive",
        });
        navigate('/delivery');
      }
    }
  }, [id, navigate, toast]);
  
  // Get unique categories from menu items
  const categories = Array.from(new Set(menuItems.map(item => item.category)));
  
  // Filter menu items by search term
  const filteredMenuItems = searchTerm 
    ? menuItems.filter(item => 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : menuItems;
  
  // Get menu items by category
  const getItemsByCategory = (category: string) => {
    return filteredMenuItems.filter(item => item.category === category);
  };
  
  // Handle adding item to cart
  const handleAddToCart = () => {
    if (!selectedItem) return;
    
    // Format options for cart item
    const formattedOptions = selectedItem.options?.map(option => ({
      name: option.name,
      choice: selectedOptions[option.name] || option.choices[0]
    }));
    
    // Create cart item
    const cartItem = {
      menuItem: selectedItem,
      quantity: quantity,
      options: formattedOptions,
      specialInstructions: specialInstructions.trim() || undefined
    };
    
    // Add to cart
    addToCart(cartItem);
    
    // Reset state
    setSelectedItem(null);
    setSelectedOptions({});
    setQuantity(1);
    setSpecialInstructions('');
  };
  
  // Handle option selection
  const handleOptionChange = (optionName: string, choice: { name: string; price: number }) => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionName]: choice
    }));
  };
  
  // Calculate item price with selected options
  const calculateItemPrice = () => {
    if (!selectedItem) return 0;
    
    let total = selectedItem.price;
    
    // Add option prices
    Object.values(selectedOptions).forEach(choice => {
      total += choice.price;
    });
    
    return total * quantity;
  };
  
  // Toggle favorite
  const toggleFavorite = () => {
    if (!restaurant) return;
    
    if (isFavorite(restaurant.id)) {
      removeFromFavorites(restaurant.id);
    } else {
      addToFavorites(restaurant.id);
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <MainNavigation currentApp="delivery" />
      
      {/* Cart Panel */}
      {isCartOpen && <CartPanel isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />}
      
      {/* Restaurant Header */}
      {restaurant && (
        <div className="relative">
          {/* Restaurant Image */}
          <div className="h-48 sm:h-64 overflow-hidden relative">
            {restaurant.imageUrl ? (
              <img 
                src={restaurant.imageUrl}
                alt={restaurant.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://placehold.co/800x400/orange/white?text=Restaurant+Image';
                }}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500">
                {restaurant.name}
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-transparent" />
          </div>
          
          {/* Back Button */}
          <Button
            variant="outline"
            size="icon"
            className="absolute top-4 left-4 bg-white/80 hover:bg-white rounded-full shadow-sm"
            onClick={() => navigate('/delivery')}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          {/* Favorite Button */}
          <Button
            variant="outline"
            size="icon"
            className={`absolute top-4 right-4 ${
              isFavorite(restaurant.id) 
                ? 'bg-red-50 text-red-500 hover:bg-red-100 hover:text-red-600' 
                : 'bg-white/80 hover:bg-white'
            } rounded-full shadow-sm`}
            onClick={toggleFavorite}
          >
            <Heart className={`h-4 w-4 ${isFavorite(restaurant.id) ? 'fill-current' : ''}`} />
          </Button>
          
          {/* Restaurant Info */}
          <div className="container mx-auto px-4 -mt-16 relative">
            <Card className="mb-6">
              <CardContent className="p-6">
                <h1 className="text-2xl font-bold mb-2">{restaurant.name}</h1>
                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge variant="outline">{restaurant.cuisine}</Badge>
                  {restaurant.tags.map((tag, i) => (
                    <Badge key={i} variant="outline">{tag}</Badge>
                  ))}
                </div>
                
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 mr-1" />
                    <span>{restaurant.rating}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-muted-foreground mr-1" />
                    <span>{restaurant.deliveryTime}</span>
                  </div>
                  <div className="flex items-center">
                    <Package className="h-4 w-4 text-muted-foreground mr-1" />
                    <span>Delivery: {restaurant.deliveryFee}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
      
      {/* Menu */}
      <div className="container mx-auto px-4 pb-20">
        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search menu items..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        {/* Categories and Menu Items */}
        {categories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Categories Sidebar */}
            <div className="hidden md:block">
              <Card className="sticky top-20">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-1">
                    {categories.map((category) => (
                      <Button
                        key={category}
                        variant={activeCategory === category ? "default" : "ghost"}
                        className="w-full justify-start"
                        onClick={() => setActiveCategory(category)}
                      >
                        {category}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Menu Items */}
            <div className="md:col-span-3">
              {/* Mobile Categories */}
              <ScrollArea className="md:hidden">
                <div className="flex space-x-2 pb-4">
                  {categories.map((category) => (
                    <Button
                      key={category}
                      variant={activeCategory === category ? "default" : "outline"}
                      onClick={() => setActiveCategory(category)}
                      className="whitespace-nowrap"
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              </ScrollArea>
              
              {/* Menu Items By Category */}
              {searchTerm ? (
                <div>
                  <h2 className="text-xl font-medium mb-4">Search Results</h2>
                  {filteredMenuItems.length > 0 ? (
                    <div className="space-y-4">
                      {filteredMenuItems.map((item) => (
                        <Card 
                          key={item.id}
                          className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
                          onClick={() => setSelectedItem(item)}
                        >
                          <div className="flex p-4">
                            <div className="flex-1 pr-4">
                              <h3 className="font-medium">{item.name}</h3>
                              <p className="text-sm text-gray-500 line-clamp-2 mt-1">{item.description}</p>
                              <div className="mt-2">
                                <span className="font-medium">${item.price.toFixed(2)}</span>
                                {item.popular && (
                                  <Badge variant="outline" className="ml-2 bg-orange-100 text-orange-700 border-orange-200">
                                    Popular
                                  </Badge>
                                )}
                              </div>
                            </div>
                            {item.imageUrl && (
                              <div className="h-16 w-16 rounded overflow-hidden">
                                <img 
                                  src={item.imageUrl}
                                  alt={item.name}
                                  className="h-full w-full object-cover"
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.src = 'https://placehold.co/200x200/orange/white?text=Food';
                                  }}
                                />
                              </div>
                            )}
                          </div>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-gray-500">No items found matching "{searchTerm}"</p>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {categories.map((category) => (
                    <div key={category} id={category} className="mb-8" style={{ display: activeCategory === category || !activeCategory ? 'block' : 'none' }}>
                      <h2 className="text-xl font-medium mb-4">{category}</h2>
                      <div className="space-y-4">
                        {getItemsByCategory(category).map((item) => (
                          <Card 
                            key={item.id}
                            className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
                            onClick={() => setSelectedItem(item)}
                          >
                            <div className="flex p-4">
                              <div className="flex-1 pr-4">
                                <h3 className="font-medium">{item.name}</h3>
                                <p className="text-sm text-gray-500 line-clamp-2 mt-1">{item.description}</p>
                                <div className="mt-2">
                                  <span className="font-medium">${item.price.toFixed(2)}</span>
                                  {item.popular && (
                                    <Badge variant="outline" className="ml-2 bg-orange-100 text-orange-700 border-orange-200">
                                      Popular
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              {item.imageUrl && (
                                <div className="h-16 w-16 rounded overflow-hidden">
                                  <img 
                                    src={item.imageUrl}
                                    alt={item.name}
                                    className="h-full w-full object-cover"
                                    onError={(e) => {
                                      const target = e.target as HTMLImageElement;
                                      target.src = 'https://placehold.co/200x200/orange/white?text=Food';
                                    }}
                                  />
                                </div>
                              )}
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        ) : (
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <p className="text-gray-500">No menu items available</p>
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Floating Cart Button */}
      {cart.length > 0 && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2">
          <Button 
            className="shadow-lg px-6 py-6 bg-orange-500 hover:bg-orange-600"
            size="lg"
            onClick={() => setIsCartOpen(true)}
          >
            <div className="absolute -top-3 -right-3 bg-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-medium text-orange-500 shadow-sm border-2 border-orange-500">
              {getCartItemCount()}
            </div>
            <span>View Cart • ${cart.length > 0 ? `${(cart.reduce((acc, item) => {
              const itemPrice = item.menuItem.price;
              const optionsPrice = item.options?.reduce((sum, opt) => sum + opt.choice.price, 0) || 0;
              return acc + ((itemPrice + optionsPrice) * item.quantity);
            }, 0)).toFixed(2)}` : '0.00'}</span>
          </Button>
        </div>
      )}
      
      {/* Item Detail Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedItem?.name}</DialogTitle>
          </DialogHeader>
          
          {selectedItem && (
            <div className="space-y-4">
              {/* Item Image */}
              {selectedItem.imageUrl && (
                <div className="h-48 overflow-hidden rounded-md">
                  <img 
                    src={selectedItem.imageUrl}
                    alt={selectedItem.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = 'https://placehold.co/600x400/orange/white?text=Food+Image';
                    }}
                  />
                </div>
              )}
              
              {/* Item Description */}
              <p className="text-sm text-gray-500">{selectedItem.description}</p>
              
              {/* Item Tags */}
              <div className="flex flex-wrap gap-2">
                {selectedItem.vegetarian && (
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    Vegetarian
                  </Badge>
                )}
                {selectedItem.spicy && (
                  <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                    Spicy
                  </Badge>
                )}
                {selectedItem.popular && (
                  <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
                    Popular
                  </Badge>
                )}
              </div>
              
              <Separator />
              
              {/* Options */}
              {selectedItem.options && selectedItem.options.length > 0 && (
                <div className="space-y-4">
                  {selectedItem.options.map((option, optionIndex) => (
                    <div key={optionIndex}>
                      <h4 className="font-medium mb-2">{option.name}</h4>
                      <RadioGroup
                        value={
                          selectedOptions[option.name] 
                            ? JSON.stringify(selectedOptions[option.name]) 
                            : JSON.stringify(option.choices[0])
                        }
                        onValueChange={(value) => {
                          const choice = JSON.parse(value);
                          handleOptionChange(option.name, choice);
                        }}
                      >
                        <div className="space-y-2">
                          {option.choices.map((choice, choiceIndex) => (
                            <div key={choiceIndex} className="flex items-center justify-between">
                              <div className="flex items-center">
                                <RadioGroupItem 
                                  value={JSON.stringify(choice)} 
                                  id={`${option.name}-${choiceIndex}`} 
                                />
                                <Label htmlFor={`${option.name}-${choiceIndex}`} className="ml-2">
                                  {choice.name}
                                </Label>
                              </div>
                              {choice.price > 0 && (
                                <span className="text-sm">+${choice.price.toFixed(2)}</span>
                              )}
                            </div>
                          ))}
                        </div>
                      </RadioGroup>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Special Instructions */}
              <div>
                <h4 className="font-medium mb-2">Special Instructions (Optional)</h4>
                <Textarea 
                  placeholder="Any special requests or allergies?"
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  className="resize-none"
                  maxLength={200}
                />
              </div>
              
              {/* Quantity */}
              <div>
                <h4 className="font-medium mb-2">Quantity</h4>
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={quantity <= 1}
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="mx-4 font-medium">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button className="w-full" size="lg" onClick={handleAddToCart}>
              Add to Cart - ${calculateItemPrice().toFixed(2)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}