import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import MainNavigation from '@/components/layout/MainNavigation';
import RestaurantCard from '@/components/delivery/RestaurantCard';

// Mock data for restaurants
const mockRestaurants = [
  {
    id: '1',
    name: 'Burger Palace',
    cuisine: 'American',
    rating: 4.5,
    deliveryTime: '15-25 min',
    deliveryFee: '$2.99',
    imageUrl: '/assets/restaurants/burger.jpg',
    tags: ['Burgers', 'Fast Food', 'American']
  },
  {
    id: '2',
    name: 'Pizza Heaven',
    cuisine: 'Italian',
    rating: 4.7,
    deliveryTime: '20-30 min',
    deliveryFee: '$1.99',
    imageUrl: '/assets/restaurants/pizza.jpg',
    tags: ['Pizza', 'Italian', 'Vegetarian options']
  },
  {
    id: '3',
    name: 'Sushi Express',
    cuisine: 'Japanese',
    rating: 4.8,
    deliveryTime: '25-35 min',
    deliveryFee: '$3.99',
    imageUrl: '/assets/restaurants/sushi.jpg',
    tags: ['Sushi', 'Japanese', 'Healthy']
  },
  {
    id: '4',
    name: 'Taco Fiesta',
    cuisine: 'Mexican',
    rating: 4.3,
    deliveryTime: '15-25 min',
    deliveryFee: '$2.49',
    imageUrl: '/assets/restaurants/taco.jpg',
    tags: ['Mexican', 'Tacos', 'Spicy']
  }
];

export default function DeliveryDashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('restaurants');

  const filteredRestaurants = mockRestaurants.filter(
    restaurant => 
      restaurant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      restaurant.cuisine.toLowerCase().includes(searchTerm.toLowerCase()) ||
      restaurant.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNavigation currentApp="delivery" />
      
      <div className="container mx-auto py-6 px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-orange-600 mb-4 md:mb-0">Food Delivery</h1>
          
          <div className="w-full md:w-1/3">
            <Input
              type="text"
              placeholder="Search for restaurants, cuisines, etc."
              className="w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="restaurants" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="restaurants">Restaurants</TabsTrigger>
            <TabsTrigger value="orders">My Orders</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>
          
          <TabsContent value="restaurants">
            {filteredRestaurants.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredRestaurants.map((restaurant) => (
                  <RestaurantCard key={restaurant.id} restaurant={restaurant} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-10">
                  <p className="text-gray-500">No restaurants found matching "{searchTerm}"</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="orders">
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <p className="text-2xl font-semibold text-gray-400 mb-4">No active orders</p>
                <Button onClick={() => setActiveTab('restaurants')}>Browse Restaurants</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="favorites">
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <p className="text-2xl font-semibold text-gray-400 mb-4">No favorite restaurants yet</p>
                <Button onClick={() => setActiveTab('restaurants')}>Browse Restaurants</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}