import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import GameBoard from "@/components/game/GameBoard";
import GameControls from "@/components/game/GameControls";
import ScoreDisplay from "@/components/game/ScoreDisplay";
import GameOverDialog from "@/components/game/GameOverDialog";
import useSnakeGame from "@/hooks/useSnakeGame";

const SnakeGame: React.FC = () => {
  const {
    board,
    snake,
    food,
    direction,
    score,
    gameOver,
    isPaused,
    highScore,
    setDirection,
    startGame,
    pauseGame,
    resumeGame,
    restartGame,
  } = useSnakeGame();

  // Handle keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault();
      
      switch (e.key) {
        case "ArrowUp":
          if (direction !== "DOWN") setDirection("UP");
          break;
        case "ArrowDown":
          if (direction !== "UP") setDirection("DOWN");
          break;
        case "ArrowLeft":
          if (direction !== "RIGHT") setDirection("LEFT");
          break;
        case "ArrowRight":
          if (direction !== "LEFT") setDirection("RIGHT");
          break;
        case " ": // Space bar to pause/resume
          if (gameOver) {
            restartGame();
          } else if (isPaused) {
            resumeGame();
          } else {
            pauseGame();
          }
          break;
        default:
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [direction, isPaused, gameOver, setDirection, pauseGame, resumeGame, restartGame]);

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-center text-3xl">Snake Game</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <ScoreDisplay score={score} highScore={highScore} />
            
            {!gameOver && (
              <Button 
                onClick={isPaused ? resumeGame : pauseGame}
                variant="outline"
              >
                {isPaused ? "Resume Game" : "Pause Game"}
              </Button>
            )}
            
            {(gameOver || isPaused) && (
              <Button 
                onClick={gameOver ? restartGame : resumeGame}
                variant="default"
                className="bg-green-600 hover:bg-green-700"
              >
                {gameOver ? "New Game" : "Resume"}
              </Button>
            )}
          </div>
          
          <div className="relative">
            <GameBoard 
              board={board}
              snake={snake}
              food={food}
              isPaused={isPaused}
            />
            
            {isPaused && !gameOver && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                <div className="bg-white p-4 rounded-md shadow-md">
                  <p className="text-xl font-bold">Game Paused</p>
                  <p className="text-sm mt-2">Press Space or Resume to continue</p>
                </div>
              </div>
            )}
          </div>
          
          <div className="mt-6">
            <GameControls 
              onDirectionChange={setDirection}
              direction={direction}
              isPaused={isPaused}
              onPause={pauseGame}
              onResume={resumeGame}
            />
          </div>
        </CardContent>
      </Card>
      
      {gameOver && (
        <GameOverDialog
          score={score}
          highScore={highScore}
          onRestart={restartGame}
          isOpen={gameOver}
        />
      )}
    </div>
  );
};

export default SnakeGame;