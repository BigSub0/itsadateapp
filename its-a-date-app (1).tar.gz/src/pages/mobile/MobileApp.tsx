import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import TrackingView from './TrackingView';
import BottomNav from '@/components/mobile/BottomNav';

const MobileApp: React.FC = () => {
  const location = useLocation();
  const isRoot = location.pathname === '/' || location.pathname === '/mobile';
  
  // Render the main mobile app content
  return (
    <div className="h-[100dvh] w-full flex flex-col bg-gray-50">
      <div className="flex-1 overflow-y-auto pb-16">
        <Routes>
          <Route path="/" element={
            <div className="flex flex-col items-center justify-center p-4 h-full">
              <h1 className="text-2xl font-bold mb-6">Courier App</h1>
              <p className="text-center mb-8">Welcome to the Vital Xpress Courier App</p>
              <Button 
                className="w-full mb-4" 
                size="lg"
                asChild
              >
                <a href="/tracking">Go to Live Tracking</a>
              </Button>
            </div>
          } />
          <Route path="/tracking" element={<TrackingView />} />
          <Route path="/*" element={<div>Route not found</div>} />
        </Routes>
      </div>
      
      {isRoot && <BottomNav />}
    </div>
  );
};

export default MobileApp;