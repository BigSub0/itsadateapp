import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Route as RouteIcon, 
  Package,
  AlertCircle, 
  CheckCircle,
  RefreshCcw, 
  Truck,
  ChevronRight
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SimpleTrackingMap from '@/components/map/SimpleTrackingMap';
import { demoDeliveries, demoDrivers, updateDriverLocation } from '@/lib/demo-data';
import BottomNav from '@/components/mobile/BottomNav';

// Define interfaces for our data types
interface DeliveryLocation {
  id: string;
  address: string;
  lat: number;
  lng: number;
  priority?: number;
  status?: 'pending' | 'in-progress' | 'completed';
  timeWindow?: {
    start: number;
    end: number;
  };
}

interface DriverLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  lastUpdated: number;
}

const TrackingView: React.FC = () => {
  // State for online/offline status
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [activeTab, setActiveTab] = useState<string>('live');
  
  // State for driver and delivery data
  const [driverLocation, setDriverLocation] = useState<DriverLocation | null>(null);
  const [deliveries, setDeliveries] = useState<DeliveryLocation[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [locationUpdateCount, setLocationUpdateCount] = useState<number>(0);
  
  // Listen for online/offline events
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load demo data and simulate location updates
  useEffect(() => {
    setIsLoading(true);
    
    // Load demo data
    const loadData = () => {
      // Use the first driver
      const driver = demoDrivers[0];
      setDriverLocation(driver);
      
      // Get all deliveries
      setDeliveries(demoDeliveries);
      
      setIsLoading(false);
    };
    
    loadData();
    
    // Set up interval to simulate driver movement
    const locationInterval = setInterval(() => {
      setDriverLocation(prevLocation => {
        if (!prevLocation) return null;
        
        // Update driver location with small random movement
        const updatedLocation = updateDriverLocation(prevLocation);
        return updatedLocation;
      });
      
      setLocationUpdateCount(prevCount => prevCount + 1);
    }, 5000); // Update every 5 seconds
    
    return () => {
      clearInterval(locationInterval);
    };
  }, []);

  // Format relative time
  const getRelativeTimeString = (timestamp: number): string => {
    const now = Date.now();
    const diffInSeconds = Math.floor((now - timestamp) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds} sec ago`;
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)} min ago`;
    } else {
      return `${Math.floor(diffInSeconds / 3600)} hr ago`;
    }
  };

  // Get ETA in minutes
  const getEta = (delivery: DeliveryLocation): number => {
    if (!delivery.timeWindow) return 30;
    
    const now = Date.now();
    const etaMinutes = Math.floor((delivery.timeWindow.end - now) / (1000 * 60));
    
    return Math.max(1, etaMinutes);
  };

  // Simple Route Visualization tab content
  const RouteTab = () => (
    <div className="p-4 space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col items-center justify-center text-center h-56">
          <RouteIcon size={48} className="text-primary opacity-20 mb-4" />
          <h3 className="font-medium">Route Optimization</h3>
          <p className="text-sm text-muted-foreground mt-2">
            Optimized route planning available in the full version.
          </p>
          <Button size="sm" variant="outline" className="mt-4">
            Learn More
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  // Loading state
  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 h-[100dvh]">
        <RefreshCcw className="h-8 w-8 animate-spin mb-4 text-primary" />
        <p className="text-muted-foreground">Loading tracking data...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-background pb-16">
      {/* Status bar */}
      <div className="sticky top-0 z-10 bg-background border-b px-4 py-2 flex items-center justify-between">
        <h1 className="text-lg font-semibold flex items-center">
          <Truck size={18} className="mr-2" />
          Live Tracking
        </h1>
        <div className="flex items-center">
          {isOnline ? (
            <Badge variant="outline" className="bg-green-100 text-green-800">
              <CheckCircle size={12} className="mr-1" /> Online
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
              <AlertCircle size={12} className="mr-1" /> Offline
            </Badge>
          )}
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Tracking status */}
        <Card>
          <CardHeader className="py-3 px-4">
            <CardTitle className="text-base">Tracking Status</CardTitle>
          </CardHeader>
          <CardContent className="px-4 py-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-sm text-muted-foreground">Driver</span>
                <p className="font-medium">{driverLocation?.name || 'Unknown'}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Updates</span>
                <p className="font-medium">{locationUpdateCount}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Deliveries</span>
                <p className="font-medium">{deliveries.filter(d => d.status !== 'completed').length}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Completed</span>
                <p className="font-medium">{deliveries.filter(d => d.status === 'completed').length}</p>
              </div>
            </div>
            
            {driverLocation && (
              <div className="mt-3 pt-3 border-t">
                <span className="text-sm text-muted-foreground">Last Update</span>
                <p className="font-medium flex items-center">
                  <MapPin size={14} className="mr-1" />
                  {getRelativeTimeString(driverLocation.lastUpdated)}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Maps with tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="live" className="flex items-center gap-1">
              <MapPin size={14} />
              Live Map
            </TabsTrigger>
            <TabsTrigger value="route" className="flex items-center gap-1">
              <RouteIcon size={14} />
              Route
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="live" className="mt-2">
            <div className="h-72">
              {driverLocation && (
                <SimpleTrackingMap 
                  driverLocation={driverLocation} 
                  deliveryLocations={deliveries}
                  isOnline={isOnline} 
                  className="h-full"
                />
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="route" className="mt-2">
            <RouteTab />
          </TabsContent>
        </Tabs>
        
        {/* Delivery list */}
        <Card>
          <CardHeader className="py-3 px-4">
            <CardTitle className="text-base flex items-center">
              <Package size={16} className="mr-2" />
              Deliveries
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 py-0">
            <div className="divide-y">
              {deliveries.length === 0 ? (
                <p className="py-4 text-center text-muted-foreground">No deliveries assigned</p>
              ) : (
                deliveries.map((delivery) => (
                  <div key={delivery.id} className="py-3 flex items-center justify-between">
                    <div>
                      <p className="font-medium">{delivery.address}</p>
                      <div className="flex items-center mt-1">
                        {delivery.status === 'completed' ? (
                          <Badge variant="outline" className="bg-green-100 text-green-800">
                            <CheckCircle size={12} className="mr-1" /> Completed
                          </Badge>
                        ) : delivery.status === 'in-progress' ? (
                          <Badge variant="outline" className="bg-blue-100 text-blue-800">
                            <Truck size={12} className="mr-1" /> In Transit
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-100 text-gray-800">
                            <Package size={12} className="mr-1" /> Pending
                          </Badge>
                        )}
                        {delivery.status !== 'completed' && (
                          <span className="ml-2 text-xs text-muted-foreground">
                            ETA: {getEta(delivery)} min
                          </span>
                        )}
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="h-8 w-8 p-0"
                    >
                      <ChevronRight size={16} />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
};

export default TrackingView;