import { useDeliveryContext } from '@/contexts/DeliveryContext';
import { CartItem, MenuItem } from '@/lib/delivery/localStorage';

/**
 * Custom hook that provides access to the delivery context
 * with additional utility functions
 */
export function useDelivery() {
  const context = useDeliveryContext();
  
  /**
   * Create a new cart item from a menu item
   * @param menuItem - The menu item to add to cart
   * @param quantity - Quantity (defaults to 1)
   * @param options - Selected options for the item
   * @param specialInstructions - Special instructions for preparation
   */
  const createCartItem = (
    menuItem: MenuItem, 
    quantity: number = 1,
    options?: { name: string; choice: { name: string; price: number } }[],
    specialInstructions?: string
  ): CartItem => {
    return {
      menuItem,
      quantity,
      options,
      specialInstructions
    };
  };

  /**
   * Calculate the price of a menu item with its selected options
   * @param menuItem - The menu item 
   * @param options - Selected options for the item
   * @param quantity - Quantity (defaults to 1)
   */
  const calculateItemPrice = (
    menuItem: MenuItem,
    options?: { name: string; choice: { name: string; price: number } }[],
    quantity: number = 1
  ): number => {
    const basePrice = menuItem.price;
    const optionsPrice = options?.reduce((sum, opt) => sum + opt.choice.price, 0) || 0;
    return (basePrice + optionsPrice) * quantity;
  };

  /**
   * Check if there are items in the cart from multiple restaurants
   */
  const hasMultipleRestaurants = (): boolean => {
    if (context.cart.length <= 1) return false;
    
    const firstRestaurantId = context.cart[0]?.menuItem.restaurantId;
    return context.cart.some(item => item.menuItem.restaurantId !== firstRestaurantId);
  };

  /**
   * Get the number of items in the cart
   */
  const getCartItemCount = (): number => {
    return context.cart.reduce((count, item) => count + item.quantity, 0);
  };

  return {
    ...context,
    createCartItem,
    calculateItemPrice,
    hasMultipleRestaurants,
    getCartItemCount,
  };
}