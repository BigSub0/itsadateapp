// src/hooks/useMobileDetect.ts
import { useState, useEffect } from 'react';

interface MobileDetectOptions {
  forceMode?: 'mobile' | 'desktop' | null;
}

interface MobileDetectResult {
  isMobile: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  isStandalone: boolean;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  isCapacitor: boolean;
}

export const useMobileDetect = (options?: MobileDetectOptions): MobileDetectResult => {
  const [result, setResult] = useState<MobileDetectResult>({
    isMobile: false,
    isIOS: false,
    isAndroid: false,
    isStandalone: false,
    deviceType: 'desktop',
    isCapacitor: false
  });

  useEffect(() => {
    // Force specific mode if provided in options
    if (options?.forceMode) {
      setResult({
        isMobile: options.forceMode === 'mobile',
        isIOS: false,
        isAndroid: false,
        isStandalone: false,
        deviceType: options.forceMode === 'mobile' ? 'mobile' : 'desktop',
        isCapacitor: false
      });
      return;
    }

    // Check if we're running inside a Capacitor app
    const isCapacitor = typeof (window as Record<string, unknown>).Capacitor !== 'undefined';

    // Get user agent
    const userAgent = navigator.userAgent || navigator.vendor || (window as Record<string, unknown>).opera || '';
    
    // Check for iOS devices
    const isIOS = /iPad|iPhone|iPod/.test(userAgent) && !(window as Record<string, unknown>).MSStream;
    
    // Check for Android devices
    const isAndroid = /android/i.test(userAgent);
    
    // Check if it's a mobile device
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent) || 
                    (window.innerWidth <= 768);
                    
    // Check if it's running as a PWA (in standalone mode)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                        (window.navigator as Record<string, unknown>).standalone ||
                        document.referrer.includes('android-app://');
    
    // Determine device type based on screen width and user agent
    let deviceType: 'mobile' | 'tablet' | 'desktop' = 'desktop';
    
    if (isMobile) {
      if (window.innerWidth >= 600 && (
          /tablet|ipad/i.test(userAgent) || 
          (isAndroid && !/mobile/i.test(userAgent)) ||
          window.innerWidth >= 768
        )) {
        deviceType = 'tablet';
      } else {
        deviceType = 'mobile';
      }
    }

    setResult({
      isMobile,
      isIOS,
      isAndroid,
      isStandalone,
      deviceType,
      isCapacitor
    });
  }, [options?.forceMode]);

  return result;
};