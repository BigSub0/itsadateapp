// src/hooks/useCamera.ts
import { useState, useCallback } from 'react';

// Mock interfaces for Capacitor Camera API
enum CameraResultType {
  Uri = 'uri',
  Base64 = 'base64',
  DataUrl = 'dataUrl'
}

enum CameraSource {
  Prompt = 'PROMPT',
  Camera = 'CAMERA',
  Photos = 'PHOTOS'
}

interface Photo {
  base64String?: string;
  dataUrl?: string;
  format?: string;
  saved?: boolean;
  path?: string;
  webPath?: string;
}

// Mock Camera implementation for web development
const Camera = {
  checkPermissions: async () => ({ camera: 'granted' }),
  getPhoto: async (options: CameraOptions): Promise<Photo> => {
    // For web, return placeholder image
    return {
      dataUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEHUlEQVR4nO2dS2tdVRSAvxYrPqpWrfUB+gP8EXUgTnTiwFHFas1AnDjQWREEHSgURHEidqCC4CvWgeBAqFartmILVhGhKEVaa31U26at0XgtJDcS09x7zt177bXv+mC95Jy91vrmZJ+19z5ni+M4juM4juMEwGwdYhnwEvAZcBY4C5wG9gMPGMQvJFpXV+tMq/c54EVgXuog5bIQ2Al0gH+o5gpwCFieMkg5rAB+JF+A0dwA+oCW9mBDpwV8TrEYo/kOuFt7wCHzKnCddDFG8z6wSHvQIXI38BN6UUZyGHhIe+ChsZbJrQ+T4RKwWXvwodAC+vEjZCzfAvO1AxQCq4Hz6N/8kP3KDmAN2rRafWh/10JgI7BQO6QGa6kezuj+zCngb+BlYCdwSCFEsjnFnZqE3pjrZ4GvgB3AV8DFBEP4VaE7Nd5aOKLQMNvc8/5XqVZgWXTcuxZ0p0av2cBfCg3ra9DV8+CYesVyRkF7aoxlvcJJ9fca9eM/Ld5R0J4ao3lLoVkvTEA/njfGKxa5xPSHQrM+qFk/y7GsKCOzlVGDekacdPMK5UcF7amRmXvJnw++Nw1wyZRjWZYGled30wCXTDmWZWl8QKFRxzWGu2TKsSwNjiU0qstm4DFgHlWC93KFs19POZZl5bvEA1k3Sp9PUA3YtR33hyiWZeX5RKFJLzK1j253HuALpXIsy8I+hQat7VH/YIL+/Ve1Y1lW/BBsgIsNaOavdHbJlGNZVqb/EprzdYP6Z5L0b12OZVkYX+FslgcT9HEqx7Ks3MG5RKFBRxLo70jQ51SOZemGeEVB/2iCfs8k6Hcqx7J0Q2xX0O9NpB+VI3Isy/gvx/VcNeAP7YY3g2Mw/aG/RkE/Hjda0G5484mKN2pnoN2kRnMceEK7YZPEZWBrPyPaTWoWXwCbtBvXBH4HXqPqXbvhr2Wla6ZVZpQqX/U+VVbGp1R5WBepHrKdAX4BfqD6GvMT4ENgC/Ao1RtB8SUYvAi8QZV67Y2IknBKRnGcMVmc4ung9gnIWZyOoW1V8mjPYDRXgScVdYtkMdDTGHG0F8rieDrhudmImXl9EdwYcbQXzOLYUdIgRagZHzumJY52A1gcu0oaZBI153K5hjjaDWFxvF3SQB6n2qkwn3jaC8viOAM8XtKrluPARvI35Is5NpW41UExNpY03BO96Nzwb0bPZ+rwcEnDHk/PPzcp2DeXNPTR9GrypknaO0oa/mh6YQZvmqTdnlDkZOxNknCDTE9YbP5xoL2koWeSdEWeL+nnhTIz1hXs6HHm+Bc/PGlgYkLQSEMOLGXutn+kZoeFo6O/toTKydYHmNNEHj2ps6mUw7CxyS+hsuS3c86jJ7/QPT+UxHGcgvgXEYdDpqR+IqEAAAAASUVORK5CYII='
    };
  }
};

interface CameraOptions {
  quality?: number;
  resultType?: CameraResultType;
  saveToGallery?: boolean;
  source?: CameraSource;
  width?: number;
  height?: number;
  correctOrientation?: boolean;
  presentationStyle?: 'fullscreen' | 'popover';
}

interface CameraHookReturn {
  takePicture: (options?: CameraOptions) => Promise<Photo>;
  selectImage: (options?: CameraOptions) => Promise<Photo>;
  lastPhoto: string | null;
  cameraError: Error | null;
  isCameraAvailable: boolean;
}

export const useCamera = (): CameraHookReturn => {
  const [lastPhoto, setLastPhoto] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<Error | null>(null);
  const [isCameraAvailable, setIsCameraAvailable] = useState<boolean>(true);

  // Check camera permissions when hook is initialized
  useCallback(async () => {
    try {
      const { camera } = await Camera.checkPermissions();
      setIsCameraAvailable(camera === 'granted' || camera === 'prompt');
    } catch (error) {
      console.error('Camera permission check failed:', error);
      setIsCameraAvailable(false);
      setCameraError(error instanceof Error ? error : new Error('Unknown camera error'));
    }
  }, [])();

  // Take a picture using the device camera
  const takePicture = async (options?: CameraOptions): Promise<Photo> => {
    setCameraError(null);
    
    try {
      const defaultOptions: CameraOptions = {
        quality: 90,
        resultType: CameraResultType.DataUrl,
        saveToGallery: false,
        source: CameraSource.Camera,
        correctOrientation: true
      };

      const mergedOptions = { ...defaultOptions, ...options };
      
      const photo = await Camera.getPhoto(mergedOptions);
      
      if (photo.dataUrl) {
        setLastPhoto(photo.dataUrl);
      }
      
      return photo;
    } catch (error) {
      console.error('Error taking picture:', error);
      const cameraError = error instanceof Error ? error : new Error('Failed to take picture');
      setCameraError(cameraError);
      throw cameraError;
    }
  };

  // Select an image from the gallery
  const selectImage = async (options?: CameraOptions): Promise<Photo> => {
    setCameraError(null);
    
    try {
      const defaultOptions: CameraOptions = {
        quality: 90,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Photos,
        correctOrientation: true
      };

      const mergedOptions = { ...defaultOptions, ...options };
      
      const photo = await Camera.getPhoto(mergedOptions);
      
      if (photo.dataUrl) {
        setLastPhoto(photo.dataUrl);
      }
      
      return photo;
    } catch (error) {
      console.error('Error selecting image:', error);
      const imageError = error instanceof Error ? error : new Error('Failed to select image');
      setCameraError(imageError);
      throw imageError;
    }
  };

  return {
    takePicture,
    selectImage,
    lastPhoto,
    cameraError,
    isCameraAvailable
  };
};