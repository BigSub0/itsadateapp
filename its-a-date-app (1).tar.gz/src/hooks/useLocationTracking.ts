import { useState, useEffect } from 'react';

// Interface for location tracking
interface Location {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

// Options for the location tracking hook
interface LocationTrackingOptions {
  enableHighAccuracy?: boolean;
  maximumAge?: number;
  timeout?: number;
  trackingInterval?: number;
}

// Return type for the useLocationTracking hook
interface LocationTrackingResult {
  currentLocation: Location | null;
  locationHistory: Location[];
  error: string | null;
  isTracking: boolean;
  startTracking: () => void;
  stopTracking: () => void;
}

/**
 * A hook for real-time location tracking
 */
export function useLocationTracking({
  enableHighAccuracy = true,
  maximumAge = 10000,
  timeout = 5000,
  trackingInterval = 10000, // Default to update every 10 seconds
}: LocationTrackingOptions = {}): LocationTrackingResult {
  // State for the current location
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  // State for location history
  const [locationHistory, setLocationHistory] = useState<Location[]>([]);
  // State for any errors
  const [error, setError] = useState<string | null>(null);
  // State for tracking status
  const [isTracking, setIsTracking] = useState<boolean>(false);
  // Reference to the interval
  const [trackingIntervalId, setTrackingIntervalId] = useState<number | null>(null);

  // Function to get the current position
  const getCurrentPosition = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        const timestamp = position.timestamp;
        
        const newLocation: Location = {
          lat: latitude,
          lng: longitude,
          accuracy,
          timestamp,
        };
        
        setCurrentLocation(newLocation);
        setLocationHistory(prev => [...prev, newLocation]);
        setError(null);
      },
      (err) => {
        setError(`Error getting location: ${err.message}`);
      },
      {
        enableHighAccuracy,
        maximumAge,
        timeout,
      }
    );
  };

  // Function to start tracking
  const startTracking = () => {
    if (isTracking) return;
    
    setIsTracking(true);
    getCurrentPosition(); // Get position immediately
    
    // Set up interval for continuous tracking
    const intervalId = window.setInterval(() => {
      getCurrentPosition();
    }, trackingInterval);
    
    setTrackingIntervalId(intervalId);
  };

  // Function to stop tracking
  const stopTracking = () => {
    if (trackingIntervalId !== null) {
      clearInterval(trackingIntervalId);
      setTrackingIntervalId(null);
    }
    setIsTracking(false);
  };

  // Clean up on component unmount
  useEffect(() => {
    return () => {
      if (trackingIntervalId !== null) {
        clearInterval(trackingIntervalId);
      }
    };
  }, [trackingIntervalId]);

  return {
    currentLocation,
    locationHistory,
    error,
    isTracking,
    startTracking,
    stopTracking,
  };
}