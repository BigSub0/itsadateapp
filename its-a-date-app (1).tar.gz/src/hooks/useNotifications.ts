// src/hooks/useNotifications.ts
import { useEffect, useState, useCallback } from 'react';

// Mocked interfaces for Capacitor Push Notifications
interface Token {
  value: string;
}

interface PushNotificationSchema {
  title?: string;
  body?: string;
  id?: string;
  badge?: number;
  notification?: Record<string, unknown>;
  data?: Record<string, unknown>;
}

interface ActionPerformed {
  actionId: string;
  notification: PushNotificationSchema;
}

// Mock PushNotifications implementation for web/development environment
const PushNotifications = typeof window !== 'undefined' ? {
  addListener: (eventName: string, callback: (data: unknown) => void) => {
    return { remove: () => console.log(`Removed listener for ${eventName}`) };
  },
  removeAllListeners: async () => {},
  register: async () => {},
  requestPermissions: async () => ({ receive: Notification?.permission || 'denied' }),
  createChannel: async (options: Record<string, unknown>) => {},
  schedule: async (options: Record<string, unknown>) => {},
  cancel: async (options: Record<string, unknown>) => {},
  cancelAll: async () => {}
} : undefined;

export interface NotificationOptions {
  title: string;
  body: string;
  id?: string;
  smallIcon?: string;
  largeIcon?: string;
  sound?: string;
  actionTypeId?: string;
  actionId?: string;
  extra?: Record<string, unknown>;
  attachments?: { id: string; url: string; options?: Record<string, unknown> }[];
  threadIdentifier?: string;
  summaryArgument?: string;
  summaryArgumentCount?: number;
  autoCancel?: boolean;
  ongoing?: boolean;
  color?: string;
  timeout?: number;
  timestamp?: number;
  visibility?: 'public' | 'private' | 'secret';
  group?: string;
  groupSummary?: boolean;
  channelId?: string;
  importance?: number;
}

interface NotificationsHookReturn {
  token: string | null;
  lastNotification: PushNotificationSchema | null;
  lastAction: ActionPerformed | null;
  notificationsEnabled: boolean;
  isInitialized: boolean;
  requestPermissions: () => Promise<boolean>;
  showLocalNotification: (options: NotificationOptions) => Promise<void>;
  scheduleLocalNotification: (options: NotificationOptions, deliveryDate: Date) => Promise<void>;
  cancelNotification: (id: string) => Promise<void>;
  cancelAllNotifications: () => Promise<void>;
  notificationError: Error | null;
}

export const useNotifications = (): NotificationsHookReturn => {
  const [token, setToken] = useState<string | null>(null);
  const [lastNotification, setLastNotification] = useState<PushNotificationSchema | null>(null);
  const [lastAction, setLastAction] = useState<ActionPerformed | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(false);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [notificationError, setNotificationError] = useState<Error | null>(null);

  // Initialize notifications
  useEffect(() => {
    const initializeNotifications = async () => {
      try {
        // Check if push notification plugin is available
        if (typeof PushNotifications === 'undefined') {
          setIsInitialized(true);
          return;
        }

        // Register notification handlers
        PushNotifications.addListener('registration', (token: Token) => {
          setToken(token.value);
          setNotificationsEnabled(true);
        });

        PushNotifications.addListener('registrationError', (error: Error | Record<string, unknown>) => {
          console.error('Registration error: ', error);
          setNotificationError(new Error(`Registration failed: ${error.message || JSON.stringify(error)}`));
        });

        PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
          setLastNotification(notification);
        });

        PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
          setLastAction(action);
        });

        // Register with push servers
        const result = await PushNotifications.requestPermissions();
        
        if (result.receive === 'granted') {
          await PushNotifications.register();
          setNotificationsEnabled(true);
        } else {
          setNotificationsEnabled(false);
        }
        
        setIsInitialized(true);
      } catch (error) {
        console.error('Error initializing notifications:', error);
        setNotificationError(error instanceof Error ? error : new Error('Unknown notification error'));
        setIsInitialized(true);
      }
    };

    initializeNotifications();

    // Clean up listeners
    return () => {
      if (typeof PushNotifications !== 'undefined') {
        PushNotifications.removeAllListeners();
      }
    };
  }, []);

  // Request permissions
  const requestPermissions = async (): Promise<boolean> => {
    try {
      if (typeof PushNotifications === 'undefined') {
        throw new Error('Push notifications not available');
      }

      const result = await PushNotifications.requestPermissions();
      setNotificationsEnabled(result.receive === 'granted');
      
      if (result.receive === 'granted') {
        await PushNotifications.register();
      }
      
      return result.receive === 'granted';
    } catch (error) {
      console.error('Error requesting notification permissions:', error);
      setNotificationError(error instanceof Error ? error : new Error('Permission request failed'));
      return false;
    }
  };

  // Show local notification
  const showLocalNotification = useCallback(async (options: NotificationOptions): Promise<void> => {
    try {
      if (typeof PushNotifications === 'undefined') {
        throw new Error('Push notifications not available');
      }

      if (!notificationsEnabled) {
        const granted = await requestPermissions();
        if (!granted) {
          throw new Error('Notification permissions not granted');
        }
      }

      await PushNotifications.createChannel({
        id: options.channelId || 'default-channel',
        name: 'Default Channel',
        description: 'Default notifications channel',
        importance: 5, // High importance
        visibility: 1, // Public
        sound: options.sound,
        lights: true,
        vibration: true
      });

      await PushNotifications.schedule({
        notifications: [
          {
            id: options.id || Math.floor(Math.random() * 100000).toString(),
            title: options.title,
            body: options.body,
            largeIcon: options.largeIcon,
            smallIcon: options.smallIcon || 'ic_notification',
            sound: options.sound,
            attachments: options.attachments,
            actionTypeId: options.actionTypeId,
            extra: options.extra
          }
        ]
      });
    } catch (error) {
      console.error('Error showing notification:', error);
      setNotificationError(error instanceof Error ? error : new Error('Failed to show notification'));
      throw error;
    }
  }, [notificationsEnabled, requestPermissions]);

  // Schedule local notification
  const scheduleLocalNotification = useCallback(async (options: NotificationOptions, deliveryDate: Date): Promise<void> => {
    try {
      if (typeof PushNotifications === 'undefined') {
        throw new Error('Push notifications not available');
      }

      if (!notificationsEnabled) {
        const granted = await requestPermissions();
        if (!granted) {
          throw new Error('Notification permissions not granted');
        }
      }
      
      // Ensure scheduleEvery is not undefined
      const schedule = {
        at: deliveryDate,
        every: undefined as string | undefined
      };
      
      await PushNotifications.schedule({
        notifications: [
          {
            id: options.id || Math.floor(Math.random() * 100000).toString(),
            title: options.title,
            body: options.body,
            largeIcon: options.largeIcon,
            smallIcon: options.smallIcon || 'ic_notification',
            sound: options.sound,
            attachments: options.attachments,
            actionTypeId: options.actionTypeId,
            extra: options.extra,
            schedule
          }
        ]
      });
    } catch (error) {
      console.error('Error scheduling notification:', error);
      setNotificationError(error instanceof Error ? error : new Error('Failed to schedule notification'));
      throw error;
    }
  }, [notificationsEnabled, requestPermissions]);

  // Cancel notification
  const cancelNotification = useCallback(async (id: string): Promise<void> => {
    try {
      if (typeof PushNotifications === 'undefined') {
        throw new Error('Push notifications not available');
      }

      await PushNotifications.cancel({ notifications: [{ id }] });
    } catch (error) {
      console.error('Error cancelling notification:', error);
      setNotificationError(error instanceof Error ? error : new Error('Failed to cancel notification'));
      throw error;
    }
  }, []);

  // Cancel all notifications
  const cancelAllNotifications = useCallback(async (): Promise<void> => {
    try {
      if (typeof PushNotifications === 'undefined') {
        throw new Error('Push notifications not available');
      }

      await PushNotifications.cancelAll();
    } catch (error) {
      console.error('Error cancelling all notifications:', error);
      setNotificationError(error instanceof Error ? error : new Error('Failed to cancel all notifications'));
      throw error;
    }
  }, []);

  return {
    token,
    lastNotification,
    lastAction,
    notificationsEnabled,
    isInitialized,
    requestPermissions,
    showLocalNotification,
    scheduleLocalNotification,
    cancelNotification,
    cancelAllNotifications,
    notificationError
  };
};