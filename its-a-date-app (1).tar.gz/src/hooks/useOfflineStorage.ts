// src/hooks/useOfflineStorage.ts
import { useState, useEffect, useCallback } from 'react';

// Mock for Capacitor Storage API
const Storage = {
  get: async ({ key }: { key: string }) => {
    try {
      const value = localStorage.getItem(key);
      return { value };
    } catch (e) {
      console.error('Error reading from storage:', e);
      return { value: null };
    }
  },
  set: async ({ key, value }: { key: string; value: string }) => {
    try {
      localStorage.setItem(key, value);
      return { value };
    } catch (e) {
      console.error('Error writing to storage:', e);
      return { value: null };
    }
  },
  remove: async ({ key }: { key: string }) => {
    try {
      localStorage.removeItem(key);
      return { value: true };
    } catch (e) {
      console.error('Error removing from storage:', e);
      return { value: false };
    }
  }
};

// Mock for Capacitor Network API
const Network = {
  getStatus: async () => ({ connected: navigator.onLine }),
  addListener: (eventName: string, callback: (status: { connected: boolean }) => void) => {
    if (eventName === 'networkStatusChange') {
      window.addEventListener('online', () => callback({ connected: true }));
      window.addEventListener('offline', () => callback({ connected: false }));
    }
    return { remove: () => {} };
  },
  removeAllListeners: async () => {
    // This would typically remove event listeners
  }
};

interface OfflineStorageOptions<T> {
  initialValue?: T;
  syncDelay?: number; // milliseconds to wait between sync attempts
  syncRetryMax?: number; // max number of retries
}

interface OfflineStorageResult<T> {
  data: T;
  updateData: (newValueOrFn: T | ((prev: T) => T)) => Promise<void>;
  syncStatus: 'synced' | 'syncing' | 'offline' | 'error';
  syncError: Error | null;
  lastSynced: Date | null;
  isLoading: boolean;
  clearData: () => Promise<void>;
}

/**
 * A hook for managing offline data storage with syncing capabilities
 * @param key The storage key to use for this data
 * @param initialValue The initial value if no data is found
 * @param syncFunction Optional function to sync data with a remote server
 * @param options Additional options for offline storage behavior
 */
export function useOfflineStorage<T>(
  key: string,
  initialValue: T,
  syncFunction?: (data: T) => Promise<void>,
  options: OfflineStorageOptions<T> = {}
): OfflineStorageResult<T> {
  const [data, setData] = useState<T>(initialValue);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'offline' | 'error'>('synced');
  const [syncError, setSyncError] = useState<Error | null>(null);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isOnline, setIsOnline] = useState<boolean>(true);

  const {
    syncDelay = 5000,
    syncRetryMax = 3
  } = options;

  // Initialize network status
  useEffect(() => {
    const checkNetworkStatus = async () => {
      const status = await Network.getStatus();
      setIsOnline(status.connected);
    };

    // Set up network status listener
    Network.addListener('networkStatusChange', (status) => {
      setIsOnline(status.connected);
    });

    checkNetworkStatus();

    return () => {
      // Clean up
      const cleanup = async () => {
        await Network.removeAllListeners();
      };
      cleanup();
    };
  }, []);

  // Load data from storage on initialization
  useEffect(() => {
    const loadData = async () => {
      try {
        const { value } = await Storage.get({ key });
        if (value) {
          setData(JSON.parse(value));
        }
      } catch (error) {
        console.error('Error loading data from storage:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [key]);

  // Sync data with server when online
  useEffect(() => {
    let syncRetries = 0;
    let syncTimeoutId: ReturnType<typeof setTimeout> | null = null;

    const attemptSync = async () => {
      if (!syncFunction || !isOnline || syncStatus === 'syncing') {
        return;
      }

      // Check if we have pending changes to sync
      const pendingChangesKey = `${key}_pendingChanges`;
      const { value: hasPendingChangesValue } = await Storage.get({ key: pendingChangesKey });
      const hasPendingChanges = hasPendingChangesValue === 'true';

      if (!hasPendingChanges) {
        return;
      }

      setSyncStatus('syncing');
      
      try {
        await syncFunction(data);
        
        // Clear pending changes flag
        await Storage.set({ key: pendingChangesKey, value: 'false' });
        
        setSyncStatus('synced');
        setSyncError(null);
        setLastSynced(new Date());
        syncRetries = 0;
      } catch (error) {
        console.error('Error syncing data:', error);
        setSyncStatus('error');
        setSyncError(error instanceof Error ? error : new Error('Unknown sync error'));
        
        // Retry logic
        syncRetries++;
        if (syncRetries < syncRetryMax) {
          syncTimeoutId = setTimeout(attemptSync, syncDelay);
        }
      }
    };

    // Try to sync when we come online
    if (isOnline && syncFunction) {
      attemptSync();
    } else if (!isOnline) {
      setSyncStatus('offline');
    }

    return () => {
      if (syncTimeoutId) {
        clearTimeout(syncTimeoutId);
      }
    };
  }, [isOnline, data, syncFunction, syncDelay, syncRetryMax, key, syncStatus]);

  // Update data in storage and mark for sync
  const updateData = useCallback(async (newValueOrFn: T | ((prev: T) => T)) => {
    const newValue = typeof newValueOrFn === 'function' 
      ? (newValueOrFn as ((prev: T) => T))(data)
      : newValueOrFn;
    
    setData(newValue);
    
    // Save to local storage
    await Storage.set({
      key,
      value: JSON.stringify(newValue)
    });
    
    // Mark that we have changes to sync
    const pendingChangesKey = `${key}_pendingChanges`;
    await Storage.set({ key: pendingChangesKey, value: 'true' });
    
    if (isOnline && syncFunction) {
      setSyncStatus('syncing');
      try {
        await syncFunction(newValue);
        setSyncStatus('synced');
        setSyncError(null);
        setLastSynced(new Date());
        await Storage.set({ key: pendingChangesKey, value: 'false' });
      } catch (error) {
        console.error('Error syncing updated data:', error);
        setSyncStatus('error');
        setSyncError(error instanceof Error ? error : new Error('Unknown sync error'));
      }
    } else {
      setSyncStatus('offline');
    }
  }, [data, key, isOnline, syncFunction]);

  // Clear stored data
  const clearData = useCallback(async () => {
    await Storage.remove({ key });
    setData(initialValue);
    setSyncStatus('synced');
    setSyncError(null);
    setLastSynced(null);
  }, [key, initialValue]);

  return {
    data,
    updateData,
    syncStatus,
    syncError,
    lastSynced,
    isLoading,
    clearData
  };
}