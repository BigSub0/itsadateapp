import { useState, useEffect, useCallback } from "react";

// Types
export type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";
export type Cell = "EMPTY" | "SNAKE" | "FOOD";
export type Position = {
  row: number;
  col: number;
};

// Game configuration
const BOARD_SIZE = 20;
const GAME_SPEED = 150; // milliseconds
const INITIAL_SNAKE: Position[] = [
  { row: 10, col: 8 },
  { row: 10, col: 7 },
  { row: 10, col: 6 },
];
const INITIAL_DIRECTION: Direction = "RIGHT";
const LOCAL_STORAGE_KEY = "snakeHighScore";

const useSnakeGame = () => {
  // Game state
  const [board, setBoard] = useState<Cell[][]>(createEmptyBoard());
  const [snake, setSnake] = useState<Position[]>([...INITIAL_SNAKE]);
  const [food, setFood] = useState<Position | null>(null);
  const [direction, setDirection] = useState<Direction>(INITIAL_DIRECTION);
  const [nextDirection, setNextDirection] = useState<Direction>(INITIAL_DIRECTION);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(true);
  const [gameStarted, setGameStarted] = useState(false);

  // Create empty board
  function createEmptyBoard(): Cell[][] {
    return Array(BOARD_SIZE).fill(null).map(() => 
      Array(BOARD_SIZE).fill("EMPTY")
    );
  }

  // Initialize game
  useEffect(() => {
    // Load high score from local storage
    const savedHighScore = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore, 10));
    }

    // Initial food placement
    placeFood();
    updateBoard();
  }, []);

  // Update the high score when game over
  useEffect(() => {
    if (gameOver && score > highScore) {
      setHighScore(score);
      localStorage.setItem(LOCAL_STORAGE_KEY, score.toString());
    }
  }, [gameOver, score, highScore]);

  // Place food at random position
  const placeFood = useCallback(() => {
    const newFood = () => {
      const row = Math.floor(Math.random() * BOARD_SIZE);
      const col = Math.floor(Math.random() * BOARD_SIZE);
      return { row, col };
    };

    let position = newFood();
    
    // Ensure food is not placed on snake
    while (snake.some(segment => segment.row === position.row && segment.col === position.col)) {
      position = newFood();
    }
    
    setFood(position);
  }, [snake]);

  // Update board based on snake and food positions
  const updateBoard = useCallback(() => {
    const newBoard = createEmptyBoard();
    
    // Place snake on board
    snake.forEach(segment => {
      if (segment.row >= 0 && segment.row < BOARD_SIZE && 
          segment.col >= 0 && segment.col < BOARD_SIZE) {
        newBoard[segment.row][segment.col] = "SNAKE";
      }
    });
    
    // Place food on board
    if (food && food.row >= 0 && food.row < BOARD_SIZE && 
        food.col >= 0 && food.col < BOARD_SIZE) {
      newBoard[food.row][food.col] = "FOOD";
    }
    
    setBoard(newBoard);
  }, [snake, food]);

  // Game loop
  useEffect(() => {
    if (gameOver || isPaused) return;

    const gameLoop = setInterval(() => {
      moveSnake();
    }, GAME_SPEED);

    return () => clearInterval(gameLoop);
  }, [snake, food, direction, nextDirection, gameOver, isPaused]);

  // Update the board whenever snake or food changes
  useEffect(() => {
    updateBoard();
  }, [snake, food, updateBoard]);

  // Check for collisions and move the snake
  const moveSnake = useCallback(() => {
    if (gameOver) return;

    // Apply the next direction
    setDirection(nextDirection);
    
    const head = { ...snake[0] };

    // Calculate new head position based on current direction
    switch (nextDirection) {
      case "UP":
        head.row -= 1;
        break;
      case "DOWN":
        head.row += 1;
        break;
      case "LEFT":
        head.col -= 1;
        break;
      case "RIGHT":
        head.col += 1;
        break;
    }

    // Check for wall collision
    if (
      head.row < 0 ||
      head.row >= BOARD_SIZE ||
      head.col < 0 ||
      head.col >= BOARD_SIZE
    ) {
      setGameOver(true);
      return;
    }

    // Check for self collision (excluding the tail which will move)
    const snakeWithoutTail = snake.slice(0, -1);
    if (snakeWithoutTail.some(segment => segment.row === head.row && segment.col === head.col)) {
      setGameOver(true);
      return;
    }

    const newSnake = [head, ...snake];

    // Check if snake ate the food
    if (food && head.row === food.row && head.col === food.col) {
      setScore(prevScore => prevScore + 1);
      placeFood();
    } else {
      // Remove tail if no food was eaten
      newSnake.pop();
    }

    setSnake(newSnake);
  }, [snake, nextDirection, food, gameOver, placeFood]);

  // Game control functions
  const startGame = useCallback(() => {
    setSnake([...INITIAL_SNAKE]);
    setDirection(INITIAL_DIRECTION);
    setNextDirection(INITIAL_DIRECTION);
    setScore(0);
    setGameOver(false);
    setIsPaused(false);
    setGameStarted(true);
    placeFood();
  }, [placeFood]);

  const pauseGame = useCallback(() => {
    if (!gameOver && gameStarted) {
      setIsPaused(true);
    }
  }, [gameOver, gameStarted]);

  const resumeGame = useCallback(() => {
    if (!gameOver) {
      setIsPaused(false);
    }
  }, [gameOver]);

  const restartGame = useCallback(() => {
    startGame();
  }, [startGame]);

  // Custom setDirection function that doesn't allow 180 degree turns
  const setDirectionWithValidation = useCallback((newDirection: Direction) => {
    // Prevent 180 degree turns
    if (
      (newDirection === "UP" && direction === "DOWN") ||
      (newDirection === "DOWN" && direction === "UP") ||
      (newDirection === "LEFT" && direction === "RIGHT") ||
      (newDirection === "RIGHT" && direction === "LEFT")
    ) {
      return;
    }
    
    setNextDirection(newDirection);
  }, [direction]);

  return {
    board,
    snake,
    food,
    direction,
    score,
    gameOver,
    isPaused,
    highScore,
    setDirection: setDirectionWithValidation,
    startGame,
    pauseGame,
    resumeGame,
    restartGame,
  };
};

export default useSnakeGame;