import { useState, ChangeEvent } from 'react';

interface UseImageUploadResult {
  imageUrl: string | null;
  previewUrl: string | null;
  isLoading: boolean;
  error: string | null;
  uploadImage: (event: ChangeEvent<HTMLInputElement>) => void;
  clearImage: () => void;
}

export const useImageUpload = (initialUrl: string | null = null): UseImageUploadResult => {
  const [imageUrl, setImageUrl] = useState<string | null>(initialUrl);
  const [previewUrl, setPreviewUrl] = useState<string | null>(initialUrl);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const uploadImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    
    if (!file) {
      return;
    }

    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('Please select a valid image file (JPEG, PNG, GIF, or WEBP)');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image size should not exceed 5MB');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Create a FileReader to generate preview URL
      const reader = new FileReader();
      
      reader.onload = () => {
        // Generate a base64 data URL for preview
        const dataUrl = reader.result as string;
        setPreviewUrl(dataUrl);
        
        // In a real app, we would upload the file to a server here
        // and get back a permanent URL
        // For now, we'll just use the data URL as our "uploaded" image URL
        setImageUrl(dataUrl);
        setIsLoading(false);
      };
      
      reader.onerror = () => {
        setError('Failed to read image file');
        setIsLoading(false);
      };
      
      reader.readAsDataURL(file);
    } catch (err) {
      setError('An error occurred while processing the image');
      setIsLoading(false);
      console.error('Image upload error:', err);
    }
  };

  const clearImage = () => {
    setImageUrl(null);
    setPreviewUrl(null);
    setError(null);
  };

  return {
    imageUrl,
    previewUrl,
    isLoading,
    error,
    uploadImage,
    clearImage
  };
};

export default useImageUpload;