import { useState, useEffect } from 'react';

/**
 * Hook to detect if the current device is a mobile device
 * @returns An object with isMobile boolean
 */
export function useMobileDetect() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Function to check if device is mobile
    const checkIfMobile = () => {
      // Check using user agent
      const userAgent = navigator.userAgent || navigator.vendor || (window as Window & typeof globalThis & { opera: string }).opera;
      const mobileRegex = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i;
      const isMobileByAgent = mobileRegex.test(userAgent.toLowerCase());
      
      // Check using window width
      const isMobileByWidth = window.innerWidth < 768;
      
      setIsMobile(isMobileByAgent || isMobileByWidth);
    };

    // Initial check
    checkIfMobile();

    // Add resize event listener to update on window resize
    window.addEventListener('resize', checkIfMobile);
    
    // Cleanup
    return () => window.removeEventListener('resize', checkIfMobile);
  }, []);

  return { isMobile };
}

export default useMobileDetect;