// src/lib/mobile-utils.ts
/**
 * Utility functions for mobile app functionality
 */

// Get device geolocation with promise-based API
export const getGeolocation = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser/device'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      position => resolve(position),
      error => reject(new Error(`Geolocation error: ${error.message}`)),
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 60000
      }
    );
  });
};

// Get device geolocation with watch (continuous updates)
export const watchGeolocation = (
  onUpdate: (position: GeolocationPosition) => void,
  onError?: (error: GeolocationPositionError) => void
): () => void => {
  if (!navigator.geolocation) {
    if (onError) {
      onError({
        code: 0,
        message: 'Geolocation is not supported by this browser/device',
        PERMISSION_DENIED: 1,
        POSITION_UNAVAILABLE: 2,
        TIMEOUT: 3
      });
    }
    return () => {}; // Empty function as there's nothing to clear
  }

  const watchId = navigator.geolocation.watchPosition(
    position => onUpdate(position),
    error => {
      if (onError) {
        onError(error);
      }
    },
    {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 30000
    }
  );

  // Return function to stop watching
  return () => navigator.geolocation.clearWatch(watchId);
};

// Check if the app is installed as PWA
export const isPWA = (): boolean => {
  return window.matchMedia('(display-mode: standalone)').matches || 
    (window.navigator as { standalone?: boolean }).standalone === true ||
    document.referrer.includes('android-app://');
};

// Check if the device is online
export const isOnline = (): boolean => {
  return navigator.onLine;
};

// Add network status event listeners
export const addNetworkListeners = (
  onOnline: () => void,
  onOffline: () => void
): () => void => {
  window.addEventListener('online', onOnline);
  window.addEventListener('offline', onOffline);

  // Return cleanup function
  return () => {
    window.removeEventListener('online', onOnline);
    window.removeEventListener('offline', onOffline);
  };
};

// Format a location object for display
export const formatLocation = (
  coords: GeolocationCoordinates | { latitude: number; longitude: number },
  precision: number = 6
): string => {
  return `${coords.latitude.toFixed(precision)}, ${coords.longitude.toFixed(precision)}`;
};

// Generate a Google Maps URL from coordinates
export const getMapsUrl = (
  coords: GeolocationCoordinates | { latitude: number; longitude: number },
  label?: string
): string => {
  const baseUrl = 'https://www.google.com/maps';
  
  if (label) {
    return `${baseUrl}/search/?api=1&query=${coords.latitude},${coords.longitude}&query_place_id=${encodeURIComponent(label)}`;
  }
  
  return `${baseUrl}/?q=${coords.latitude},${coords.longitude}`;
};

// Get approximate address from coordinates using reverse geocoding
export const getAddressFromCoords = async (
  coords: GeolocationCoordinates | { latitude: number; longitude: number }
): Promise<string> => {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${coords.latitude}&lon=${coords.longitude}&addressdetails=1`
    );
    
    if (!response.ok) {
      throw new Error('Geocoding service failed');
    }
    
    const data = await response.json();
    return data.display_name || 'Unknown location';
  } catch (error) {
    console.error('Error getting address:', error);
    return 'Location unavailable';
  }
};

// Calculate distance between two coordinates in kilometers
export const calculateDistance = (
  coords1: GeolocationCoordinates | { latitude: number; longitude: number },
  coords2: GeolocationCoordinates | { latitude: number; longitude: number }
): number => {
  const R = 6371; // Earth radius in kilometers
  const dLat = toRadians(coords2.latitude - coords1.latitude);
  const dLon = toRadians(coords2.longitude - coords1.longitude);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(coords1.latitude)) * 
    Math.cos(toRadians(coords2.latitude)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance;
};

// Convert degrees to radians
const toRadians = (degrees: number): number => {
  return degrees * (Math.PI / 180);
};

// Generate a unique ID (useful for notifications, etc.)
export const generateUniqueId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Vibrate the device if supported
export const vibrate = (pattern: number | number[]): boolean => {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
    return true;
  }
  return false;
};

// Check if the device has a specific capability
export interface DeviceCapabilities {
  camera: boolean;
  geolocation: boolean;
  vibration: boolean;
  notification: boolean;
  orientation: boolean;
  touch: boolean;
}

export const checkDeviceCapabilities = (): DeviceCapabilities => {
  return {
    camera: 'mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices,
    geolocation: 'geolocation' in navigator,
    vibration: 'vibrate' in navigator,
    notification: 'Notification' in window,
    orientation: 'orientation' in window || 'orientationchange' in window,
    touch: 'ontouchstart' in window || navigator.maxTouchPoints > 0
  };
};

// Handle deep links in the app
export const setupDeepLinks = (
  handleDeepLink: (url: string) => void
): void => {
  // Handle links when app is already running
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      const deepLink = sessionStorage.getItem('deepLink');
      if (deepLink) {
        sessionStorage.removeItem('deepLink');
        handleDeepLink(deepLink);
      }
    }
  });

  // Parse URL parameters for deep links
  const urlParams = new URLSearchParams(window.location.search);
  const deepLink = urlParams.get('link');
  if (deepLink) {
    handleDeepLink(deepLink);
  }
};

// Check if app can use background sync
export const canUseBackgroundSync = (): boolean => {
  return 'serviceWorker' in navigator && 'SyncManager' in window;
};

// Register for background sync
export const registerBackgroundSync = async (
  syncTag: string = 'sync-delivery-data'
): Promise<boolean> => {
  if (!canUseBackgroundSync()) {
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    await registration.sync.register(syncTag);
    return true;
  } catch (error) {
    console.error('Background sync registration failed:', error);
    return false;
  }
};