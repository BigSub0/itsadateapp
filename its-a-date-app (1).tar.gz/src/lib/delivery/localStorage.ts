// Local storage service for the delivery app
export interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: string;
  imageUrl: string;
  tags: string[];
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number;
  imageUrl?: string;
  category: string;
  options?: {
    name: string;
    choices: {
      name: string;
      price: number;
    }[];
  }[];
  popular?: boolean;
  vegetarian?: boolean;
  spicy?: boolean;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  specialInstructions?: string;
  options?: {
    name: string;
    choice: {
      name: string;
      price: number;
    };
  }[];
}

export interface Order {
  id: string;
  restaurantId: string;
  restaurantName: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  tip: number;
  total: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'out-for-delivery' | 'delivered' | 'canceled';
  placedAt: string;
  estimatedDelivery: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  paymentMethod: {
    type: 'credit' | 'debit' | 'paypal' | 'cash';
    last4?: string;
  };
}

class LocalStorageService {
  private getItem<T>(key: string, defaultValue: T): T {
    if (typeof window === 'undefined') return defaultValue;
    
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error(`Error getting item from localStorage: ${key}`, error);
      return defaultValue;
    }
  }

  private setItem<T>(key: string, value: T): void {
    if (typeof window === 'undefined') return;
    
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error setting item in localStorage: ${key}`, error);
    }
  }

  // Cart methods
  getCart(): CartItem[] {
    return this.getItem<CartItem[]>('delivery_cart', []);
  }

  setCart(cart: CartItem[]): void {
    this.setItem('delivery_cart', cart);
  }

  addToCart(item: CartItem): void {
    const cart = this.getCart();
    
    // Look for existing item with same ID and options
    const existingItemIndex = cart.findIndex(cartItem => {
      if (cartItem.menuItem.id !== item.menuItem.id) return false;
      
      // Check if options match
      if (cartItem.options?.length !== item.options?.length) return false;
      
      if (!cartItem.options && !item.options) return true;
      
      // Compare each option
      return JSON.stringify(cartItem.options) === JSON.stringify(item.options);
    });

    if (existingItemIndex >= 0) {
      // Update quantity of existing item
      cart[existingItemIndex].quantity += item.quantity;
    } else {
      // Add new item to cart
      cart.push(item);
    }

    this.setCart(cart);
  }

  updateCartItem(index: number, item: CartItem): void {
    const cart = this.getCart();
    if (index >= 0 && index < cart.length) {
      cart[index] = item;
      this.setCart(cart);
    }
  }

  removeFromCart(index: number): void {
    const cart = this.getCart();
    if (index >= 0 && index < cart.length) {
      cart.splice(index, 1);
      this.setCart(cart);
    }
  }

  clearCart(): void {
    this.setCart([]);
  }

  // Orders methods
  getOrders(): Order[] {
    return this.getItem<Order[]>('delivery_orders', []);
  }

  addOrder(order: Order): void {
    const orders = this.getOrders();
    orders.unshift(order); // Add new order at the beginning
    this.setItem('delivery_orders', orders);
  }

  updateOrderStatus(orderId: string, status: Order['status']): void {
    const orders = this.getOrders();
    const orderIndex = orders.findIndex(order => order.id === orderId);
    
    if (orderIndex >= 0) {
      orders[orderIndex].status = status;
      this.setItem('delivery_orders', orders);
    }
  }

  // Favorites methods
  getFavoriteRestaurants(): string[] {
    return this.getItem<string[]>('delivery_favorites', []);
  }

  addToFavorites(restaurantId: string): void {
    const favorites = this.getFavoriteRestaurants();
    if (!favorites.includes(restaurantId)) {
      favorites.push(restaurantId);
      this.setItem('delivery_favorites', favorites);
    }
  }

  removeFromFavorites(restaurantId: string): void {
    const favorites = this.getFavoriteRestaurants();
    const updatedFavorites = favorites.filter(id => id !== restaurantId);
    this.setItem('delivery_favorites', updatedFavorites);
  }

  isFavorite(restaurantId: string): boolean {
    return this.getFavoriteRestaurants().includes(restaurantId);
  }
}

export const deliveryStorage = new LocalStorageService();