// Define an interface for a delivery location
export interface DeliveryLocation {
  id: string;
  address: string;
  lat: number;
  lng: number;
  priority?: number; // Optional priority (1 is highest)
  timeWindow?: {
    start: number; // Timestamp for delivery window start
    end: number; // Timestamp for delivery window end
  };
  status?: 'pending' | 'in-progress' | 'completed';
}

// Define an interface for a driver's location
export interface DriverLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  lastUpdated: number; // Timestamp
}

/**
 * Calculate distance between two points using the Haversine formula
 * @param lat1 Latitude of point 1
 * @param lng1 Longitude of point 1
 * @param lat2 Latitude of point 2
 * @param lng2 Longitude of point 2
 * @returns Distance in kilometers
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Find the nearest delivery location from a driver's position
 * @param driverLocation Driver's current location
 * @param deliveryLocations Array of delivery locations
 * @returns The nearest delivery location
 */
export function findNearestDelivery(
  driverLocation: DriverLocation,
  deliveryLocations: DeliveryLocation[]
): DeliveryLocation | null {
  if (deliveryLocations.length === 0) return null;
  
  // Filter out completed deliveries
  const activeDeliveries = deliveryLocations.filter(
    (delivery) => delivery.status !== 'completed'
  );
  
  if (activeDeliveries.length === 0) return null;
  
  let nearestDelivery = activeDeliveries[0];
  let shortestDistance = calculateDistance(
    driverLocation.lat,
    driverLocation.lng,
    nearestDelivery.lat,
    nearestDelivery.lng
  );

  for (let i = 1; i < activeDeliveries.length; i++) {
    const currentDelivery = activeDeliveries[i];
    const currentDistance = calculateDistance(
      driverLocation.lat,
      driverLocation.lng,
      currentDelivery.lat,
      currentDelivery.lng
    );

    // Consider priority if available (lower number = higher priority)
    let shouldUpdate = false;
    
    if (currentDelivery.priority && nearestDelivery.priority) {
      if (currentDelivery.priority < nearestDelivery.priority) {
        shouldUpdate = true;
      } else if (currentDelivery.priority === nearestDelivery.priority) {
        shouldUpdate = currentDistance < shortestDistance;
      }
    } else {
      shouldUpdate = currentDistance < shortestDistance;
    }
    
    if (shouldUpdate) {
      nearestDelivery = currentDelivery;
      shortestDistance = currentDistance;
    }
  }

  return nearestDelivery;
}

/**
 * Optimize delivery route using a greedy nearest-neighbor algorithm
 * @param startLocation Starting location of the driver
 * @param deliveryLocations Array of delivery locations to optimize
 * @returns Optimized route as an array of delivery locations
 */
export function optimizeRoute(
  startLocation: { lat: number; lng: number },
  deliveryLocations: DeliveryLocation[]
): DeliveryLocation[] {
  // Copy the array to avoid modifying the original
  const remainingDeliveries = [...deliveryLocations];
  const optimizedRoute: DeliveryLocation[] = [];
  
  // If there are no deliveries, return empty array
  if (remainingDeliveries.length === 0) return optimizedRoute;
  
  // Start with driver's current location
  let currentLocation = startLocation;
  
  // Continue until all deliveries are added to the route
  while (remainingDeliveries.length > 0) {
    // Find the nearest delivery from current location
    let nearestIndex = 0;
    let shortestDistance = calculateDistance(
      currentLocation.lat,
      currentLocation.lng,
      remainingDeliveries[0].lat,
      remainingDeliveries[0].lng
    );
    
    for (let i = 1; i < remainingDeliveries.length; i++) {
      const currentDistance = calculateDistance(
        currentLocation.lat,
        currentLocation.lng,
        remainingDeliveries[i].lat,
        remainingDeliveries[i].lng
      );
      
      // Consider time windows if available
      const now = Date.now();
      const hasTimeWindow = remainingDeliveries[i].timeWindow;
      
      if (hasTimeWindow && remainingDeliveries[i].timeWindow!.end < now) {
        // Skip this delivery if we're past the delivery window
        continue;
      }
      
      // Prioritize deliveries with time windows that are closing soon
      if (hasTimeWindow && 
          remainingDeliveries[i].timeWindow!.end - now < 3600000 && // Within 1 hour of closing
          currentDistance < shortestDistance * 1.5) { // Not too far away
        nearestIndex = i;
        shortestDistance = currentDistance;
      } 
      // Otherwise use simple distance calculation
      else if (currentDistance < shortestDistance) {
        nearestIndex = i;
        shortestDistance = currentDistance;
      }
    }
    
    // Add the nearest delivery to the optimized route
    const nextDelivery = remainingDeliveries[nearestIndex];
    optimizedRoute.push(nextDelivery);
    
    // Remove it from remaining deliveries
    remainingDeliveries.splice(nearestIndex, 1);
    
    // Update current location
    currentLocation = {
      lat: nextDelivery.lat,
      lng: nextDelivery.lng
    };
  }
  
  return optimizedRoute;
}