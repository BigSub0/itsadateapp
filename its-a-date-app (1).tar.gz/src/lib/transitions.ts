import { Variants } from 'framer-motion';

// Simple fade up animation
export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      duration: 0.4, 
      ease: 'easeOut' 
    } 
  },
  exit: { 
    opacity: 0, 
    y: 20, 
    transition: { 
      duration: 0.2, 
      ease: 'easeIn' 
    } 
  }
};

// Page transition that slides in from right
export const pageSlideIn: Variants = {
  hidden: { opacity: 0, x: 50 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { 
      duration: 0.4, 
      ease: 'easeOut',
      when: 'beforeChildren',
      staggerChildren: 0.1
    } 
  },
  exit: { 
    opacity: 0, 
    x: -50, 
    transition: { 
      duration: 0.3, 
      ease: 'easeIn',
      when: 'afterChildren',
      staggerChildren: 0.05
    } 
  }
};

// Fade in for list items
export const listItem: Variants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      duration: 0.3
    } 
  },
  exit: { 
    opacity: 0,
    transition: { 
      duration: 0.2
    } 
  }
};

// Scale up for cards
export const cardScale: Variants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { 
      duration: 0.4, 
      ease: 'easeOut' 
    } 
  },
  exit: { 
    opacity: 0, 
    scale: 0.9, 
    transition: { 
      duration: 0.3, 
      ease: 'easeIn' 
    } 
  }
};