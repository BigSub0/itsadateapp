import { io, Socket } from 'socket.io-client';

// Define types for socket events
export interface BidUpdateEvent {
  loadId: string;
  bidPrice?: number;
  assignedDriver?: string;
  distance?: number;
  status: string;
  error?: string;
}

export interface DriverLocationUpdateEvent {
  driverId: number;
  location: {
    lat: number;
    lng: number;
  };
  timestamp: number;
}

/**
 * Socket service for real-time updates from Vital Xpress server
 */
class SocketService {
  private socket: Socket | null = null;
  private connectionAttempts = 0;
  private readonly MAX_RECONNECT_ATTEMPTS = 5;

  /**
   * Initialize the socket connection
   */
  connect(): Socket {
    if (!this.socket) {
      // Would use environment variables in production
      this.socket = io('http://localhost:3000', {
        reconnectionAttempts: this.MAX_RECONNECT_ATTEMPTS,
        reconnectionDelay: 1000,
        autoConnect: true,
      });

      this.setupEventListeners();
    }
    return this.socket;
  }

  /**
   * Check if the socket is connected
   */
  isConnected(): boolean {
    return !!this.socket?.connected;
  }

  /**
   * Setup default event listeners for the socket
   */
  private setupEventListeners(): void {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('Connected to Vital Xpress server');
      this.connectionAttempts = 0;
    });

    this.socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      this.connectionAttempts++;

      if (this.connectionAttempts >= this.MAX_RECONNECT_ATTEMPTS) {
        console.error('Max reconnection attempts reached');
        this.socket?.disconnect();
      }
    });

    this.socket.on('disconnect', (reason) => {
      console.log('Disconnected from Vital Xpress server:', reason);
    });
  }

  /**
   * Disconnect the socket
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  /**
   * Subscribe to bid updates
   */
  onBidUpdate(callback: (update: BidUpdateEvent) => void): void {
    this.socket?.on('bidUpdate', callback);
  }

  /**
   * Subscribe to driver location updates
   */
  onDriverLocationUpdate(callback: (update: DriverLocationUpdateEvent) => void): void {
    this.socket?.on('driverLocationUpdate', callback);
  }

  /**
   * Remove a specific event listener
   */
  off(event: string, callback?: ((...args: unknown[]) => void)): void {
    this.socket?.off(event, callback);
  }
}

// Export a singleton instance
export const socketService = new SocketService();