// Define interfaces for local storage data types
export interface User {
  id: string;
  email: string;
  password: string;
  name: string;
  createdAt: string;
}

export interface Profile {
  userId: string;
  name: string;
  age: number;
  gender: string;
  interestedIn: string[];
  bio: string;
  location: string;
  imageUrl: string;
  interests: string[];
  completed: boolean;
}

export interface SurveyAnswer {
  userId: string;
  questionId: number;
  answer: string;
}

export interface Match {
  id: string;
  user1Id: string;
  user2Id: string;
  matchScore: number;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

export interface DateIdea {
  id: string;
  title: string;
  description: string;
  category: string;
  cost: number; // 1-3 representing $ to $$$
  imageUrl: string;
  location: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}

// Local storage keys
export const STORAGE_KEYS = {
  USERS: 'dating_app_users',
  CURRENT_USER: 'dating_app_current_user',
  PROFILES: 'dating_app_profiles',
  SURVEY_ANSWERS: 'dating_app_survey_answers',
  MATCHES: 'dating_app_matches',
  DATE_IDEAS: 'dating_app_date_ideas',
  MESSAGES: 'dating_app_messages'
};

// Authentication functions
export const authService = {
  // Register a new user
  register: (email: string, password: string, name: string): User | null => {
    try {
      const users = getItem<User[]>(STORAGE_KEYS.USERS, []);
      
      // Check if user already exists
      if (users.some(user => user.email === email)) {
        return null;
      }
      
      const newUser: User = {
        id: generateId(),
        email,
        password, // Note: In a real app, we would hash this password
        name,
        createdAt: new Date().toISOString()
      };
      
      users.push(newUser);
      setItem(STORAGE_KEYS.USERS, users);
      setItem(STORAGE_KEYS.CURRENT_USER, newUser);
      
      // Initialize an empty profile for the user
      const profiles = getItem<Profile[]>(STORAGE_KEYS.PROFILES, []);
      const newProfile: Profile = {
        userId: newUser.id,
        name: newUser.name,
        age: 0,
        gender: '',
        interestedIn: [],
        bio: '',
        location: '',
        imageUrl: '',
        interests: [],
        completed: false
      };
      profiles.push(newProfile);
      setItem(STORAGE_KEYS.PROFILES, profiles);
      
      return newUser;
    } catch (error) {
      console.error('Error registering user:', error);
      return null;
    }
  },
  
  // Login a user
  login: (email: string, password: string): User | null => {
    try {
      const users = getItem<User[]>(STORAGE_KEYS.USERS, []);
      const user = users.find(u => u.email === email && u.password === password);
      
      if (user) {
        setItem(STORAGE_KEYS.CURRENT_USER, user);
        return user;
      }
      
      return null;
    } catch (error) {
      console.error('Error logging in:', error);
      return null;
    }
  },
  
  // Logout current user
  logout: () => {
    try {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      return true;
    } catch (error) {
      console.error('Error logging out:', error);
      return false;
    }
  },
  
  // Get current logged in user
  getCurrentUser: (): User | null => {
    return getItem<User | null>(STORAGE_KEYS.CURRENT_USER, null);
  }
};

// Profile functions
export const profileService = {
  // Get profile by user ID
  getProfileByUserId: (userId: string): Profile | null => {
    try {
      const profiles = getItem<Profile[]>(STORAGE_KEYS.PROFILES, []);
      return profiles.find(p => p.userId === userId) || null;
    } catch (error) {
      console.error('Error getting profile:', error);
      return null;
    }
  },
  
  // Update profile
  updateProfile: (updatedProfile: Profile): Profile | null => {
    try {
      const profiles = getItem<Profile[]>(STORAGE_KEYS.PROFILES, []);
      const index = profiles.findIndex(p => p.userId === updatedProfile.userId);
      
      if (index !== -1) {
        profiles[index] = { ...updatedProfile };
        setItem(STORAGE_KEYS.PROFILES, profiles);
        return profiles[index];
      }
      
      return null;
    } catch (error) {
      console.error('Error updating profile:', error);
      return null;
    }
  },
  
  // Get all completed profiles
  getAllProfiles: (): Profile[] => {
    try {
      const profiles = getItem<Profile[]>(STORAGE_KEYS.PROFILES, []);
      return profiles.filter(p => p.completed);
    } catch (error) {
      console.error('Error getting all profiles:', error);
      return [];
    }
  }
};

// Survey and matching functions
export const surveyService = {
  // Save survey answer
  saveAnswer: (userId: string, questionId: number, answer: string): boolean => {
    try {
      const answers = getItem<SurveyAnswer[]>(STORAGE_KEYS.SURVEY_ANSWERS, []);
      
      // Check if answer exists and update it, or add a new one
      const existingIndex = answers.findIndex(
        a => a.userId === userId && a.questionId === questionId
      );
      
      if (existingIndex !== -1) {
        answers[existingIndex].answer = answer;
      } else {
        answers.push({ userId, questionId, answer });
      }
      
      setItem(STORAGE_KEYS.SURVEY_ANSWERS, answers);
      return true;
    } catch (error) {
      console.error('Error saving answer:', error);
      return false;
    }
  },
  
  // Get all answers for a user
  getUserAnswers: (userId: string): SurveyAnswer[] => {
    try {
      const answers = getItem<SurveyAnswer[]>(STORAGE_KEYS.SURVEY_ANSWERS, []);
      return answers.filter(a => a.userId === userId);
    } catch (error) {
      console.error('Error getting user answers:', error);
      return [];
    }
  },
  
  // Calculate match score between two users (simple algorithm)
  calculateMatchScore: (user1Id: string, user2Id: string): number => {
    try {
      const answers1 = surveyService.getUserAnswers(user1Id);
      const answers2 = surveyService.getUserAnswers(user2Id);
      
      // If either user hasn't answered any questions, return 0
      if (answers1.length === 0 || answers2.length === 0) {
        return 0;
      }
      
      // Count matching answers
      let matchCount = 0;
      let totalQuestions = 0;
      
      answers1.forEach(a1 => {
        const a2 = answers2.find(a => a.questionId === a1.questionId);
        if (a2) {
          totalQuestions++;
          if (a1.answer === a2.answer) {
            matchCount++;
          }
        }
      });
      
      return totalQuestions > 0 ? Math.round((matchCount / totalQuestions) * 100) : 0;
    } catch (error) {
      console.error('Error calculating match score:', error);
      return 0;
    }
  },
  
  // Find potential matches for a user
  findMatches: (userId: string, minScore = 50): Match[] => {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) return [];
      
      const currentUserProfile = profileService.getProfileByUserId(userId);
      if (!currentUserProfile || !currentUserProfile.completed) return [];
      
      const allProfiles = profileService.getAllProfiles();
      const existingMatches = getItem<Match[]>(STORAGE_KEYS.MATCHES, []);
      const potentialMatches: Match[] = [];
      
      // Filter profiles based on preferences
      const filteredProfiles = allProfiles.filter(profile => {
        // Don't match with self
        if (profile.userId === userId) return false;
        
        // Check if match already exists
        const matchExists = existingMatches.some(
          m => (m.user1Id === userId && m.user2Id === profile.userId) || 
               (m.user1Id === profile.userId && m.user2Id === userId)
        );
        if (matchExists) return false;
        
        // Check gender preference match
        const isGenderMatch = 
          currentUserProfile.interestedIn.includes(profile.gender) && 
          profile.interestedIn.includes(currentUserProfile.gender);
        
        return isGenderMatch;
      });
      
      // Calculate match score for each potential match
      for (const profile of filteredProfiles) {
        const score = surveyService.calculateMatchScore(userId, profile.userId);
        
        if (score >= minScore) {
          const newMatch: Match = {
            id: generateId(),
            user1Id: userId,
            user2Id: profile.userId,
            matchScore: score,
            status: 'pending',
            createdAt: new Date().toISOString()
          };
          
          potentialMatches.push(newMatch);
        }
      }
      
      // Save new matches to storage
      if (potentialMatches.length > 0) {
        setItem(STORAGE_KEYS.MATCHES, [...existingMatches, ...potentialMatches]);
      }
      
      return potentialMatches;
    } catch (error) {
      console.error('Error finding matches:', error);
      return [];
    }
  },
  
  // Get all matches for a user
  getUserMatches: (userId: string): Match[] => {
    try {
      const matches = getItem<Match[]>(STORAGE_KEYS.MATCHES, []);
      return matches.filter(
        m => (m.user1Id === userId || m.user2Id === userId)
      );
    } catch (error) {
      console.error('Error getting user matches:', error);
      return [];
    }
  },
  
  // Update match status
  updateMatchStatus: (matchId: string, status: 'accepted' | 'rejected'): boolean => {
    try {
      const matches = getItem<Match[]>(STORAGE_KEYS.MATCHES, []);
      const index = matches.findIndex(m => m.id === matchId);
      
      if (index !== -1) {
        matches[index].status = status;
        setItem(STORAGE_KEYS.MATCHES, matches);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error updating match status:', error);
      return false;
    }
  }
};

// Date ideas service
export const dateIdeasService = {
  // Get all date ideas
  getAllDateIdeas: (): DateIdea[] => {
    try {
      return getItem<DateIdea[]>(STORAGE_KEYS.DATE_IDEAS, []);
    } catch (error) {
      console.error('Error getting date ideas:', error);
      return [];
    }
  },
  
  // Filter date ideas by category
  getDateIdeasByCategory: (category: string): DateIdea[] => {
    try {
      const ideas = getItem<DateIdea[]>(STORAGE_KEYS.DATE_IDEAS, []);
      return ideas.filter(idea => idea.category === category);
    } catch (error) {
      console.error('Error filtering date ideas:', error);
      return [];
    }
  },
  
  // Initialize with some default date ideas if none exist
  initializeDateIdeas: (): void => {
    try {
      const existingIdeas = getItem<DateIdea[]>(STORAGE_KEYS.DATE_IDEAS, []);
      
      if (existingIdeas.length === 0) {
        const defaultDateIdeas: DateIdea[] = [
          {
            id: '1',
            title: 'Sunset Picnic',
            description: 'Enjoy a romantic picnic with a beautiful sunset view.',
            category: 'Outdoors',
            cost: 1,
            imageUrl: '/assets/date-ideas/sunset-picnic.jpg',
            location: 'Any park or beach'
          },
          {
            id: '2',
            title: 'Cooking Class',
            description: 'Learn to cook a new cuisine together.',
            category: 'Food',
            cost: 2,
            imageUrl: '/assets/date-ideas/cooking-class.jpg',
            location: 'Local cooking school'
          },
          {
            id: '3',
            title: 'Art Museum Tour',
            description: 'Explore art and culture together at a local museum.',
            category: 'Culture',
            cost: 1,
            imageUrl: '/assets/date-ideas/art-museum.jpg',
            location: 'Local art museum'
          },
          {
            id: '4',
            title: 'Wine Tasting',
            description: 'Sample different wines at a local vineyard or wine bar.',
            category: 'Food',
            cost: 2,
            imageUrl: '/assets/date-ideas/wine-tasting.jpg',
            location: 'Vineyard or wine bar'
          },
          {
            id: '5',
            title: 'Stargazing',
            description: 'Look at the stars together and find constellations.',
            category: 'Outdoors',
            cost: 1,
            imageUrl: '/assets/date-ideas/stargazing.jpg',
            location: 'Park or countryside away from city lights'
          },
          {
            id: '6',
            title: 'Escape Room',
            description: 'Solve puzzles together to escape a themed room.',
            category: 'Entertainment',
            cost: 2,
            imageUrl: '/assets/date-ideas/escape-room.jpg',
            location: 'Local escape room venue'
          },
          {
            id: '7',
            title: 'Dance Class',
            description: 'Learn a new dance style together.',
            category: 'Entertainment',
            cost: 2,
            imageUrl: '/assets/date-ideas/dance-class.jpg',
            location: 'Dance studio'
          },
          {
            id: '8',
            title: 'Fine Dining Experience',
            description: 'Dress up and enjoy a meal at an upscale restaurant.',
            category: 'Food',
            cost: 3,
            imageUrl: '/assets/date-ideas/fine-dining.jpg',
            location: 'Upscale restaurant'
          }
        ];
        
        setItem(STORAGE_KEYS.DATE_IDEAS, defaultDateIdeas);
      }
    } catch (error) {
      console.error('Error initializing date ideas:', error);
    }
  }
};

// Survey questions
export const surveyQuestions = [
  {
    id: 1,
    question: "What's your ideal first date?",
    options: [
      "Coffee shop conversation",
      "Outdoor adventure",
      "Dinner and movie",
      "Museum or art gallery"
    ]
  },
  {
    id: 2,
    question: "How do you prefer to spend weekends?",
    options: [
      "Relaxing at home",
      "Going out with friends",
      "Outdoor activities",
      "Exploring new places"
    ]
  },
  {
    id: 3,
    question: "What's most important in a relationship?",
    options: [
      "Communication",
      "Trust",
      "Shared interests",
      "Chemistry"
    ]
  },
  {
    id: 4,
    question: "Which best describes your approach to life?",
    options: [
      "Spontaneous and adventurous",
      "Organized and planned",
      "Balanced mix of both",
      "Go with the flow"
    ]
  },
  {
    id: 5,
    question: "What's your ideal evening?",
    options: [
      "Cooking dinner at home",
      "Going out to restaurants",
      "Watching movies/TV",
      "Social events with friends"
    ]
  }
];

// Helper functions
function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Error getting item ${key} from localStorage:`, error);
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error setting item ${key} in localStorage:`, error);
  }
}