import axios from 'axios';

// Define types for our API requests and responses
export interface LoadLocation {
  lat: number;
  lng: number;
}

export interface PlaceBidRequest {
  loadId: string;
  pickupLocation: LoadLocation;
  dropoffLocation: LoadLocation;
  isMedical: boolean;
  isLongHaul: boolean;
}

export interface PlaceBidResponse {
  message: string;
  loadId: string;
  bidPrice: number;
  assignedDriver: string;
  distance: number;
}

export interface ErrorResponse {
  error: string;
  details?: string;
}

// Base API URL - would be configured from environment in production
const BASE_URL = 'http://localhost:3000';

/**
 * API service for the Vital Xpress Courier application
 */
class ApiService {
  /**
   * Places a bid on a load and assigns a driver
   */
  async placeBid(bidRequest: PlaceBidRequest): Promise<PlaceBidResponse> {
    try {
      const response = await axios.post<PlaceBidResponse>(`${BASE_URL}/api/place-bid`, bidRequest);
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        throw new Error((error.response.data as ErrorResponse).error || 'Failed to place bid');
      }
      throw new Error('Network error when placing bid');
    }
  }

  /**
   * Calculate estimated bid price based on pickup and dropoff locations
   * This is a client-side estimation - the actual price is determined server-side
   */
  calculateEstimatedBid(
    pickupLocation: LoadLocation, 
    dropoffLocation: LoadLocation,
    isMedical: boolean,
    isLongHaul: boolean
  ): number {
    // Simple distance calculation (Haversine formula)
    const R = 3958.8; // Earth radius in miles
    const dLat = this.toRad(dropoffLocation.lat - pickupLocation.lat);
    const dLon = this.toRad(dropoffLocation.lng - pickupLocation.lng);
    
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.toRad(pickupLocation.lat)) * 
      Math.cos(this.toRad(dropoffLocation.lat)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    // Simple pricing model (this should match server-side logic for accuracy)
    const pricing = isMedical ? 
      { base: isLongHaul ? 43 : 33, perMile: 1.25 } : 
      { base: isLongHaul ? 30 : 20, perMile: 1.25 };
      
    const totalCost = pricing.base + (distance * pricing.perMile);
    return totalCost * 1.2; // Add 20% profit margin
  }
  
  private toRad(degrees: number): number {
    return degrees * Math.PI / 180;
  }
}

// Export a singleton instance
export const apiService = new ApiService();