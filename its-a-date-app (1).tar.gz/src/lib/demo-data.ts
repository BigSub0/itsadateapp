import { DeliveryLocation, DriverLocation } from './route-optimizer';

// Demo data for the Vital Xpress Courier application

/**
 * Sample driver locations for demo purposes
 */
export const demoDrivers: DriverLocation[] = [
  {
    id: 'driver-001',
    name: 'John Smith',
    lat: 37.7749,
    lng: -122.4194,
    lastUpdated: Date.now() - 120000 // 2 minutes ago
  },
  {
    id: 'driver-002',
    name: 'Maria Garcia',
    lat: 37.7833,
    lng: -122.4167,
    lastUpdated: Date.now() - 60000 // 1 minute ago
  },
  {
    id: 'driver-003',
    name: 'David Chen',
    lat: 37.7879,
    lng: -122.4075,
    lastUpdated: Date.now() - 180000 // 3 minutes ago
  }
];

/**
 * Sample delivery locations for demo purposes
 */
export const demoDeliveries: DeliveryLocation[] = [
  {
    id: 'delivery-001',
    address: '123 Market St, San Francisco, CA',
    lat: 37.7935,
    lng: -122.3957,
    priority: 1,
    status: 'in-progress',
    timeWindow: {
      start: Date.now(),
      end: Date.now() + 3600000 // 1 hour from now
    }
  },
  {
    id: 'delivery-002',
    address: '456 Mission St, San Francisco, CA',
    lat: 37.7879,
    lng: -122.3996,
    priority: 2,
    status: 'pending',
    timeWindow: {
      start: Date.now(),
      end: Date.now() + 7200000 // 2 hours from now
    }
  },
  {
    id: 'delivery-003',
    address: '789 Howard St, San Francisco, CA',
    lat: 37.7835,
    lng: -122.4056,
    priority: 3,
    status: 'pending',
    timeWindow: {
      start: Date.now() + 1800000, // 30 minutes from now
      end: Date.now() + 10800000 // 3 hours from now
    }
  },
  {
    id: 'delivery-004',
    address: '101 California St, San Francisco, CA',
    lat: 37.7932,
    lng: -122.3984,
    priority: 1,
    status: 'completed',
    timeWindow: {
      start: Date.now() - 7200000, // 2 hours ago
      end: Date.now() - 3600000 // 1 hour ago
    }
  },
  {
    id: 'delivery-005',
    address: '1 Ferry Building, San Francisco, CA',
    lat: 37.7955,
    lng: -122.3937,
    priority: 2,
    status: 'pending',
    timeWindow: {
      start: Date.now() + 3600000, // 1 hour from now
      end: Date.now() + 14400000 // 4 hours from now
    }
  }
];

/**
 * Generate moving positions for drivers to simulate movement
 * @param driver The driver to update
 * @returns Updated driver location
 */
export function updateDriverLocation(driver: DriverLocation): DriverLocation {
  // Simulate small random movement
  const latChange = (Math.random() - 0.5) * 0.002; // Random change in latitude
  const lngChange = (Math.random() - 0.5) * 0.002; // Random change in longitude
  
  return {
    ...driver,
    lat: driver.lat + latChange,
    lng: driver.lng + lngChange,
    lastUpdated: Date.now()
  };
}

/**
 * Get a driver's assigned deliveries
 * @param driverId The ID of the driver
 * @returns Array of deliveries assigned to the driver
 */
export function getDriverDeliveries(driverId: string): DeliveryLocation[] {
  // In a real app, this would filter based on a driver-delivery assignment table
  // For demo purposes, we'll just assign some deliveries to driver-001
  if (driverId === 'driver-001') {
    return demoDeliveries.filter(d => d.id !== 'delivery-004');
  } else if (driverId === 'driver-002') {
    return demoDeliveries.filter(d => d.id === 'delivery-004');
  }
  
  return [];
}

/**
 * Update the status of a delivery
 * @param deliveryId The ID of the delivery to update
 * @param status The new status of the delivery
 * @returns The updated delivery or null if not found
 */
export function updateDeliveryStatus(
  deliveryId: string,
  status: 'pending' | 'in-progress' | 'completed'
): DeliveryLocation | null {
  const deliveryIndex = demoDeliveries.findIndex(d => d.id === deliveryId);
  
  if (deliveryIndex === -1) {
    return null;
  }
  
  // Update the delivery status
  const updatedDelivery = {
    ...demoDeliveries[deliveryIndex],
    status
  };
  
  // In a real app, this would update a database
  // For demo purposes, we'll just update our array
  demoDeliveries[deliveryIndex] = updatedDelivery;
  
  return updatedDelivery;
}

/**
 * Get statistics for the demo dashboard
 */
export function getDashboardStats() {
  return {
    totalDeliveries: demoDeliveries.length,
    completed: demoDeliveries.filter(d => d.status === 'completed').length,
    inProgress: demoDeliveries.filter(d => d.status === 'in-progress').length,
    pending: demoDeliveries.filter(d => d.status === 'pending').length,
    activeDrivers: demoDrivers.length,
    avgDeliveryTime: 45, // minutes, this would be calculated from actual data in a real app
    onTimeRate: 94 // percentage, this would be calculated from actual data in a real app
  };
}