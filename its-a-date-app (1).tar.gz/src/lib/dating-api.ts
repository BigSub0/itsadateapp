import axios from 'axios';

// Define types for API requests and responses
export interface UserLocation {
  lat: number;
  lng: number;
}

export interface UserPreferences {
  cuisine: string;
  activity: string;
}

export interface SurveyAnswers {
  [key: string]: string;
}

export interface UserProfile {
  userId: string;
  name: string;
  location: UserLocation;
  preferences: UserPreferences;
  surveyAnswers: SurveyAnswers;
}

export interface SurveyQuestion {
  id: string;
  text: string;
  options: string[];
}

export interface Deal {
  title: string;
  price: number;
  description?: string;
  imageUrl?: string;
}

export interface Match {
  user: {
    id: string;
    name: string;
  };
  score: number;
}

export interface SubmitProfileResponse {
  message: string;
  matches: Match[];
  deals: Deal[];
}

// Base API URL - would be configured from environment in production
const BASE_URL = 'http://localhost:3000';

/**
 * API service for the It's A Date application
 */
class DatingApiService {
  /**
   * Get survey questions for a new user
   */
  async getSurveyQuestions(): Promise<SurveyQuestion[]> {
    try {
      const response = await axios.get<SurveyQuestion[]>(`${BASE_URL}/api/survey`);
      return response.data;
    } catch (error) {
      console.error('Error fetching survey questions:', error);
      // Return mock questions in case API is unavailable
      return [
        { id: 'q1', text: "What's your ideal first date?", options: ['Dinner', 'Movie', 'Hiking', 'Museum'] },
        { id: 'q2', text: 'When do you prefer to go out?', options: ['Morning', 'Afternoon', 'Evening'] },
        { id: 'q3', text: "What's your vibe?", options: ['Romantic', 'Casual', 'Adventurous'] },
      ];
    }
  }

  /**
   * Submit user profile with survey answers
   */
  async submitProfile(profile: UserProfile): Promise<SubmitProfileResponse> {
    try {
      const response = await axios.post<SubmitProfileResponse>(`${BASE_URL}/api/submit-profile`, profile);
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        throw new Error(error.response.data.error || 'Failed to submit profile');
      }
      throw new Error('Network error when submitting profile');
    }
  }

  /**
   * Generate a unique ID for new users
   */
  generateUserId(): string {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  /**
   * Get user's current location
   */
  async getUserLocation(): Promise<UserLocation> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        resolve({ lat: 40.7128, lng: -74.0060 }); // Default to NYC
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          // If error, use default position
          resolve({ lat: 40.7128, lng: -74.0060 }); // Default to NYC
        }
      );
    });
  }
}

// Export a singleton instance
export const datingApiService = new DatingApiService();