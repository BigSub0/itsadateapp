import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Truck, DollarSign } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface LoadCardProps {
  load: {
    id: string;
    pickup: {
      address: string;
      time: string;
    };
    delivery: {
      address: string;
      time: string;
    };
    distance: number;
    payment: number;
    status: string;
    urgency: string;
  };
  onAccept: () => void;
}

export const LoadCard: React.FC<LoadCardProps> = ({ load, onAccept }) => {
  const { id, pickup, delivery, distance, payment, urgency } = load;
  
  const formatDateTime = (dateTimeString: string) => {
    const date = new Date(dateTimeString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(date);
  };
  
  const getTimeFromNow = (dateTimeString: string) => {
    try {
      const date = new Date(dateTimeString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return 'time unknown';
    }
  };
  
  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return 'bg-red-500';
      case 'medium':
        return 'bg-amber-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-blue-500';
    }
  };
  
  return (
    <Card className="overflow-hidden">
      <div className={`h-1 ${getUrgencyColor(urgency)}`} />
      <CardContent className="pt-5">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-lg font-semibold">{id}</h3>
          <Badge variant={urgency === 'high' ? 'destructive' : 'outline'}>
            {urgency === 'high' ? 'Urgent' : 'Regular'}
          </Badge>
        </div>
        
        <div className="space-y-3">
          <div className="flex">
            <div className="mr-2 text-blue-500 mt-1">
              <MapPin size={16} />
            </div>
            <div>
              <p className="text-sm font-medium">Pickup</p>
              <p className="text-sm text-muted-foreground">{pickup.address}</p>
              <div className="flex items-center text-xs text-muted-foreground mt-1">
                <Clock size={12} className="mr-1" />
                <span>{formatDateTime(pickup.time)}</span>
                <span className="ml-1">({getTimeFromNow(pickup.time)})</span>
              </div>
            </div>
          </div>
          
          <div className="flex">
            <div className="mr-2 text-green-500 mt-1">
              <MapPin size={16} />
            </div>
            <div>
              <p className="text-sm font-medium">Delivery</p>
              <p className="text-sm text-muted-foreground">{delivery.address}</p>
              <div className="flex items-center text-xs text-muted-foreground mt-1">
                <Clock size={12} className="mr-1" />
                <span>{formatDateTime(delivery.time)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between mt-2 pt-2 border-t text-sm">
            <div className="flex items-center">
              <Truck size={14} className="mr-1 text-muted-foreground" />
              <span>{distance.toFixed(1)} mi</span>
            </div>
            <div className="flex items-center font-semibold">
              <DollarSign size={14} className="mr-1 text-green-600" />
              <span>${payment.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="bg-muted/50 pt-3 pb-3">
        <Button className="w-full" onClick={onAccept}>
          Accept Load
        </Button>
      </CardFooter>
    </Card>
  );
};