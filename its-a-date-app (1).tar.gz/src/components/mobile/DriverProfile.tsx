import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Car, Star, MapPin, BarChart3, Calendar, Phone, Shield, Settings } from 'lucide-react';

interface DriverProps {
  driver: {
    id: string;
    name: string;
    rating: number;
    deliveriesCompleted: number;
    onTimeRate: number;
    vehicle: {
      make: string;
      model: string;
      year: number;
      licensePlate: string;
    };
    earnings: {
      today: number;
      thisWeek: number;
      thisMonth: number;
    };
    status: string;
    location?: {
      latitude: number;
      longitude: number;
    };
    profileImage?: string;
  };
}

export const DriverProfile: React.FC<DriverProps> = ({ driver }) => {
  const {
    id,
    name,
    rating,
    deliveriesCompleted,
    onTimeRate,
    vehicle,
    earnings,
    status,
    profileImage
  } = driver;

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-green-500';
      case 'on_break':
        return 'bg-amber-500';
      case 'offline':
        return 'bg-gray-500';
      default:
        return 'bg-blue-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'Active';
      case 'on_break':
        return 'On Break';
      case 'offline':
        return 'Offline';
      default:
        return status;
    }
  };

  // Format to display currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  return (
    <div className="space-y-4">
      {/* Profile header */}
      <Card>
        <CardContent className="pt-6 pb-4">
          <div className="flex items-center">
            <Avatar className="h-16 w-16 border-2 border-primary">
              {profileImage ? (
                <AvatarImage src={profileImage} alt={name} />
              ) : (
                <AvatarFallback>{getInitials(name)}</AvatarFallback>
              )}
            </Avatar>
            <div className="ml-4">
              <h2 className="text-xl font-bold">{name}</h2>
              <div className="flex items-center mt-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="ml-1 text-sm font-medium">{rating.toFixed(1)}</span>
                <Badge className={`ml-3 ${getStatusColor(status)}`}>
                  {getStatusLabel(status)}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats overview */}
      <Card>
        <CardHeader className="pb-2">
          <h3 className="text-md font-medium">Performance</h3>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Deliveries</p>
              <p className="text-2xl font-semibold">{deliveriesCompleted}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">On-Time Rate</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold">{onTimeRate}%</p>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-sm">
              <span>On-Time Performance</span>
              <span>{onTimeRate}%</span>
            </div>
            <Progress value={onTimeRate} className="mt-2" />
          </div>
        </CardContent>
      </Card>

      {/* Earnings */}
      <Tabs defaultValue="earnings" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="earnings">Earnings</TabsTrigger>
          <TabsTrigger value="vehicle">Vehicle</TabsTrigger>
        </TabsList>
        <TabsContent value="earnings">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Today</span>
                  <span className="font-semibold">{formatCurrency(earnings.today)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">This Week</span>
                  <span className="font-semibold">{formatCurrency(earnings.thisWeek)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">This Month</span>
                  <span className="font-semibold">{formatCurrency(earnings.thisMonth)}</span>
                </div>
                <Button variant="outline" className="w-full mt-2">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  View Earnings Details
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="vehicle">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <Car size={24} className="text-primary mr-3" />
                <div>
                  <p className="font-semibold">{vehicle.year} {vehicle.make} {vehicle.model}</p>
                  <p className="text-sm text-muted-foreground">License: {vehicle.licensePlate}</p>
                </div>
              </div>
              <div className="space-y-3">
                <Button variant="outline" className="w-full">
                  <Calendar className="mr-2 h-4 w-4" />
                  Schedule Maintenance
                </Button>
                <Button variant="outline" className="w-full">
                  <Shield className="mr-2 h-4 w-4" />
                  Update Insurance
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" className="h-12">
          <Phone className="mr-2 h-4 w-4" />
          Support
        </Button>
        <Button variant="outline" className="h-12">
          <Settings className="mr-2 h-4 w-4" />
          Settings
        </Button>
      </div>
    </div>
  );
};