import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { X } from 'lucide-react';

const isIOS = (): boolean => {
  if (typeof window !== 'undefined') {
    const userAgent = window.navigator.userAgent.toLowerCase();
    return /iphone|ipad|ipod/.test(userAgent) && !window.navigator.standalone;
  }
  return false;
};

const InstallPwaPrompt: React.FC = () => {
  const [showPrompt, setShowPrompt] = useState<boolean>(false);
  const [animateIn, setAnimateIn] = useState<boolean>(false);
  const [hasClosedPrompt, setHasClosedPrompt] = useState<boolean>(false);

  useEffect(() => {
    // Check if user is on iOS and whether they've closed the prompt before
    const hasSeenPrompt = localStorage.getItem('pwa-prompt-closed');
    
    if (isIOS() && !hasSeenPrompt) {
      // Delay showing the prompt to let the app load first
      const timer = setTimeout(() => {
        setShowPrompt(true);
        setAnimateIn(true);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const closePrompt = (): void => {
    setAnimateIn(false);
    setHasClosedPrompt(true);
    localStorage.setItem('pwa-prompt-closed', 'true');
    
    // Give time for the animation to complete
    setTimeout(() => {
      setShowPrompt(false);
    }, 300);
  };

  const handleRemindLater = (): void => {
    setAnimateIn(false);
    
    // Close the prompt but don't set it as permanently closed
    setTimeout(() => {
      setShowPrompt(false);
    }, 300);
  };

  if (!showPrompt) return null;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm transition-opacity duration-300 ${animateIn ? 'opacity-100' : 'opacity-0'}`}>
      <Card className={`w-[90%] max-w-md p-6 mx-auto transition-all duration-300 ${animateIn ? 'translate-y-0' : 'translate-y-8'}`}>
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-pink-600">Add to Home Screen</h3>
          <button 
            onClick={closePrompt} 
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Install "It's A Date" on your iPhone for the best experience:
          </p>
          
          <ol className="space-y-3 text-sm text-gray-700">
            <li className="flex items-start gap-2">
              <div className="min-w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs">1</div>
              <div>
                Tap the <span className="inline-flex items-center px-1 bg-gray-100 rounded">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="4 14 10 14 10 20"></polyline>
                    <polyline points="20 10 14 10 14 4"></polyline>
                    <line x1="14" y1="10" x2="21" y2="3"></line>
                    <line x1="3" y1="21" x2="10" y2="14"></line>
                  </svg>
                </span> share button at the bottom of Safari
              </div>
            </li>
            
            <li className="flex items-start gap-2">
              <div className="min-w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs">2</div>
              <div>
                Scroll down and tap <span className="font-medium">Add to Home Screen</span>
              </div>
            </li>
            
            <li className="flex items-start gap-2">
              <div className="min-w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs">3</div>
              <div>
                Tap <span className="font-medium">Add</span> in the top right corner
              </div>
            </li>
          </ol>
          
          <div className="flex flex-col items-center justify-center mt-2 py-2">
            <img 
              src="/assets/icons/icon-192x192.png"
              alt="It's A Date app icon" 
              className="w-16 h-16 rounded-xl shadow-md mb-2"
            />
            <p className="text-xs text-center text-gray-500">
              Enjoy full-screen experience and offline access!
            </p>
          </div>
        </div>
        
        <div className="flex flex-col gap-2 mt-4">
          <Button 
            onClick={handleRemindLater}
            variant="ghost"
            className="w-full"
          >
            Remind me later
          </Button>
          <Button 
            onClick={closePrompt}
            variant="default"
            className="w-full bg-pink-600 hover:bg-pink-700"
          >
            Got it
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default InstallPwaPrompt;