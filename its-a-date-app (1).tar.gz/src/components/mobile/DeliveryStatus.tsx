import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, MapPin, Package, AlertCircle, CheckCircle, Truck } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';

interface DeliveryStatusProps {
  delivery: {
    id: string;
    loadId: string;
    status: string;
    currentLocation: { latitude: number; longitude: number } | null;
    eta: string;
    completedSteps: Array<{ name: string; time: string }>;
    nextStep: string;
    client: string;
    package: {
      type: string;
      weight: number;
      dimensions: string;
    };
  };
  onCompleteStep: () => void;
}

export const DeliveryStatus: React.FC<DeliveryStatusProps> = ({ 
  delivery, 
  onCompleteStep 
}) => {
  const { 
    id, loadId, status, eta, completedSteps, nextStep, client, 
    package: packageDetails
  } = delivery;
  
  // Calculate progress percentage based on completed steps
  const totalSteps = 3; // Pickup, In Transit, Delivery
  const completedStepCount = completedSteps.length;
  const progress = Math.round((completedStepCount / totalSteps) * 100);
  
  const formatDateTime = (dateTimeString: string) => {
    try {
      const date = new Date(dateTimeString);
      return format(date, 'MMM d, h:mm a');
    } catch (e) {
      return 'Invalid date';
    }
  };
  
  const getTimeFromNow = (dateTimeString: string) => {
    try {
      const date = new Date(dateTimeString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return '';
    }
  };
  
  const getStatusColor = () => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'in_progress':
        return 'bg-blue-500';
      case 'pending':
        return 'bg-amber-500';
      case 'exception':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  const getStatusBadge = () => {
    switch (status) {
      case 'completed':
        return <Badge variant="outline" className="border-green-500 text-green-500">Completed</Badge>;
      case 'in_progress':
        return <Badge variant="outline" className="border-blue-500 text-blue-500">In Progress</Badge>;
      case 'pending':
        return <Badge variant="outline" className="border-amber-500 text-amber-500">Pending</Badge>;
      case 'exception':
        return <Badge variant="destructive">Issue Reported</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };
  
  // Determine if the next step button should be shown and what it says
  const getActionButton = () => {
    if (status === 'completed' || nextStep === 'Completed') {
      return null;
    }
    
    return (
      <Button 
        className="w-full mt-2" 
        variant={nextStep === 'Delivery' ? 'default' : 'outline'}
        onClick={onCompleteStep}
      >
        {nextStep === 'Pickup' ? (
          <>
            <Truck size={16} className="mr-2" />
            Start Pickup
          </>
        ) : nextStep === 'In Transit' ? (
          <>
            <Truck size={16} className="mr-2" />
            Start Transit
          </>
        ) : (
          <>
            <CheckCircle size={16} className="mr-2" />
            Complete Delivery
          </>
        )}
      </Button>
    );
  };
  
  return (
    <Card className="overflow-hidden">
      <div className={`h-1 ${getStatusColor()}`} />
      
      <CardContent className="pt-5">
        <div className="flex justify-between items-start mb-1">
          <div>
            <p className="text-xs text-muted-foreground">Delivery #{id}</p>
            <h3 className="text-lg font-semibold">{loadId}</h3>
          </div>
          {getStatusBadge()}
        </div>
        
        {/* Progress bar */}
        <div className="my-3">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between mt-1 text-xs text-muted-foreground">
            <span>Pickup</span>
            <span>In Transit</span>
            <span>Delivery</span>
          </div>
        </div>
        
        {/* Client and package info */}
        <div className="mt-3 space-y-2">
          <div className="flex">
            <div className="mr-2 text-blue-500 mt-0.5">
              <Package size={14} />
            </div>
            <div>
              <p className="text-sm font-medium">{client}</p>
              <p className="text-xs text-muted-foreground">
                {packageDetails.type}, {packageDetails.weight} lbs, {packageDetails.dimensions}
              </p>
            </div>
          </div>
          
          {/* ETA Info */}
          <div className="flex">
            <div className="mr-2 text-amber-500 mt-0.5">
              <Clock size={14} />
            </div>
            <div>
              <p className="text-sm font-medium">Estimated Delivery</p>
              <p className="text-xs text-muted-foreground">
                {formatDateTime(eta)} ({getTimeFromNow(eta)})
              </p>
            </div>
          </div>
        </div>
        
        {/* Timeline of completed steps */}
        <div className="mt-4 space-y-2">
          <p className="text-sm font-medium">Progress</p>
          <div className="pl-6 border-l space-y-4">
            {completedSteps.map((step, index) => (
              <div key={index} className="relative">
                <div className="absolute w-3 h-3 bg-primary rounded-full -left-7 mt-1.5"></div>
                <p className="text-sm font-medium">{step.name}</p>
                <p className="text-xs text-muted-foreground">{formatDateTime(step.time)}</p>
              </div>
            ))}
            
            {nextStep !== 'Completed' && (
              <div className="relative">
                <div className="absolute w-3 h-3 bg-gray-300 rounded-full -left-7 mt-1.5"></div>
                <p className="text-sm text-muted-foreground">{nextStep} - Pending</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Action button */}
        {getActionButton()}
      </CardContent>
    </Card>
  );
};