import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { X } from 'lucide-react';

export const IOSInstallPrompt: React.FC = () => {
  const [isIOS, setIsIOS] = useState(false);
  const [isInStandaloneMode, setIsInStandaloneMode] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const [showSheet, setShowSheet] = useState(false);
  
  useEffect(() => {
    // Detect iOS
    const checkIOS = () => {
      const ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as Window & typeof globalThis & { MSStream?: unknown }).MSStream;
      setIsIOS(ios);
      
      // Check if already installed as PWA
      const standalone = ('standalone' in window.navigator) && ((window.navigator as Navigator & { standalone?: boolean }).standalone);
      setIsInStandaloneMode(standalone);
      
      // Show prompt if iOS and not installed
      const installInstructionsShown = localStorage.getItem('installInstructionsShown');
      setShowPrompt(ios && !standalone && !installInstructionsShown);
      
      // Show sheet after 5 seconds if should show prompt
      if (ios && !standalone && !installInstructionsShown) {
        setTimeout(() => {
          setShowSheet(true);
        }, 5000);
      }
    };
    
    checkIOS();
  }, []);
  
  const handleOpenInstructions = () => {
    window.location.href = '/ios-install.html';
  };
  
  const handleDismiss = () => {
    setShowSheet(false);
    // Set a temporary flag so we don't show again in this session
    sessionStorage.setItem('installPromptDismissed', 'true');
  };

  if (!isIOS || isInStandaloneMode || !showPrompt) {
    return null;
  }
  
  return (
    <>
      {/* Floating button for installation instructions */}
      <div className="fixed bottom-4 right-4 z-50">
        <Button 
          onClick={handleOpenInstructions}
          className="bg-pink-500 hover:bg-pink-600 text-white rounded-full shadow-lg"
        >
          Install App
        </Button>
      </div>
      
      {/* Sheet that appears automatically */}
      <Sheet open={showSheet} onOpenChange={setShowSheet}>
        <SheetContent side="bottom" className="rounded-t-xl bg-gradient-to-br from-pink-500 to-pink-600 text-white">
          <button 
            onClick={handleDismiss}
            className="absolute top-3 right-3 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            aria-label="Close"
          >
            <X size={18} />
          </button>
          <SheetHeader className="pb-4">
            <SheetTitle className="text-white text-2xl font-bold">Install "It's A Date"</SheetTitle>
            <SheetDescription className="text-white/90 text-base">
              For the best experience, install this app on your home screen!
            </SheetDescription>
          </SheetHeader>
          <div className="space-y-4">
            <p className="text-white/90">
              iOS doesn't support automatic installation, but you can easily add this app to your home screen.
            </p>
            <div className="bg-white/20 p-4 rounded-lg space-y-2">
              <p className="flex items-center">
                <span className="bg-white text-pink-500 w-6 h-6 rounded-full inline-flex items-center justify-center mr-2 font-bold">1</span>
                <span>Tap the share icon ↑</span>
              </p>
              <p className="flex items-center">
                <span className="bg-white text-pink-500 w-6 h-6 rounded-full inline-flex items-center justify-center mr-2 font-bold">2</span>
                <span>Select "Add to Home Screen"</span>
              </p>
            </div>
            <div className="flex justify-between pt-4">
              <Button 
                variant="outline" 
                className="bg-transparent border-white text-white hover:bg-white/20 hover:text-white"
                onClick={handleDismiss}
              >
                Later
              </Button>
              <Button 
                className="bg-white text-pink-500 hover:bg-white/90 hover:text-pink-600"
                onClick={handleOpenInstructions}
              >
                Show Full Instructions
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
};

export default IOSInstallPrompt;