import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, ChevronsUpDown, Check, X, CircleAlert, Upload } from 'lucide-react';
import { useCamera } from '@/hooks/useCamera';
import { getGeolocation, formatLocation } from '@/lib/mobile-utils';
import { cn } from '@/lib/utils';

interface DeliveryCaptureProps {
  loadId: string;
  onComplete: (data: {
    photos: string[];
    geolocation: GeolocationCoordinates | null;
    signatureData: string | null;
    notes: string;
    timestamp: string;
  }) => void;
  onCancel: () => void;
}

export const DeliveryCapture: React.FC<DeliveryCaptureProps> = ({
  loadId,
  onComplete,
  onCancel
}) => {
  const { takePicture, selectImage, lastPhoto, cameraError, isCameraAvailable } = useCamera();
  const [photos, setPhotos] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [locationStatus, setLocationStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [location, setLocation] = useState<GeolocationCoordinates | null>(null);
  const [signatureData, setSignatureData] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<'photos' | 'signature' | 'confirmation'>('photos');
  const [uploadingStatus, setUploadingStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');

  // Get the current location when the component mounts
  useEffect(() => {
    const fetchLocation = async () => {
      try {
        const position = await getGeolocation();
        setLocation(position.coords);
        setLocationStatus('success');
      } catch (error) {
        console.error('Error getting location:', error);
        setLocationStatus('error');
      }
    };

    fetchLocation();
  }, []);

  // Add the most recently captured photo to our collection
  useEffect(() => {
    if (lastPhoto && !photos.includes(lastPhoto)) {
      setPhotos(prev => [...prev, lastPhoto]);
    }
  }, [lastPhoto, photos]);

  const handleCapture = async () => {
    try {
      await takePicture({
        quality: 90,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera,
        correctOrientation: true,
        saveToGallery: false
      });
    } catch (error) {
      console.error('Error taking picture:', error);
    }
  };

  const handleSelectImage = async () => {
    try {
      await selectImage({
        quality: 90,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Photos,
        correctOrientation: true
      });
    } catch (error) {
      console.error('Error selecting image:', error);
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  const handleCompletePhotos = () => {
    if (photos.length === 0) {
      alert("Please take at least one photo to continue.");
      return;
    }
    setCurrentStep('signature');
  };

  const handleDrawSignature = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = e.currentTarget;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    let x, y;
    
    if ((e as React.TouchEvent<HTMLCanvasElement>).touches) {
      // Touch event
      const touch = (e as React.TouchEvent<HTMLCanvasElement>).touches[0];
      x = (touch.clientX - rect.left) * scaleX;
      y = (touch.clientY - rect.top) * scaleY;
    } else {
      // Mouse event
      x = ((e as React.MouseEvent<HTMLCanvasElement>).clientX - rect.left) * scaleX;
      y = ((e as React.MouseEvent<HTMLCanvasElement>).clientY - rect.top) * scaleY;
    }
    
    ctx.lineTo(x, y);
    ctx.stroke();
  };
  
  const handleStartDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = e.currentTarget;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.beginPath();
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#000';
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    let x, y;
    
    if ((e as React.TouchEvent<HTMLCanvasElement>).touches) {
      // Touch event
      const touch = (e as React.TouchEvent<HTMLCanvasElement>).touches[0];
      x = (touch.clientX - rect.left) * scaleX;
      y = (touch.clientY - rect.top) * scaleY;
    } else {
      // Mouse event
      x = ((e as React.MouseEvent<HTMLCanvasElement>).clientX - rect.left) * scaleX;
      y = ((e as React.MouseEvent<HTMLCanvasElement>).clientY - rect.top) * scaleY;
    }
    
    ctx.moveTo(x, y);
  };
  
  const handleEndDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = e.currentTarget;
    const signatureDataUrl = canvas.toDataURL('image/png');
    setSignatureData(signatureDataUrl);
  };

  const clearSignature = () => {
    const canvas = document.getElementById('signature-pad') as HTMLCanvasElement;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setSignatureData(null);
    }
  };

  const handleCompleteSignature = () => {
    if (!signatureData) {
      alert("Please sign to confirm delivery.");
      return;
    }
    setCurrentStep('confirmation');
  };

  const handleSubmitVerification = async () => {
    setUploadingStatus('uploading');
    
    try {
      // In a real app, you would upload data to a server here
      // Simulate a network request
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      onComplete({
        photos,
        geolocation: location,
        signatureData,
        notes,
        timestamp: new Date().toISOString()
      });
      
      setUploadingStatus('success');
    } catch (error) {
      console.error('Error submitting verification:', error);
      setUploadingStatus('error');
    }
  };

  // Render based on current step
  if (currentStep === 'photos') {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <h2 className="text-lg font-semibold">Delivery Verification</h2>
          <p className="text-sm text-muted-foreground">
            Take photos of the delivered package
          </p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Location status */}
          <div className={cn(
            "p-2 rounded-md text-sm flex items-center",
            locationStatus === 'loading' ? "bg-amber-50 text-amber-700" : 
            locationStatus === 'success' ? "bg-green-50 text-green-700" :
            "bg-red-50 text-red-700"
          )}>
            {locationStatus === 'loading' ? (
              <>
                <ChevronsUpDown size={16} className="animate-pulse mr-2" />
                <span>Getting your location...</span>
              </>
            ) : locationStatus === 'success' ? (
              <>
                <Check size={16} className="mr-2" />
                <span>Location captured: {formatLocation(location!)}</span>
              </>
            ) : (
              <>
                <CircleAlert size={16} className="mr-2" />
                <span>Couldn't get your location</span>
              </>
            )}
          </div>
          
          {/* Photo capture area */}
          <div className="flex flex-wrap gap-2">
            {photos.map((photo, index) => (
              <div key={index} className="relative w-[calc(33%-8px)] aspect-square">
                <img 
                  src={photo} 
                  alt={`Delivery photo ${index + 1}`} 
                  className="object-cover w-full h-full rounded-md"
                />
                <button 
                  className="absolute -top-2 -right-2 rounded-full bg-red-500 text-white p-1"
                  onClick={() => handleRemovePhoto(index)}
                >
                  <X size={14} />
                </button>
              </div>
            ))}
            
            {photos.length < 4 && (
              <button 
                onClick={handleCapture}
                className="w-[calc(33%-8px)] aspect-square flex items-center justify-center rounded-md border-2 border-dashed border-gray-300 text-gray-400"
                disabled={!isCameraAvailable}
              >
                <Camera size={24} />
              </button>
            )}
          </div>
          
          {/* Photo gallery select button */}
          <Button 
            variant="outline" 
            onClick={handleSelectImage} 
            className="w-full"
            disabled={!isCameraAvailable}
          >
            <Upload className="mr-2 h-4 w-4" />
            Select from gallery
          </Button>
          
          {/* Optional notes */}
          <div className="space-y-2">
            <label className="text-sm" htmlFor="notes">
              Delivery notes (optional):
            </label>
            <textarea
              id="notes"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm min-h-[80px]"
              placeholder="Add any notes about the delivery..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            ></textarea>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={handleCompletePhotos} disabled={photos.length === 0}>
            Continue
          </Button>
        </CardFooter>
      </Card>
    );
  }
  
  if (currentStep === 'signature') {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <h2 className="text-lg font-semibold">Signature Confirmation</h2>
          <p className="text-sm text-muted-foreground">
            Please sign to confirm delivery
          </p>
        </CardHeader>
        
        <CardContent>
          <div className="border rounded-md p-1 bg-white">
            <canvas 
              id="signature-pad" 
              width="400" 
              height="200" 
              className="w-full touch-none"
              onMouseDown={handleStartDrawing}
              onMouseMove={handleDrawSignature}
              onMouseUp={handleEndDrawing}
              onTouchStart={handleStartDrawing}
              onTouchMove={handleDrawSignature}
              onTouchEnd={handleEndDrawing}
            ></canvas>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={clearSignature}
            className="mt-2"
          >
            Clear Signature
          </Button>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => setCurrentStep('photos')}>Back</Button>
          <Button onClick={handleCompleteSignature} disabled={!signatureData}>
            Continue
          </Button>
        </CardFooter>
      </Card>
    );
  }
  
  // Confirmation step
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <h2 className="text-lg font-semibold">Review and Submit</h2>
        <p className="text-sm text-muted-foreground">
          Confirm delivery verification for {loadId}
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <p className="text-sm font-medium">Photos:</p>
          <div className="flex flex-wrap gap-2">
            {photos.map((photo, index) => (
              <div key={index} className="w-[calc(25%-6px)]">
                <img 
                  src={photo} 
                  alt={`Delivery photo ${index + 1}`}
                  className="w-full aspect-square object-cover rounded-md"
                />
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-1">
          <p className="text-sm font-medium">Signature:</p>
          <div className="border rounded-md p-1 bg-white h-[100px] overflow-hidden">
            {signatureData && (
              <img 
                src={signatureData} 
                alt="Signature" 
                className="max-h-full object-contain mx-auto"
              />
            )}
          </div>
        </div>
        
        <div className="space-y-1">
          <p className="text-sm font-medium">Location:</p>
          <p className="text-sm">
            {locationStatus === 'success' ? 
              formatLocation(location!) : 
              'Location not available'
            }
          </p>
        </div>
        
        {notes && (
          <div className="space-y-1">
            <p className="text-sm font-medium">Notes:</p>
            <p className="text-sm">{notes}</p>
          </div>
        )}
        
        <div className="space-y-1">
          <p className="text-sm font-medium">Timestamp:</p>
          <p className="text-sm">{new Intl.DateTimeFormat('en-US', {
            dateStyle: 'medium',
            timeStyle: 'medium'
          }).format(new Date())}</p>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={() => setCurrentStep('signature')}
          disabled={uploadingStatus === 'uploading'}
        >
          Back
        </Button>
        <Button 
          onClick={handleSubmitVerification}
          disabled={uploadingStatus !== 'idle'}
        >
          {uploadingStatus === 'uploading' ? (
            <>
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-b-transparent"></div>
              Submitting...
            </>
          ) : uploadingStatus === 'error' ? (
            'Try Again'
          ) : (
            'Complete Verification'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};