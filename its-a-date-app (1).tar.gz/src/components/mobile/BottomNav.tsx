import React, { useState } from 'react';
import { TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Truck, Package, User, Map } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link, useLocation } from 'react-router-dom';

interface BottomNavProps {
  activeTab?: string;
  onChangeTab?: (tab: string) => void;
}

const BottomNav: React.FC = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('home');

  return (
    <div className="fixed bottom-0 w-full border-t bg-background z-50">
      <TabsList className="w-full grid grid-cols-4 h-16 gap-0">
        <TabsTrigger 
          value="home" 
          onClick={() => setActiveTab('home')}
          className={cn(
            "flex flex-col pt-2 pb-1 h-full rounded-none data-[state=active]:border-t-2 data-[state=active]:border-primary",
            activeTab === 'home' ? 'text-primary' : 'text-muted-foreground'
          )}
          asChild
        >
          <Link to="/">
            <Truck size={20} className="mb-1" />
            <span className="text-xs font-medium">Home</span>
          </Link>
        </TabsTrigger>
        
        <TabsTrigger 
          value="tracking" 
          onClick={() => setActiveTab('tracking')}
          className={cn(
            "flex flex-col pt-2 pb-1 h-full rounded-none data-[state=active]:border-t-2 data-[state=active]:border-primary",
            activeTab === 'tracking' ? 'text-primary' : 'text-muted-foreground'
          )}
          asChild
        >
          <Link to="/tracking">
            <Map size={20} className="mb-1" />
            <span className="text-xs font-medium">Tracking</span>
          </Link>
        </TabsTrigger>
        
        <TabsTrigger 
          value="deliveries" 
          onClick={() => setActiveTab('deliveries')}
          className={cn(
            "flex flex-col pt-2 pb-1 h-full rounded-none data-[state=active]:border-t-2 data-[state=active]:border-primary",
            activeTab === 'deliveries' ? 'text-primary' : 'text-muted-foreground'
          )}
          asChild
        >
          <Link to="/">
            <Package size={20} className="mb-1" />
            <span className="text-xs font-medium">Deliveries</span>
          </Link>
        </TabsTrigger>
        
        <TabsTrigger 
          value="profile" 
          onClick={() => setActiveTab('profile')}
          className={cn(
            "flex flex-col pt-2 pb-1 h-full rounded-none data-[state=active]:border-t-2 data-[state=active]:border-primary",
            activeTab === 'profile' ? 'text-primary' : 'text-muted-foreground'
          )}
          asChild
        >
          <Link to="/">
            <User size={20} className="mb-1" />
            <span className="text-xs font-medium">Profile</span>
          </Link>
        </TabsTrigger>
      </TabsList>
    </div>
  );
};

export default BottomNav;