import React, { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { XIcon, MapPin, DollarSign, Clock, AlertCircle, Check, Package, Info } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface LoadDetail {
  id: string;
  origin: string;
  originAddress: string;
  destination: string;
  destinationAddress: string;
  distance: string;
  type: string;
  urgent: boolean;
  description: string;
  details: string;
  rate: string;
  marketRate: string;
  deadline: string;
  posted: string;
  equipment: string;
  dimensions: string;
  weight: string;
  client: string;
}

// Sample load details for bidding panel
const loadDetails: Record<string, LoadDetail> = {
  "DAT1248": {
    id: "DAT1248",
    origin: "Atlanta, GA",
    originAddress: "1200 Peachtree St NE, Atlanta, GA 30309",
    destination: "Marietta, GA",
    destinationAddress: "560 Johnson Ferry Rd, Marietta, GA 30068",
    distance: "18.7",
    type: "Medical",
    urgent: true,
    description: "Medical specimens - temperature controlled",
    details: "Package contains laboratory samples that must remain at 2-8°C. TempArmour cooler required. HIPAA compliance necessary.",
    rate: "$85.50",
    marketRate: "$75-$95",
    deadline: "Today, 4:30 PM",
    posted: "35 min ago",
    equipment: "Sedan",
    dimensions: "Small package (12\" x 8\" x 6\")",
    weight: "5 lbs",
    client: "LabCorp"
  },
  "DAT3672": {
    id: "DAT3672",
    origin: "Buckhead, Atlanta",
    originAddress: "3400 Peachtree Rd NE, Atlanta, GA 30326",
    destination: "Emory University Hospital",
    destinationAddress: "1364 Clifton Rd NE, Atlanta, GA 30322",
    distance: "7.2",
    type: "Medical",
    urgent: true,
    description: "Medical supplies - critical delivery",
    details: "Urgent medical supplies needed for ongoing procedure. Express delivery required. Medical courier certification preferred.",
    rate: "$62.75",
    marketRate: "$55-$70",
    deadline: "Today, 2:15 PM",
    posted: "22 min ago",
    equipment: "SUV",
    dimensions: "Medium box (18\" x 14\" x 12\")",
    weight: "12 lbs",
    client: "Emory Healthcare"
  },
};

interface BiddingPanelProps {
  loadId: string;
  onClose: () => void;
  onBidSubmit: () => void;
}

export default function BiddingPanel({ loadId, onClose, onBidSubmit }: BiddingPanelProps) {
  const load = loadDetails[loadId] || null;
  
  // Auto-calculated rate, no bidding required
  const baseRate = load?.type === "Medical" ? 43 : 30; // $43 for medical, $30 for general
  const mileageRate = 1.25; // $1.25 per mile
  const mileage = parseFloat(load?.distance || "0");
  const calculatedRate = baseRate + (mileageRate * mileage);
  
  // Since the system is automated, we use the calculated rate directly
  const bidAmount = calculatedRate;
  
  const driverPayout = load?.type === "Medical" 
    ? bidAmount * 0.55 // 55% for medical loads
    : bidAmount * 0.60; // 60% for general loads
  
  const companyProfit = bidAmount - driverPayout;
  const profitMargin = (companyProfit / bidAmount) * 100;
  
  const getMarginClass = () => {
    if (profitMargin >= 25) return "text-green-600";
    if (profitMargin >= 15) return "text-emerald-600";
    if (profitMargin >= 10) return "text-amber-600";
    return "text-red-600";
  };

  if (!load) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p>Load details not available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="sticky top-20">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center">
              {load.id}
              {load.urgent && (
                <Badge variant="outline" className="ml-2 bg-red-100 text-red-800 border-red-200">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Urgent
                </Badge>
              )}
            </CardTitle>
            <div className="text-sm text-muted-foreground mt-1">
              <Badge variant="outline" className={`
                ${load.type === 'Medical' 
                  ? 'bg-red-100 text-red-800 border-red-200' 
                  : 'bg-blue-100 text-blue-800 border-blue-200'}
              `}>
                {load.type}
              </Badge>
              <span className="mx-2">•</span>
              <span>{load.equipment}</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <XIcon className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="py-2">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="text-xs text-blue-600 font-medium mb-1">Origin</div>
              <div className="flex items-center">
                <MapPin className="h-3 w-3 mr-1 text-blue-600" />
                <span className="font-medium">{load.origin}</span>
              </div>
              <div className="text-xs mt-1 line-clamp-1">{load.originAddress}</div>
            </div>
            
            <div className="p-3 bg-red-50 rounded-lg">
              <div className="text-xs text-red-600 font-medium mb-1">Destination</div>
              <div className="flex items-center">
                <MapPin className="h-3 w-3 mr-1 text-red-600" />
                <span className="font-medium">{load.destination}</span>
              </div>
              <div className="text-xs mt-1 line-clamp-1">{load.destinationAddress}</div>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-2 border rounded-md">
              <div className="text-xs text-muted-foreground">Distance</div>
              <div className="font-medium">{load.distance} mi</div>
            </div>
            <div className="p-2 border rounded-md">
              <div className="text-xs text-muted-foreground">Market Rate</div>
              <div className="font-medium">{load.marketRate}</div>
            </div>
            <div className="p-2 border rounded-md">
              <div className="text-xs text-muted-foreground">Deadline</div>
              <div className="font-medium text-sm">{load.deadline}</div>
            </div>
          </div>
          
          <div>
            <div className="font-medium mb-1">Package Details</div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Size:</span>
                <span>{load.dimensions}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-muted-foreground">Weight:</span>
                <span>{load.weight}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-muted-foreground">Client:</span>
                <span>{load.client}</span>
              </div>
            </div>
          </div>
          
          <div>
            <div className="font-medium mb-1">Special Instructions</div>
            <div className="p-3 bg-gray-50 rounded-lg text-sm">
              {load.details}
            </div>
          </div>
          
          <Separator />
          
          <div>
            <div className="flex justify-between items-center mb-2">
              <div className="font-medium">Automated Bid (Bot)</div>
              <div className="text-lg font-bold">${bidAmount.toFixed(2)}</div>
            </div>
            
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 flex items-center gap-1">
                <Info className="h-3 w-3" />
                Automatic rate calculation
              </Badge>
            </div>
            
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg mb-4">
              <div className="flex items-center gap-2 mb-2">
                <Check className="h-4 w-4 text-emerald-600" />
                <span className="text-sm font-medium text-emerald-700">Auto-bidding system active</span>
              </div>
              <p className="text-xs text-emerald-600">Our AI system automatically calculates and submits optimal bids based on market conditions and load parameters. No manual bidding required.</p>
            </div>
            
            <div className="p-3 border border-dashed rounded-lg mb-4">
              <div className="flex justify-between items-center">
                <div className="text-sm">Suggested base rate</div>
                <div className="font-medium">${baseRate.toFixed(2)}</div>
              </div>
              <div className="flex justify-between items-center mt-1">
                <div className="text-sm">Mileage ({mileageRate.toFixed(2)}/mi × {mileage} mi)</div>
                <div className="font-medium">${(mileageRate * mileage).toFixed(2)}</div>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between items-center">
                <div className="text-sm font-medium">Calculated rate</div>
                <div className="font-bold">${calculatedRate.toFixed(2)}</div>
              </div>
            </div>
            
            <div className="p-3 rounded-lg bg-blue-50 mb-4">
              <div className="flex justify-between items-center">
                <div className="text-sm">Driver payout ({load.type === "Medical" ? '55%' : '60%'})</div>
                <div className="font-medium">${driverPayout.toFixed(2)}</div>
              </div>
              <div className="flex justify-between items-center mt-1">
                <div className="text-sm">Company profit</div>
                <div className="font-medium">${companyProfit.toFixed(2)}</div>
              </div>
              <Separator className="my-2 bg-blue-200" />
              <div className="flex justify-between items-center">
                <div className="text-sm font-medium">Profit margin</div>
                <div className={`font-bold ${getMarginClass()}`}>{profitMargin.toFixed(1)}%</div>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">System Notes</label>
              <div className="p-3 bg-gray-50 rounded-lg text-sm">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="h-3 w-3 text-gray-500" />
                  <span className="text-xs text-gray-600">Auto-assignment scheduled for {load.deadline}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Package className="h-3 w-3 text-gray-500" />
                  <span className="text-xs text-gray-600">Driver will be auto-matched based on proximity and qualifications</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex gap-3">
        <Button variant="outline" className="w-full" onClick={onClose}>
          Close
        </Button>
        <Button 
          className="w-full bg-emerald-600 hover:bg-emerald-700"
          onClick={onBidSubmit}
        >
          <Check className="h-4 w-4 mr-2" />
          Accept Auto-Assignment
        </Button>
      </CardFooter>
    </Card>
  );
}