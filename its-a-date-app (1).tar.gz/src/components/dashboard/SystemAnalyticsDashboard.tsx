import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AreaChart } from '@/components/ui/area-chart';
import { BarChart } from '@/components/ui/bar-chart';
import { TrendingUp, TrendingDown, AlertCircle, Clock, DollarSign, Activity, Car } from 'lucide-react';

// Sample data for analytics dashboard
const monthlyDeliveryData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  datasets: [
    {
      label: 'On-Time Deliveries',
      data: [89, 87, 92, 90, 93, 94, 95, 96, 97, 98, 97, 96],
      backgroundColor: 'rgba(52, 152, 219, 0.2)',
      borderColor: 'rgba(52, 152, 219, 1)',
      borderWidth: 2,
      fill: true,
    },
    {
      label: 'Total Deliveries',
      data: [95, 92, 98, 97, 99, 100, 100, 100, 100, 100, 100, 100],
      backgroundColor: 'rgba(211, 211, 211, 0.2)',
      borderColor: 'rgba(211, 211, 211, 1)',
      borderWidth: 2,
      fill: true,
    }
  ]
};

const costOptimizationData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  datasets: [
    {
      label: 'Manual Dispatching Cost',
      data: [12500, 12700, 12400, 12600, 12800, 12900, 12700, 12600, 12300, 12100, 11900, 11800],
      backgroundColor: 'rgba(231, 76, 60, 0.2)',
      borderColor: 'rgba(231, 76, 60, 1)',
      borderWidth: 2,
      fill: true,
    },
    {
      label: 'Automated System Cost',
      data: [12500, 11800, 11200, 10700, 10200, 9800, 9500, 9200, 8900, 8700, 8500, 8300],
      backgroundColor: 'rgba(46, 204, 113, 0.2)',
      borderColor: 'rgba(46, 204, 113, 1)',
      borderWidth: 2,
      fill: true,
    }
  ]
};

const deliveryTypeData = {
  labels: ['Medical', 'Retail', 'Food', 'Documents', 'Electronics', 'Other'],
  datasets: [
    {
      label: 'Deliveries by Type',
      data: [42, 18, 15, 12, 8, 5],
      backgroundColor: [
        'rgba(52, 152, 219, 0.6)',
        'rgba(46, 204, 113, 0.6)',
        'rgba(155, 89, 182, 0.6)',
        'rgba(52, 73, 94, 0.6)',
        'rgba(241, 196, 15, 0.6)',
        'rgba(230, 126, 34, 0.6)'
      ],
      borderColor: [
        'rgba(52, 152, 219, 1)',
        'rgba(46, 204, 113, 1)',
        'rgba(155, 89, 182, 1)',
        'rgba(52, 73, 94, 1)',
        'rgba(241, 196, 15, 1)',
        'rgba(230, 126, 34, 1)'
      ],
      borderWidth: 1,
    }
  ]
};

const driverEfficiencyData = {
  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7', 'Week 8'],
  datasets: [
    {
      label: 'Manual Assignment',
      data: [4.2, 4.3, 4.1, 4.4, 4.3, 4.2, 4.3, 4.4],
      backgroundColor: 'rgba(231, 76, 60, 0.6)',
      borderColor: 'rgba(231, 76, 60, 1)',
      borderWidth: 2,
    },
    {
      label: 'AI Auto-Assignment',
      data: [4.2, 4.5, 4.8, 5.2, 5.7, 6.1, 6.3, 6.5],
      backgroundColor: 'rgba(46, 204, 113, 0.6)',
      borderColor: 'rgba(46, 204, 113, 1)',
      borderWidth: 2,
    }
  ]
};

const hourlyDeliveryData = {
  labels: ['6AM', '8AM', '10AM', '12PM', '2PM', '4PM', '6PM', '8PM', '10PM'],
  datasets: [
    {
      label: 'Deliveries per Hour',
      data: [5, 18, 32, 41, 38, 42, 35, 22, 8],
      backgroundColor: 'rgba(155, 89, 182, 0.6)',
      borderColor: 'rgba(155, 89, 182, 1)',
      borderWidth: 2,
      fill: true,
    }
  ]
};

interface KeyMetric {
  title: string;
  value: string;
  trend: 'up' | 'down' | 'neutral';
  change: string;
  icon: React.ReactNode;
  color: string;
}

const keyMetrics: KeyMetric[] = [
  {
    title: 'On-Time Delivery',
    value: '97.3%',
    trend: 'up',
    change: '+4.2%',
    icon: <Clock className="h-4 w-4" />,
    color: 'text-blue-600'
  },
  {
    title: 'Cost Efficiency',
    value: '$8.42/del',
    trend: 'down',
    change: '-32%',
    icon: <DollarSign className="h-4 w-4" />,
    color: 'text-green-600'
  },
  {
    title: 'Driver Utilization',
    value: '89.5%',
    trend: 'up',
    change: '+16.7%',
    icon: <Car className="h-4 w-4" />,
    color: 'text-purple-600'
  },
  {
    title: 'Avg. Response Time',
    value: '1m 24s',
    trend: 'down',
    change: '-62%',
    icon: <Activity className="h-4 w-4" />,
    color: 'text-amber-600'
  }
];

export default function SystemAnalyticsDashboard() {
  const [timeframe, setTimeframe] = useState<string>('12month');
  const [showProjections, setShowProjections] = useState<boolean>(true);
  
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-semibold">System Analytics Dashboard</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Performance metrics for the automated courier management system
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="3month">Last 3 Months</SelectItem>
                <SelectItem value="6month">Last 6 Months</SelectItem>
                <SelectItem value="12month">Last 12 Months</SelectItem>
                <SelectItem value="ytd">Year to Date</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
              AI Enhanced
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {keyMetrics.map((metric, idx) => (
              <Card key={idx} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className={`p-2 rounded-md ${metric.color.replace('text-', 'bg-').replace('600', '100')}`}>
                      {metric.icon}
                    </div>
                    <div className="flex items-center">
                      {metric.trend === 'up' && (
                        <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      )}
                      {metric.trend === 'down' && (
                        <TrendingDown className="h-4 w-4 text-green-500 mr-1" />
                      )}
                      <span className={`text-xs ${metric.trend === 'up' ? 'text-green-500' : 'text-green-500'}`}>
                        {metric.change}
                      </span>
                    </div>
                  </div>
                  <div className="mt-2">
                    <h3 className="text-sm font-medium text-muted-foreground">{metric.title}</h3>
                    <div className={`text-2xl font-bold ${metric.color}`}>{metric.value}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Tabs for different analytics views */}
          <Tabs defaultValue="performance" className="mt-6">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="cost">Cost Analysis</TabsTrigger>
              <TabsTrigger value="efficiency">Efficiency Gains</TabsTrigger>
            </TabsList>
            
            {/* Performance Tab */}
            <TabsContent value="performance" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">On-Time Delivery Rate</CardTitle>
                    <div className="text-sm text-muted-foreground">Monthly progression</div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="h-[300px]">
                      <AreaChart 
                        data={monthlyDeliveryData}
                        options={{
                          scales: {
                            y: {
                              beginAtZero: false,
                              min: 80,
                              max: 100,
                              title: {
                                display: true,
                                text: 'Percentage (%)'
                              }
                            }
                          },
                          plugins: {
                            tooltip: {
                              callbacks: {
                                label: function(context) {
                                  return `${context.dataset.label}: ${context.parsed.y}%`;
                                }
                              }
                            }
                          }
                        }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Steady improvement
                      </Badge>
                      <div className="text-sm text-muted-foreground">
                        <span className="font-medium text-green-600">+8.2%</span> since automation
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Delivery Types</CardTitle>
                    <div className="text-sm text-muted-foreground">Distribution by category</div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="h-[300px]">
                      <BarChart 
                        data={deliveryTypeData}
                        options={{
                          plugins: {
                            legend: {
                              display: false
                            },
                            tooltip: {
                              callbacks: {
                                label: function(context) {
                                  return `${context.label}: ${context.parsed.y}%`;
                                }
                              }
                            }
                          }
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div className="text-center p-2 bg-blue-50 rounded-md">
                        <div className="text-sm font-medium">Medical</div>
                        <div className="text-xl font-bold text-blue-600">42%</div>
                      </div>
                      <div className="text-center p-2 bg-green-50 rounded-md">
                        <div className="text-sm font-medium">Retail</div>
                        <div className="text-xl font-bold text-green-600">18%</div>
                      </div>
                      <div className="text-center p-2 bg-purple-50 rounded-md">
                        <div className="text-sm font-medium">Food</div>
                        <div className="text-xl font-bold text-purple-600">15%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Hourly Delivery Volume</CardTitle>
                  <div className="text-sm text-muted-foreground">Average deliveries per hour</div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="h-[200px]">
                    <BarChart 
                      data={hourlyDeliveryData}
                      options={{
                        plugins: {
                          legend: {
                            display: false
                          }
                        },
                        scales: {
                          y: {
                            title: {
                              display: true,
                              text: 'Number of Deliveries'
                            }
                          }
                        }
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-sm">
                      <span className="font-medium">Peak hours:</span> 12PM - 6PM
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Auto-scaled driver availability based on demand
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Cost Analysis Tab */}
            <TabsContent value="cost" className="space-y-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Cost Optimization</CardTitle>
                  <div className="text-sm text-muted-foreground">Manual vs. Automated system costs</div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="h-[300px]">
                    <AreaChart 
                      data={costOptimizationData}
                      options={{
                        scales: {
                          y: {
                            title: {
                              display: true,
                              text: 'Monthly Cost ($)'
                            }
                          }
                        }
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center">
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        <TrendingDown className="h-3 w-3 mr-1" />
                        Cost reduction
                      </Badge>
                      <div className="ml-2 text-sm text-muted-foreground">
                        <span className="font-medium text-green-600">-33.6%</span> YTD
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="h-3 w-3 bg-green-500 rounded-full mr-1"></div>
                      <span className="text-sm mr-3">Automated</span>
                      <div className="h-3 w-3 bg-red-500 rounded-full mr-1"></div>
                      <span className="text-sm">Manual</span>
                    </div>
                  </div>
                  <Separator className="my-4" />
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Cost Breakdown (Automated)</h3>
                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">System maintenance</span>
                          <span>$1,870</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">Cloud infrastructure</span>
                          <span>$960</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">Support staff</span>
                          <span>$4,500</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">License fees</span>
                          <span>$970</span>
                        </div>
                        <Separator className="my-2" />
                        <div className="flex justify-between items-center text-sm font-medium">
                          <span>Total monthly cost</span>
                          <span>$8,300</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium mb-2">ROI Analysis</h3>
                      <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">238%</div>
                        <div className="text-sm text-green-700">Annual ROI</div>
                        <Separator className="my-2 bg-green-200" />
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-green-700">Initial investment</span>
                          <span className="font-medium">$85,000</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-green-700">Annual savings</span>
                          <span className="font-medium">$54,000</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-green-700">Payback period</span>
                          <span className="font-medium">19 months</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Efficiency Gains Tab */}
            <TabsContent value="efficiency" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Driver Efficiency</CardTitle>
                    <div className="text-sm text-muted-foreground">Deliveries per driver per hour</div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="h-[300px]">
                      <BarChart 
                        data={driverEfficiencyData}
                        options={{
                          scales: {
                            y: {
                              beginAtZero: false,
                              min: 3.5,
                              title: {
                                display: true,
                                text: 'Deliveries per Hour'
                              }
                            }
                          }
                        }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Significant improvement
                      </Badge>
                      <div className="text-sm text-muted-foreground">
                        <span className="font-medium text-green-600">+52.4%</span> in 8 weeks
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">System Efficiency Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-1 text-sm">
                          <div className="font-medium">Auto-assignment accuracy</div>
                          <div className="font-medium text-green-600">97.8%</div>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="bg-green-500 h-full" style={{ width: '97.8%' }}></div>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Percentage of assignments that don't require manual intervention
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-1 text-sm">
                          <div className="font-medium">Route optimization</div>
                          <div className="font-medium text-green-600">23.4%</div>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="bg-blue-500 h-full" style={{ width: '23.4%' }}></div>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Average mileage reduction compared to manual routing
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-1 text-sm">
                          <div className="font-medium">Dispatch time</div>
                          <div className="font-medium text-green-600">84 seconds</div>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="bg-purple-500 h-full" style={{ width: '96%' }}></div>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Average time from order receipt to driver assignment
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-1 text-sm">
                          <div className="font-medium">Resource utilization</div>
                          <div className="font-medium text-green-600">89.5%</div>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="bg-amber-500 h-full" style={{ width: '89.5%' }}></div>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Average driver time actively delivering vs. idle/waiting
                        </div>
                      </div>
                    </div>

                    <Separator className="my-4" />

                    <div>
                      <h3 className="text-sm font-medium mb-2">AI Enhancement Impact</h3>
                      <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center">
                            <div className="text-xs text-blue-700">Decision Accuracy</div>
                            <div className="text-2xl font-bold text-blue-600">93.7%</div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-blue-700">Learning Rate</div>
                            <div className="text-2xl font-bold text-blue-600">+3.2%</div>
                            <div className="text-xs text-blue-600">monthly</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">System Performance Summary</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-green-50 border border-green-100 rounded-lg">
                        <h3 className="text-sm font-medium text-green-700 mb-1">Peak Performance</h3>
                        <div className="flex justify-between">
                          <div className="text-sm text-green-600">
                            <div>Max deliveries/hour:</div>
                            <div>Max concurrent assignments:</div>
                            <div>Fastest assignment:</div>
                          </div>
                          <div className="text-sm font-medium text-right">
                            <div>126</div>
                            <div>74</div>
                            <div>8.2 seconds</div>
                          </div>
                        </div>
                      </div>
                      <div className="p-3 bg-amber-50 border border-amber-100 rounded-lg">
                        <h3 className="text-sm font-medium text-amber-700 mb-1">System Reliability</h3>
                        <div className="flex justify-between">
                          <div className="text-sm text-amber-600">
                            <div>Uptime:</div>
                            <div>Error rate:</div>
                            <div>Recovery time:</div>
                          </div>
                          <div className="text-sm font-medium text-right">
                            <div>99.98%</div>
                            <div>0.08%</div>
                            <div>1.2 seconds</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 rounded-lg border">
                      <h3 className="text-sm font-medium mb-3">Automated System Benefits</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex items-start gap-2">
                          <div className="mt-0.5">
                            <svg className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">33% lower</span> operational costs compared to manual dispatching
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="mt-0.5">
                            <svg className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">52% increase</span> in driver productivity and efficiency
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="mt-0.5">
                            <svg className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">8.2% improvement</span> in on-time delivery performance
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
}