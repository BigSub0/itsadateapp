import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { InfoIcon, Clock, MapPin, DollarSign, AlertCircle, Package, TrendingUp } from 'lucide-react';

// Sample data for load board items based on the board ID
const mockLoadData = {
  dat: [
    {
      id: "DAT1248",
      origin: "Atlanta, GA",
      destination: "Marietta, GA",
      distance: "18.7 mi",
      type: "Medical",
      urgent: true,
      description: "Medical specimens - temperature controlled",
      rate: "$85.50",
      deadline: "Today, 4:30 PM",
      posted: "35 min ago",
      equipment: "Sedan",
    },
    {
      id: "DAT3672",
      origin: "Buckhead, Atlanta",
      destination: "Emory University Hospital",
      distance: "7.2 mi",
      type: "Medical",
      urgent: true,
      description: "Medical supplies - critical delivery",
      rate: "$62.75",
      deadline: "Today, 2:15 PM",
      posted: "22 min ago",
      equipment: "SUV",
    },
    {
      id: "DAT9823",
      origin: "Downtown Atlanta",
      destination: "Sandy Springs, GA",
      distance: "15.4 mi",
      type: "General",
      urgent: false,
      description: "Office supplies - standard delivery",
      rate: "$43.25",
      deadline: "Tomorrow, 10:00 AM",
      posted: "1 hr ago",
      equipment: "Sedan",
    },
    {
      id: "DAT4531",
      origin: "Peachtree Center",
      destination: "Cumberland Mall",
      distance: "12.8 mi",
      type: "General",
      urgent: false,
      description: "Retail package delivery",
      rate: "$38.50",
      deadline: "Tomorrow, 2:00 PM",
      posted: "45 min ago",
      equipment: "Sedan",
    },
    {
      id: "DAT7765",
      origin: "Grady Memorial Hospital",
      destination: "Children's Healthcare of Atlanta",
      distance: "8.9 mi",
      type: "Medical",
      urgent: true,
      description: "Blood samples - temperature sensitive",
      rate: "$75.25",
      deadline: "Today, 5:45 PM",
      posted: "15 min ago",
      equipment: "Sedan",
    }
  ],
  loadsmart: [
    {
      id: "LS2953",
      origin: "Alpharetta, GA",
      destination: "Atlanta Medical Center",
      distance: "22.1 mi",
      type: "Medical",
      urgent: false,
      description: "Medical equipment delivery",
      rate: "$79.50",
      deadline: "Tomorrow, 9:00 AM",
      posted: "2 hrs ago",
      equipment: "SUV",
    },
    {
      id: "LS8734",
      origin: "Midtown Atlanta",
      destination: "Perimeter Center",
      distance: "14.5 mi",
      type: "General",
      urgent: false,
      description: "Document delivery - standard",
      rate: "$42.75",
      deadline: "Tomorrow, 3:30 PM",
      posted: "1.5 hrs ago",
      equipment: "Sedan",
    },
    {
      id: "LS6219",
      origin: "Northside Hospital",
      destination: "CDC Atlanta",
      distance: "10.2 mi",
      type: "Medical",
      urgent: true,
      description: "Lab samples - urgent transport",
      rate: "$68.50",
      deadline: "Today, 6:15 PM",
      posted: "25 min ago",
      equipment: "Sedan",
    }
  ],
  chrobinson: [
    {
      id: "CH7725",
      origin: "East Point, GA",
      destination: "Hartsfield-Jackson Airport",
      distance: "8.4 mi",
      type: "General",
      urgent: true,
      description: "Time-sensitive package delivery",
      rate: "$55.25",
      deadline: "Today, 7:00 PM",
      posted: "40 min ago",
      equipment: "Sedan",
    },
    {
      id: "CH4418",
      origin: "Piedmont Hospital",
      destination: "Emory Saint Joseph's Hospital",
      distance: "12.7 mi",
      type: "Medical",
      urgent: false,
      description: "Medical supplies delivery",
      rate: "$65.50",
      deadline: "Tomorrow, 11:30 AM",
      posted: "3 hrs ago",
      equipment: "SUV",
    }
  ],
  goshare: []
};

interface LoadBoardTableProps {
  boardId: string;
  onLoadSelect: (loadId: string) => void;
  selectedLoadId: string | null;
}

export default function LoadBoardTable({ boardId, onLoadSelect, selectedLoadId }: LoadBoardTableProps) {
  const loadData = mockLoadData[boardId as keyof typeof mockLoadData] || [];
  
  return (
    <div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[160px]">ID/Details</TableHead>
            <TableHead>Origin/Destination</TableHead>
            <TableHead>Type</TableHead>
            <TableHead className="w-[120px]">Rate</TableHead>
            <TableHead className="w-[120px] text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {loadData.length > 0 ? (
            loadData.map((load) => (
              <TableRow 
                key={load.id} 
                className={`${selectedLoadId === load.id ? 'bg-blue-50' : ''}`}
              >
                <TableCell className="font-medium">
                  <div className="flex flex-col">
                    <div className="flex items-center">
                      <span>{load.id}</span>
                      {load.urgent && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="ml-2">
                                <AlertCircle className="h-4 w-4 text-red-500" />
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Urgent delivery</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center">
                      <Package className="h-3 w-3 mr-1" />
                      <span>{load.equipment}</span>
                      <span className="mx-1">•</span>
                      <span>{load.distance}</span>
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Posted {load.posted}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1 text-blue-500" />
                      <span>{load.origin}</span>
                    </div>
                    <div className="flex items-center mt-1">
                      <MapPin className="h-3 w-3 mr-1 text-red-500" />
                      <span>{load.destination}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      <span>Due: {load.deadline}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={`
                    ${load.type === 'Medical' 
                      ? 'bg-red-100 text-red-800 border-red-200' 
                      : 'bg-blue-100 text-blue-800 border-blue-200'}
                  `}>
                    {load.type}
                  </Badge>
                  <div className="text-xs text-muted-foreground mt-2 line-clamp-1">
                    {load.description}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    <span className="font-medium">{load.rate}</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    onClick={() => onLoadSelect(load.id)} 
                    className={`${selectedLoadId === load.id ? 'bg-blue-700' : 'bg-blue-600'} hover:bg-blue-700`}
                    size="sm"
                  >
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Bid
                  </Button>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={5} className="h-24 text-center">
                {boardId === 'goshare' 
                  ? "Connect to GoShare to view available loads" 
                  : "No loads available at this time"}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}