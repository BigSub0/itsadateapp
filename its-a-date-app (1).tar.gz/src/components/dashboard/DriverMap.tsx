import React, { useEffect, useRef, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

interface Driver {
  id: string;
  name: string;
  status: string;
  location: {
    lat: number;
    lng: number;
    lastUpdate: string;
    address: string;
  };
  vehicle: string;
  medicalCertified: boolean;
}

interface DriverMapProps {
  drivers: Driver[];
  selectedDriverId: string | null;
  onDriverSelect: (driverId: string) => void;
  center: { lat: number, lng: number };
}

export default function DriverMap({ 
  drivers, 
  selectedDriverId, 
  onDriverSelect, 
  center 
}: DriverMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  interface MapObject {
    center: { lat: number, lng: number };
    zoom: number;
  }

  interface Marker {
    id: string;
    position: {
      lat: number;
      lng: number;
    };
    title: string;
    icon: string;
    status: string;
  }

  const [mapObject, setMapObject] = useState<MapObject | null>(null);
  const [markers, setMarkers] = useState<Marker[]>([]);
  
  // In a real implementation, this would use the Google Maps API
  // This is a placeholder visualization
  
  // Simulate map loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setMapLoaded(true);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Create simple visualization of driver positions
  useEffect(() => {
    if (mapLoaded && mapRef.current) {
      // In a real implementation, this would initialize the Google Maps instance
      console.log("Map would be initialized here with Google Maps API");
      
      // Set a placeholder map object
      setMapObject({
        center: center,
        zoom: 10
      });
    }
  }, [mapLoaded, center]);
  
  // Update driver markers when drivers change or map loads
  useEffect(() => {
    if (mapLoaded && mapObject) {
      // In a real implementation, this would create Google Maps markers
      // Clear existing markers
      markers.forEach(marker => {
        // marker.setMap(null) would be called here
      });
      
      // Create new markers
      const newMarkers = drivers.map(driver => {
        // Create marker
        return {
          id: driver.id,
          position: driver.location,
          title: driver.name,
          icon: driver.medicalCertified ? 'medical-pin' : 'standard-pin',
          status: driver.status
        };
      });
      
      setMarkers(newMarkers);
    }
  }, [drivers, mapLoaded, mapObject]);
  
  return (
    <div className="relative w-full h-full">
      {!mapLoaded ? (
        <Skeleton className="w-full h-full rounded-none" />
      ) : (
        <div className="w-full h-full bg-gray-100 relative">
          {/* Placeholder Map Rendering */}
          <div ref={mapRef} className="w-full h-full bg-blue-50 flex items-center justify-center">
            <div className="absolute inset-0">
              {/* This simulates the map - would be replaced with Google Maps */}
              <div className="w-full h-full bg-[#e8f0f9]">
                {/* Simulate roads */}
                <div className="absolute left-1/4 right-1/4 top-1/4 bottom-1/4 bg-[#d6e6f9]" />
                <div className="absolute left-[10%] right-[10%] top-[40%] h-2 bg-[#a8c9f0]" />
                <div className="absolute left-[45%] top-[10%] bottom-[10%] w-2 bg-[#a8c9f0]" />
              
                {/* Render markers */}
                {markers.map((marker, idx) => {
                  const isSelected = selectedDriverId === marker.id;
                  const statusColors: Record<string, string> = {
                    active: 'bg-green-500',
                    delivering: 'bg-blue-500',
                    available: 'bg-emerald-500',
                    offline: 'bg-gray-500'
                  };
                  
                  // Calculate position based on lat/lng
                  // In a real map these would be proper coordinates
                  const left = `${((marker.position.lng + 84.5) * 100) % 80 + 10}%`;
                  const top = `${((marker.position.lat - 33.7) * 100) % 80 + 10}%`;
                  
                  return (
                    <div
                      key={idx}
                      className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer
                        ${isSelected ? 'z-10' : 'z-0'}`}
                      style={{ left, top }}
                      onClick={() => onDriverSelect(marker.id)}
                    >
                      <div className={`
                        ${isSelected ? 'w-12 h-12 border-4' : 'w-10 h-10 border-2'} 
                        rounded-full border-white ${statusColors[marker.status] || 'bg-gray-500'} 
                        shadow-lg flex items-center justify-center transition-all
                      `}>
                        <div className="text-white font-medium">
                          {marker.title.split(' ').map((n: string) => n[0]).join('')}
                        </div>
                      </div>
                      {isSelected && (
                        <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded-md shadow-md text-xs whitespace-nowrap">
                          {marker.title}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="absolute bottom-4 left-4 bg-white p-2 rounded shadow z-10 text-xs">
              <div className="font-medium mb-1">Driver Status</div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span>Active</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span>On Delivery</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                  <span>Available</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                  <span>Offline</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm rounded shadow-md px-3 py-2 z-10">
        <div className="text-sm font-medium">Driver Location</div>
        <div className="text-xs text-muted-foreground">
          {mapLoaded ? `${drivers.length} drivers tracked` : "Loading map..."}
        </div>
      </div>
    </div>
  );
}