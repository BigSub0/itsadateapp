import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Check, AlertTriangle, MapPin, Shield, Clock, Activity } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { motion, AnimatePresence } from 'framer-motion';

// Sample data for driver auto-assignment demonstration
interface Driver {
  id: string;
  name: string;
  avatar: string;
  status: 'available' | 'busy' | 'offline';
  location: string;
  distance: number; // miles from pickup
  rating: number;
  qualifications: string[];
  vehicle: string;
  matchScore: number;
  lastActive: string;
}

interface Load {
  id: string;
  type: string;
  origin: string;
  destination: string;
  requiresMedical: boolean;
  requiresSpecial: boolean;
  urgent: boolean;
  deadline: string;
  distance: number;
}

// Sample drivers data
const sampleDrivers: Driver[] = [
  {
    id: "DR1204",
    name: "James Wilson",
    avatar: "",
    status: "available",
    location: "Atlanta Downtown",
    distance: 2.4,
    rating: 4.8,
    qualifications: ["Medical", "Temperature Controlled"],
    vehicle: "Sedan",
    matchScore: 92,
    lastActive: "Just now"
  },
  {
    id: "DR0873",
    name: "Michael Chen",
    avatar: "",
    status: "available",
    location: "Buckhead",
    distance: 4.1,
    rating: 4.9,
    qualifications: ["Medical", "Hazardous"],
    vehicle: "SUV",
    matchScore: 85,
    lastActive: "2 min ago"
  },
  {
    id: "DR2536",
    name: "Sarah Johnson",
    avatar: "",
    status: "available",
    location: "Marietta",
    distance: 7.8,
    rating: 4.7,
    qualifications: ["Medical"],
    vehicle: "Sedan",
    matchScore: 78,
    lastActive: "5 min ago"
  },
  {
    id: "DR0494",
    name: "Raj Patel",
    avatar: "",
    status: "busy",
    location: "Decatur",
    distance: 6.2,
    rating: 4.9,
    qualifications: ["Medical", "Temperature Controlled"],
    vehicle: "Van",
    matchScore: 75,
    lastActive: "10 min ago"
  },
  {
    id: "DR1358",
    name: "Emma Garcia",
    avatar: "",
    status: "available",
    location: "Sandy Springs",
    distance: 8.4,
    rating: 4.5,
    qualifications: ["Temperature Controlled"],
    vehicle: "Sedan",
    matchScore: 71,
    lastActive: "3 min ago"
  }
];

// Sample active loads
const activeLoads: Load[] = [
  {
    id: "DAT1248",
    type: "Medical",
    origin: "Atlanta, GA",
    destination: "Marietta, GA",
    requiresMedical: true,
    requiresSpecial: true,
    urgent: true,
    deadline: "Today, 4:30 PM",
    distance: 18.7
  },
  {
    id: "DAT3672",
    type: "Medical",
    origin: "Buckhead, Atlanta",
    destination: "Emory University Hospital",
    requiresMedical: true,
    requiresSpecial: false,
    urgent: true,
    deadline: "Today, 2:15 PM",
    distance: 7.2
  }
];

export default function DriverAutoAssignment() {
  const [selectedLoad, setSelectedLoad] = useState<Load>(activeLoads[0]);
  const [availableDrivers, setAvailableDrivers] = useState<Driver[]>([]);
  const [assignmentProcess, setAssignmentProcess] = useState<string>('analyzing');
  const [assignmentProgress, setAssignmentProgress] = useState<number>(0);
  const [assignedDriver, setAssignedDriver] = useState<Driver | null>(null);
  const [systemStatus, setSystemStatus] = useState<'operational' | 'learning' | 'warning'>('operational');

  // Filter drivers based on selected load and simulate the assignment process
  useEffect(() => {
    // Reset assignment state
    setAssignmentProcess('analyzing');
    setAssignmentProgress(0);
    setAssignedDriver(null);
    
    // Filter available drivers
    const filteredDrivers = sampleDrivers.filter(driver => 
      driver.status === 'available' && 
      (!selectedLoad.requiresMedical || driver.qualifications.includes('Medical')) &&
      (!selectedLoad.requiresSpecial || driver.qualifications.includes('Temperature Controlled'))
    ).sort((a, b) => b.matchScore - a.matchScore);
    
    setAvailableDrivers(filteredDrivers);
    
    // Simulated assignment progress
    const progressInterval = setInterval(() => {
      setAssignmentProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setAssignmentProcess('completed');
          setAssignedDriver(filteredDrivers[0]);
          return 100;
        }
        
        // Update the process description based on progress
        if (prev === 0) setAssignmentProcess('analyzing');
        else if (prev >= 25 && prev < 50) setAssignmentProcess('matching');
        else if (prev >= 50 && prev < 75) setAssignmentProcess('optimizing');
        else if (prev >= 75) setAssignmentProcess('finalizing');
        
        return prev + 5;
      });
    }, 300);
    
    return () => clearInterval(progressInterval);
  }, [selectedLoad]);

  // Get an appropriate label for the assignment process
  const getProcessLabel = () => {
    switch (assignmentProcess) {
      case 'analyzing': return 'Analyzing load requirements...';
      case 'matching': return 'Matching qualified drivers...';
      case 'optimizing': return 'Optimizing for proximity and ETA...';
      case 'finalizing': return 'Finalizing driver selection...';
      case 'completed': return 'Assignment complete';
      default: return 'Processing...';
    }
  };
  
  // Get color based on system status
  const getSystemStatusColor = () => {
    switch (systemStatus) {
      case 'operational': return 'bg-green-500';
      case 'learning': return 'bg-blue-500';
      case 'warning': return 'bg-amber-500';
      default: return 'bg-green-500';
    }
  };
  
  // Get badge color based on driver distance
  const getDistanceBadgeColor = (distance: number) => {
    if (distance < 3) return 'bg-green-100 text-green-800 border-green-200';
    if (distance < 6) return 'bg-blue-100 text-blue-800 border-blue-200';
    if (distance < 10) return 'bg-amber-100 text-amber-800 border-amber-200';
    return 'bg-gray-100 text-gray-800 border-gray-200';
  };

  // Get match quality indicator
  const getMatchIndicator = (score: number) => {
    if (score >= 90) return { color: 'text-green-600', label: 'Excellent match' };
    if (score >= 80) return { color: 'text-emerald-600', label: 'Great match' };
    if (score >= 70) return { color: 'text-blue-600', label: 'Good match' };
    if (score >= 60) return { color: 'text-amber-600', label: 'Fair match' };
    return { color: 'text-gray-600', label: 'Limited match' };
  };

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold">Auto-Assignment System</CardTitle>
          <div className="flex items-center gap-2">
            <div className="text-sm">System Status:</div>
            <div className="flex items-center gap-2">
              <div className={`h-2 w-2 rounded-full ${getSystemStatusColor()}`} />
              <div className="text-sm font-medium">
                {systemStatus === 'operational' ? 'Operational' : 
                 systemStatus === 'learning' ? 'Learning Mode' : 'Attention Required'}
              </div>
            </div>
          </div>
        </div>
        <div className="text-sm text-muted-foreground">
          AI-powered driver matching and automated assignment
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {/* Load Selection */}
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Active Load for Assignment</h3>
            <div className="grid grid-cols-2 gap-2">
              {activeLoads.map(load => (
                <div 
                  key={load.id}
                  className={`p-3 rounded-lg cursor-pointer border-2 transition-all ${
                    selectedLoad.id === load.id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedLoad(load)}
                >
                  <div className="flex justify-between items-start">
                    <div className="font-medium">{load.id}</div>
                    <Badge variant="outline" className={`
                      ${load.type === 'Medical' 
                        ? 'bg-red-100 text-red-800 border-red-200' 
                        : 'bg-blue-100 text-blue-800 border-blue-200'}`}
                    >
                      {load.type}
                    </Badge>
                  </div>
                  <div className="flex items-center text-sm mt-1">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span className="text-muted-foreground mr-1">{load.origin}</span>
                    <span className="mx-1">→</span>
                    <span className="text-muted-foreground">{load.destination}</span>
                  </div>
                  <div className="flex mt-2 gap-1">
                    {load.urgent && (
                      <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200 text-xs">
                        Urgent
                      </Badge>
                    )}
                    <Badge variant="outline" className="bg-gray-100 text-xs">
                      {load.distance} mi
                    </Badge>
                    <Badge variant="outline" className="bg-gray-100 text-xs">
                      {load.deadline}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Assignment Process Visualization */}
          <div className="bg-gray-50 p-4 rounded-lg border relative overflow-hidden mb-4">
            <h3 className="text-sm font-medium mb-2">Assignment Process</h3>
            <div className="relative">
              <Progress value={assignmentProgress} className="h-2 mb-2" />
              <div className="flex justify-between items-center">
                <div className="text-sm font-medium">{getProcessLabel()}</div>
                <div className="text-sm">{assignmentProgress}%</div>
              </div>
              
              {/* Process stages visualization */}
              <div className="flex justify-between mt-4 relative">
                <div className="absolute top-[10px] left-0 right-0 h-1 bg-gray-200 -z-10"></div>
                
                {['Analyze', 'Match', 'Optimize', 'Assign'].map((stage, idx) => {
                  const isComplete = 
                    (idx === 0 && assignmentProgress >= 25) || 
                    (idx === 1 && assignmentProgress >= 50) ||
                    (idx === 2 && assignmentProgress >= 75) ||
                    (idx === 3 && assignmentProgress >= 100);
                  
                  const isActive =
                    (idx === 0 && assignmentProgress < 25) ||
                    (idx === 1 && assignmentProgress >= 25 && assignmentProgress < 50) ||
                    (idx === 2 && assignmentProgress >= 50 && assignmentProgress < 75) ||
                    (idx === 3 && assignmentProgress >= 75 && assignmentProgress < 100);
                  
                  return (
                    <div key={stage} className="flex flex-col items-center z-10">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                        isComplete ? 'bg-green-500' : isActive ? 'bg-blue-500' : 'bg-gray-300'
                      }`}>
                        {isComplete && <Check className="h-3 w-3 text-white" />}
                        {!isComplete && !isActive && <div className="w-2 h-2 bg-gray-100 rounded-full"></div>}
                        {isActive && <div className="w-2 h-2 bg-white rounded-full"></div>}
                      </div>
                      <div className={`text-xs mt-1 ${isComplete ? 'text-green-600' : isActive ? 'text-blue-600 font-medium' : 'text-gray-500'}`}>
                        {stage}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          
          {/* Matching Drivers */}
          <div>
            <h3 className="text-sm font-medium mb-2">
              {assignmentProcess === 'completed' ? 'Selected Driver' : 'Matching Drivers'} 
              <span className="text-muted-foreground ml-1">({assignmentProcess === 'completed' ? 1 : availableDrivers.length})</span>
            </h3>
            
            <div className="space-y-2">
              <AnimatePresence>
                {assignmentProcess === 'completed' ? (
                  // Show only the assigned driver when completed
                  assignedDriver && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      key={assignedDriver.id}
                      className="p-4 bg-green-50 border border-green-200 rounded-lg"
                    >
                      <div className="flex justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>{assignedDriver.name.substring(0, 2)}</AvatarFallback>
                            {assignedDriver.avatar && <AvatarImage src={assignedDriver.avatar} alt={assignedDriver.name} />}
                          </Avatar>
                          <div>
                            <div className="font-medium">{assignedDriver.name}</div>
                            <div className="text-sm text-muted-foreground">{assignedDriver.id}</div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <Badge className="bg-green-500">Assigned</Badge>
                          <div className="text-sm mt-1">
                            <span className="font-medium">ETA:</span> {Math.ceil(assignedDriver.distance * 2)} min
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mt-3">
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span>{assignedDriver.location}</span>
                          <Badge variant="outline" className={getDistanceBadgeColor(assignedDriver.distance)}>
                            {assignedDriver.distance} mi away
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Shield className="h-3 w-3 text-muted-foreground" />
                          <span>{assignedDriver.qualifications.join(', ')}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          <span>Last active: {assignedDriver.lastActive}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Activity className="h-3 w-3 text-muted-foreground" />
                          <span>Rating: {assignedDriver.rating}/5</span>
                        </div>
                      </div>
                      
                      <div className="mt-3 bg-white rounded-md p-2 border">
                        <div className="text-xs text-muted-foreground mb-1">Match Score</div>
                        <div className="flex items-center justify-between">
                          <div className="w-full bg-gray-100 rounded-full h-2.5">
                            <div 
                              className="bg-green-500 h-2.5 rounded-full transition-all" 
                              style={{ width: `${assignedDriver.matchScore}%` }}
                            ></div>
                          </div>
                          <div className="ml-2 font-medium">{assignedDriver.matchScore}%</div>
                        </div>
                        <div className={`text-xs mt-1 ${getMatchIndicator(assignedDriver.matchScore).color}`}>
                          {getMatchIndicator(assignedDriver.matchScore).label}
                        </div>
                      </div>
                      
                      <div className="mt-3 text-sm text-green-700 bg-green-100 p-2 rounded-md">
                        <Check className="h-4 w-4 inline mr-1" />
                        Driver automatically notified and confirmed pickup
                      </div>
                    </motion.div>
                  )
                ) : (
                  // Show the matching process for available drivers
                  availableDrivers.map((driver, index) => (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      key={driver.id}
                      className={`p-3 border rounded-lg ${
                        index === 0 ? 'bg-blue-50 border-blue-200' : 'bg-white'
                      }`}
                    >
                      <div className="flex justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>{driver.name.substring(0, 2)}</AvatarFallback>
                            {driver.avatar && <AvatarImage src={driver.avatar} alt={driver.name} />}
                          </Avatar>
                          <div>
                            <div className="font-medium">{driver.name}</div>
                            <div className="text-xs text-muted-foreground">{driver.id}</div>
                          </div>
                        </div>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="w-[60px]">
                                <div className="flex items-center justify-between mb-0.5">
                                  <div className="text-xs">Match</div>
                                  <div className="text-xs font-medium">{driver.matchScore}%</div>
                                </div>
                                <div className="w-full bg-gray-100 rounded-full h-1.5">
                                  <div 
                                    className="bg-blue-500 h-1.5 rounded-full" 
                                    style={{ width: `${driver.matchScore}%` }}
                                  ></div>
                                </div>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <div className="text-xs">
                                Match score considers: proximity, qualifications, rating, and vehicle type
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-x-2 gap-y-1 mt-2">
                        <div className="flex items-center gap-1 text-xs">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <Badge variant="outline" className={`${getDistanceBadgeColor(driver.distance)} text-xs`}>
                            {driver.distance} mi
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1 text-xs col-span-2">
                          <Shield className="h-3 w-3 text-muted-foreground" />
                          <span className="truncate">{driver.qualifications.join(', ')}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
              
              {availableDrivers.length === 0 && assignmentProcess !== 'completed' && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    <div className="font-medium text-amber-700">No matching drivers found</div>
                  </div>
                  <p className="text-sm text-amber-600 mt-1">
                    Expanding search radius and sending alerts to nearby drivers...
                  </p>
                </div>
              )}
            </div>
          </div>
          
          {/* System Log */}
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2 flex items-center justify-between">
              <span>System Activity Log</span>
              <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Auto-updating</Badge>
            </h3>
            <div className="bg-gray-50 border rounded-lg p-3 max-h-[140px] overflow-y-auto text-xs space-y-2">
              <div className="flex gap-2">
                <div className="text-green-600 shrink-0">[{new Date().toLocaleTimeString()}]</div>
                <div>Driver auto-assignment process completed for load {selectedLoad.id}.</div>
              </div>
              <div className="flex gap-2">
                <div className="text-blue-600 shrink-0">[{new Date(Date.now() - 60000).toLocaleTimeString()}]</div>
                <div>Comparing 5 qualified drivers based on proximity, ETA, and vehicle type.</div>
              </div>
              <div className="flex gap-2">
                <div className="text-blue-600 shrink-0">[{new Date(Date.now() - 120000).toLocaleTimeString()}]</div>
                <div>Analyzing load requirements for {selectedLoad.type} delivery from {selectedLoad.origin}.</div>
              </div>
              <div className="flex gap-2">
                <div className="text-green-600 shrink-0">[{new Date(Date.now() - 300000).toLocaleTimeString()}]</div>
                <div>Driver DR0873 successfully completed delivery for load DAT9274.</div>
              </div>
              <div className="flex gap-2">
                <div className="text-amber-600 shrink-0">[{new Date(Date.now() - 600000).toLocaleTimeString()}]</div>
                <div>Load DAT8521 rescheduled due to traffic delays.</div>
              </div>
            </div>
          </div>
          
          {/* AI System Stats */}
          <div className="mt-4">
            <Separator className="mb-4" />
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600">97.8%</div>
                <div className="text-xs text-muted-foreground">Assignment Accuracy</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-emerald-600">93.2%</div>
                <div className="text-xs text-muted-foreground">On-time Deliveries</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">89.5%</div>
                <div className="text-xs text-muted-foreground">First Match Success</div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}