import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { 
  MapPin, 
  PackageCheck, 
  Package, 
  Clock, 
  Calendar, 
  ChevronDown, 
  Search, 
  User, 
  Phone, 
  Truck, 
  CheckCircle2, 
  AlertCircle,
  CircleAlert
} from 'lucide-react';

// Types
interface DeliveryLocation {
  lat: number;
  lng: number;
  address: string;
}

interface DeliveryStep {
  status: string;
  time: string;
  location?: string;
  description: string;
  completed: boolean;
}

interface Driver {
  id: string;
  name: string;
  avatar: string;
  phone: string;
  vehicle: string;
  rating: number;
}

interface Delivery {
  id: string;
  orderNumber: string;
  status: 'in-transit' | 'delivered' | 'pending' | 'exception';
  type: string;
  origin: DeliveryLocation;
  destination: DeliveryLocation;
  currentLocation?: DeliveryLocation;
  progress: number;
  eta: string;
  pickupTime: string;
  deliveryTime?: string;
  deadline: string;
  customer: {
    name: string;
    phone: string;
  };
  driver?: Driver;
  steps: DeliveryStep[];
  items: string[];
  priority: 'standard' | 'express' | 'urgent';
}

// Sample data
const activeDeliveries: Delivery[] = [
  {
    id: "DEL-20231215-004A",
    orderNumber: "ORD-78452",
    status: "in-transit",
    type: "Medical",
    origin: {
      lat: 33.749,
      lng: -84.388,
      address: "Northside Hospital, 1000 Johnson Ferry Rd NE, Atlanta, GA 30342"
    },
    destination: {
      lat: 33.781,
      lng: -84.412,
      address: "Emory University Hospital, 1364 Clifton Rd NE, Atlanta, GA 30322"
    },
    currentLocation: {
      lat: 33.767,
      lng: -84.405,
      address: "Peachtree Rd NE, Atlanta, GA"
    },
    progress: 68,
    eta: "12:45 PM",
    pickupTime: "11:30 AM",
    deadline: "1:00 PM",
    customer: {
      name: "Dr. Sarah Johnson",
      phone: "404-555-7890"
    },
    driver: {
      id: "DRV-1204",
      name: "James Wilson",
      avatar: "",
      phone: "404-555-1234",
      vehicle: "Toyota Prius (White) • AXJ-8274",
      rating: 4.8
    },
    steps: [
      {
        status: "Order Received",
        time: "11:05 AM",
        description: "Medical delivery request received",
        completed: true
      },
      {
        status: "Driver Assigned",
        time: "11:07 AM",
        description: "James Wilson assigned automatically",
        completed: true
      },
      {
        status: "Pickup",
        time: "11:30 AM",
        location: "Northside Hospital",
        description: "Package picked up",
        completed: true
      },
      {
        status: "In Transit",
        time: "11:32 AM",
        description: "En route to destination",
        completed: true
      },
      {
        status: "Delivery",
        time: "12:45 PM (Expected)",
        location: "Emory University Hospital",
        description: "Package delivery",
        completed: false
      }
    ],
    items: ["Temperature-controlled medical samples", "Urgent lab specimens"],
    priority: "urgent"
  },
  {
    id: "DEL-20231215-006B",
    orderNumber: "ORD-78455",
    status: "pending",
    type: "Retail",
    origin: {
      lat: 33.848,
      lng: -84.362,
      address: "Lenox Square Mall, 3393 Peachtree Rd NE, Atlanta, GA 30326"
    },
    destination: {
      lat: 33.787,
      lng: -84.323,
      address: "2500 Parkview Dr, Atlanta, GA 30305"
    },
    progress: 10,
    eta: "2:15 PM",
    pickupTime: "1:30 PM",
    deadline: "3:00 PM",
    customer: {
      name: "Michael Chen",
      phone: "404-555-3456"
    },
    steps: [
      {
        status: "Order Received",
        time: "12:45 PM",
        description: "Retail delivery request received",
        completed: true
      },
      {
        status: "Driver Assignment",
        time: "In progress",
        description: "Finding optimal driver based on location and current loads",
        completed: false
      },
      {
        status: "Pickup",
        time: "Scheduled for 1:30 PM",
        location: "Lenox Square Mall",
        description: "Package pickup",
        completed: false
      },
      {
        status: "In Transit",
        time: "Pending",
        description: "En route to destination",
        completed: false
      },
      {
        status: "Delivery",
        time: "Expected by 2:15 PM",
        location: "2500 Parkview Dr",
        description: "Package delivery",
        completed: false
      }
    ],
    items: ["Electronics", "Clothing items"],
    priority: "standard"
  }
];

const historyDeliveries: Delivery[] = [
  {
    id: "DEL-20231214-009C",
    orderNumber: "ORD-78431",
    status: "delivered",
    type: "Medical",
    origin: {
      lat: 33.8121,
      lng: -84.3571,
      address: "Piedmont Hospital, 1968 Peachtree Rd NW, Atlanta, GA 30309"
    },
    destination: {
      lat: 33.7756,
      lng: -84.3963,
      address: "1800 Howell Mill Rd NW, Atlanta, GA 30318"
    },
    progress: 100,
    eta: "Delivered",
    pickupTime: "2:15 PM",
    deliveryTime: "2:45 PM",
    deadline: "3:00 PM",
    customer: {
      name: "Emma Rodriguez",
      phone: "404-555-8901"
    },
    driver: {
      id: "DRV-0873",
      name: "Michael Chen",
      avatar: "",
      phone: "404-555-5678",
      vehicle: "Honda Civic (Blue) • XYZ-9283",
      rating: 4.9
    },
    steps: [
      {
        status: "Order Received",
        time: "1:45 PM",
        description: "Medical delivery request received",
        completed: true
      },
      {
        status: "Driver Assigned",
        time: "1:48 PM",
        description: "Michael Chen assigned automatically",
        completed: true
      },
      {
        status: "Pickup",
        time: "2:15 PM",
        location: "Piedmont Hospital",
        description: "Package picked up",
        completed: true
      },
      {
        status: "In Transit",
        time: "2:17 PM",
        description: "En route to destination",
        completed: true
      },
      {
        status: "Delivered",
        time: "2:45 PM",
        location: "1800 Howell Mill Rd NW",
        description: "Package delivered successfully",
        completed: true
      }
    ],
    items: ["Prescription medications", "Medical supplies"],
    priority: "express"
  },
  {
    id: "DEL-20231214-012D",
    orderNumber: "ORD-78427",
    status: "exception",
    type: "Food",
    origin: {
      lat: 33.7490,
      lng: -84.3880,
      address: "75 5th St NW, Atlanta, GA 30308"
    },
    destination: {
      lat: 33.7806,
      lng: -84.3867,
      address: "1280 Peachtree St NE, Atlanta, GA 30309"
    },
    progress: 60,
    eta: "Canceled",
    pickupTime: "11:10 AM",
    deadline: "11:45 AM",
    customer: {
      name: "David Park",
      phone: "404-555-2345"
    },
    driver: {
      id: "DRV-2536",
      name: "Sarah Johnson",
      avatar: "",
      phone: "404-555-7890",
      vehicle: "Toyota Corolla (Silver) • QWE-4328",
      rating: 4.7
    },
    steps: [
      {
        status: "Order Received",
        time: "10:45 AM",
        description: "Food delivery request received",
        completed: true
      },
      {
        status: "Driver Assigned",
        time: "10:47 AM",
        description: "Sarah Johnson assigned automatically",
        completed: true
      },
      {
        status: "Pickup",
        time: "11:10 AM",
        location: "75 5th St NW",
        description: "Food picked up",
        completed: true
      },
      {
        status: "In Transit",
        time: "11:12 AM",
        description: "En route to destination",
        completed: true
      },
      {
        status: "Exception",
        time: "11:27 AM",
        description: "Customer canceled order while in transit",
        completed: true
      }
    ],
    items: ["Restaurant food order", "Beverages"],
    priority: "express"
  }
];

// Map component mock
const DeliveryMap = ({ delivery }: { delivery: Delivery }) => {
  return (
    <div className="relative w-full h-[300px] bg-gray-100 rounded-lg overflow-hidden border">
      {/* Mock map display with delivery locations */}
      <div className="absolute inset-0 bg-blue-50 flex items-center justify-center">
        <div className="text-center text-blue-500">
          <MapPin className="h-10 w-10 mx-auto mb-2 opacity-50" />
          <p className="text-sm text-blue-700">Map View</p>
          <p className="text-xs text-blue-600 mt-1">Real-time tracking - {delivery.progress}% complete</p>
          <div className="flex justify-center items-center space-x-8 mt-4">
            <div className="flex flex-col items-center">
              <div className="w-4 h-4 rounded-full bg-blue-500"></div>
              <div className="text-xs mt-1">Origin</div>
            </div>
            {delivery.status === 'in-transit' && (
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 rounded-full bg-amber-500 animate-pulse"></div>
                <div className="text-xs mt-1">Current</div>
              </div>
            )}
            <div className="flex flex-col items-center">
              <div className="w-4 h-4 rounded-full bg-green-500"></div>
              <div className="text-xs mt-1">Destination</div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-white/80 to-transparent">
        <div className="flex justify-between text-sm">
          <div className="flex items-center">
            <MapPin className="h-4 w-4 text-blue-500 mr-1" />
            <span className="text-xs truncate max-w-[120px]">{delivery.origin.address.split(',')[0]}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-xs truncate max-w-[120px]">{delivery.destination.address.split(',')[0]}</span>
          </div>
        </div>
      </div>
      <div className="absolute top-3 right-3">
        <Badge className="bg-blue-100 text-blue-800 border-blue-200">
          Live Tracking
        </Badge>
      </div>
    </div>
  );
};

export default function ClientPortalTracker() {
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery>(activeDeliveries[0]);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [view, setView] = useState<'active' | 'history'>('active');
  const [filteredDeliveries, setFilteredDeliveries] = useState<Delivery[]>([]);

  // Filter deliveries based on search query and active/history view
  useEffect(() => {
    const deliveries = view === 'active' ? activeDeliveries : historyDeliveries;
    if (!searchQuery) {
      setFilteredDeliveries(deliveries);
      return;
    }

    const lowercaseQuery = searchQuery.toLowerCase();
    const filtered = deliveries.filter(delivery => 
      delivery.id.toLowerCase().includes(lowercaseQuery) ||
      delivery.orderNumber.toLowerCase().includes(lowercaseQuery) ||
      delivery.type.toLowerCase().includes(lowercaseQuery) ||
      delivery.origin.address.toLowerCase().includes(lowercaseQuery) ||
      delivery.destination.address.toLowerCase().includes(lowercaseQuery) ||
      (delivery.customer?.name.toLowerCase().includes(lowercaseQuery))
    );
    setFilteredDeliveries(filtered);
  }, [searchQuery, view]);

  // Set initial filtered deliveries
  useEffect(() => {
    setFilteredDeliveries(view === 'active' ? activeDeliveries : historyDeliveries);
  }, [view]);

  // Status badge renderer
  const renderStatusBadge = (status: Delivery['status']) => {
    switch (status) {
      case 'in-transit':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">In Transit</Badge>;
      case 'delivered':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Delivered</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 border-amber-200">Pending</Badge>;
      case 'exception':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Exception</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  // Priority badge renderer
  const renderPriorityBadge = (priority: Delivery['priority']) => {
    switch (priority) {
      case 'urgent':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Urgent</Badge>;
      case 'express':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Express</Badge>;
      case 'standard':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Standard</Badge>;
      default:
        return null;
    }
  };

  // ETA component
  const renderETA = (delivery: Delivery) => {
    if (delivery.status === 'delivered') {
      return (
        <div className="flex items-center">
          <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
          <span className="text-green-700">Delivered at {delivery.deliveryTime}</span>
        </div>
      );
    } else if (delivery.status === 'exception') {
      return (
        <div className="flex items-center">
          <AlertCircle className="h-4 w-4 text-red-500 mr-1" />
          <span className="text-red-700">Delivery Exception</span>
        </div>
      );
    } else if (delivery.status === 'pending') {
      return (
        <div className="flex items-center">
          <Clock className="h-4 w-4 text-amber-500 mr-1" />
          <span className="text-amber-700">Estimated pickup at {delivery.pickupTime}</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center">
          <Clock className="h-4 w-4 text-blue-500 mr-1" />
          <span className="text-blue-700">ETA: {delivery.eta}</span>
        </div>
      );
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-semibold">Delivery Tracker</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Track your automated deliveries in real-time
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="rounded-full w-2 h-2 bg-green-500 animate-pulse"></div>
            <span className="text-sm text-green-700">Live Updates</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {/* Search Bar and View Selector */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by ID, destination, or customer name..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select
              value={view}
              onValueChange={(value: 'active' | 'history') => setView(value)}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="View" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active Orders</SelectItem>
                <SelectItem value="history">Order History</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Delivery List */}
            <div className="lg:col-span-1 space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">
                {view === 'active' ? 'Active Deliveries' : 'Delivery History'}
              </h3>
              
              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                {filteredDeliveries.length > 0 ? (
                  filteredDeliveries.map(delivery => (
                    <div
                      key={delivery.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        selectedDelivery.id === delivery.id 
                          ? 'bg-blue-50 border-blue-200' 
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedDelivery(delivery)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-medium">{delivery.orderNumber}</div>
                          <div className="text-xs text-muted-foreground">{delivery.id}</div>
                        </div>
                        {renderStatusBadge(delivery.status)}
                      </div>
                      
                      <div className="mt-2 flex items-center text-xs text-muted-foreground">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span className="truncate">{delivery.destination.address.split(',')[0]}</span>
                      </div>
                      
                      <div className="mt-2 flex justify-between items-center">
                        <div className="text-xs flex items-center">
                          <Calendar className="h-3 w-3 mr-1 text-muted-foreground" />
                          <span>
                            {delivery.status === 'delivered' ? delivery.deliveryTime : delivery.pickupTime}
                          </span>
                        </div>
                        <div className="text-xs">
                          <Badge variant="outline" className="text-xs">
                            {delivery.type}
                          </Badge>
                        </div>
                      </div>
                      
                      {delivery.status === 'in-transit' && (
                        <div className="mt-2 w-full bg-gray-100 rounded-full h-1">
                          <div 
                            className="bg-blue-500 h-1 rounded-full transition-all" 
                            style={{ width: `${delivery.progress}%` }}
                          ></div>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center bg-gray-50 rounded-lg border">
                    <CircleAlert className="h-5 w-5 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">No deliveries found matching your search</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Delivery Details */}
            <div className="lg:col-span-2 space-y-4">
              {selectedDelivery && (
                <>
                  {/* Header */}
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-lg font-semibold flex items-center">
                        Order {selectedDelivery.orderNumber}
                        {renderPriorityBadge(selectedDelivery.priority)}
                      </h2>
                      <div className="text-sm text-muted-foreground">{selectedDelivery.id}</div>
                    </div>
                    {renderStatusBadge(selectedDelivery.status)}
                  </div>
                  
                  {/* Map */}
                  <DeliveryMap delivery={selectedDelivery} />
                  
                  {/* Delivery Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-medium mb-2">Delivery Details</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Type:</span>
                            <span>{selectedDelivery.type}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Pickup time:</span>
                            <span>{selectedDelivery.pickupTime}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Deadline:</span>
                            <span>{selectedDelivery.deadline}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Status:</span>
                            <span>{renderETA(selectedDelivery)}</span>
                          </div>
                          
                          <Separator className="my-2" />
                          
                          <div className="text-sm">
                            <div className="text-muted-foreground mb-1">Package contents:</div>
                            <ul className="list-disc list-inside pl-1">
                              {selectedDelivery.items.map((item, idx) => (
                                <li key={idx}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-medium mb-2">Contact Information</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Customer:</span>
                            <div className="flex items-center">
                              <User className="h-3 w-3 mr-1" />
                              <span>{selectedDelivery.customer.name}</span>
                            </div>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Phone:</span>
                            <div className="flex items-center">
                              <Phone className="h-3 w-3 mr-1" />
                              <span>{selectedDelivery.customer.phone}</span>
                            </div>
                          </div>
                          
                          {selectedDelivery.driver && (
                            <>
                              <Separator className="my-2" />
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Driver:</span>
                                <span>{selectedDelivery.driver.name}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Driver phone:</span>
                                <span>{selectedDelivery.driver.phone}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Vehicle:</span>
                                <div className="flex items-center">
                                  <Truck className="h-3 w-3 mr-1" />
                                  <span>{selectedDelivery.driver.vehicle}</span>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Delivery Timeline */}
                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-medium mb-4">Delivery Timeline</h3>
                      <div className="relative">
                        {/* Vertical line */}
                        <div className="absolute left-1.5 top-1 h-full w-px bg-gray-200"></div>
                        
                        <div className="space-y-4">
                          {selectedDelivery.steps.map((step, idx) => (
                            <div key={idx} className="flex items-start">
                              <div className={`relative z-10 rounded-full w-3 h-3 mt-1 ${
                                step.completed ? 'bg-green-500' : 'bg-gray-300'
                              }`}></div>
                              <div className="ml-4">
                                <div className="flex items-center">
                                  <h4 className="text-sm font-medium">{step.status}</h4>
                                  <span className="text-xs text-muted-foreground ml-2">{step.time}</span>
                                </div>
                                {step.location && (
                                  <div className="text-xs text-muted-foreground flex items-center mt-0.5">
                                    <MapPin className="h-3 w-3 mr-1" />
                                    <span>{step.location}</span>
                                  </div>
                                )}
                                <p className="text-xs mt-0.5">{step.description}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}