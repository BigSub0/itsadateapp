import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GamepadIcon, Brain } from 'lucide-react';
import { Link } from 'react-router-dom';

interface GameLinkProps {
  className?: string;
  showDescription?: boolean;
}

const GameLink: React.FC<GameLinkProps> = ({ 
  className = '',
  showDescription = true
}) => {
  return (
    <Card className={`overflow-hidden ${className}`}>
      <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 text-white flex justify-between items-center">
        <div className="flex items-center gap-2">
          <GamepadIcon className="h-5 w-5" />
          <h3 className="font-semibold">Games & Activities</h3>
        </div>
        <Brain className="h-5 w-5" />
      </div>
      
      <CardContent className="p-4">
        {showDescription && (
          <p className="text-sm text-muted-foreground mb-4">
            Waiting for matches? Challenge yourself with some fun games while you wait.
          </p>
        )}
        
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-pink-100 p-2 rounded-md">
                <Brain className="h-4 w-4 text-pink-500" />
              </div>
              <div>
                <h4 className="font-medium">Memory Match</h4>
                {showDescription && (
                  <p className="text-xs text-muted-foreground">Test your memory skills</p>
                )}
              </div>
            </div>
            
            <Link to="/games/memory">
              <Button size="sm" variant="outline" className="h-8">
                Play
              </Button>
            </Link>
          </div>
          
          {showDescription && (
            <p className="text-xs text-muted-foreground mt-2 border-t border-border pt-2">
              Playing games can earn you badges and profile boosts!
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default GameLink;