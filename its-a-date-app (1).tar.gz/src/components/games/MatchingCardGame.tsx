import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Heart, Trophy, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';

// Define the card interface
interface MemoryCard {
  id: number;
  imageUrl: string;
  isFlipped: boolean;
  isMatched: boolean;
  theme: string;
}

// Define props interface
interface MatchingCardGameProps {
  difficulty?: 'easy' | 'medium' | 'hard';
  theme?: 'love' | 'dating' | 'couples';
  onGameComplete?: (score: number, time: number) => void;
}

const MatchingCardGame: React.FC<MatchingCardGameProps> = ({ 
  difficulty = 'easy',
  theme = 'love',
  onGameComplete
}) => {
  // Define card counts based on difficulty
  const getCardCount = () => {
    switch (difficulty) {
      case 'easy': return 12; // 6 pairs
      case 'medium': return 16; // 8 pairs
      case 'hard': return 24; // 12 pairs
      default: return 12;
    }
  };

  const [cards, setCards] = useState<MemoryCard[]>([]);
  const [flippedIds, setFlippedIds] = useState<number[]>([]);
  const [matches, setMatches] = useState<number>(0);
  const [moves, setMoves] = useState<number>(0);
  const [gameStarted, setGameStarted] = useState<boolean>(false);
  const [gameCompleted, setGameCompleted] = useState<boolean>(false);
  const [timer, setTimer] = useState<number>(0);
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);

  // Images for card pairs based on theme
  const getThemeImages = () => {
    const images = [];
    const baseTheme = theme === 'love' ? 'hearts' : theme === 'dating' ? 'dating' : 'couples';
    
    // Add theme-specific images
    switch (baseTheme) {
      case 'hearts':
        images.push(
          '/assets/games/heart-red.png',
          '/assets/games/heart-pink.png',
          '/assets/games/heart-gold.png',
          '/assets/games/heart-purple.png',
          '/assets/games/heart-blue.png',
          '/assets/games/heart-green.png',
          '/assets/games/heart-rainbow.png',
          '/assets/games/heart-silver.png',
          '/assets/games/heart-bronze.png',
          '/assets/games/heart-black.png',
          '/assets/games/heart-white.png',
          '/assets/games/heart-orange.png'
        );
        break;
      case 'dating':
        images.push(
          '/assets/games/date-dinner.png',
          '/assets/games/date-movie.png',
          '/assets/games/date-picnic.png',
          '/assets/games/date-coffee.png',
          '/assets/games/date-beach.png',
          '/assets/games/date-hiking.png',
          '/assets/games/date-concert.png',
          '/assets/games/date-museum.png',
          '/assets/games/date-cooking.png',
          '/assets/games/date-dancing.png',
          '/assets/games/date-arcade.png',
          '/assets/games/date-stargazing.png'
        );
        break;
      case 'couples':
        images.push(
          '/assets/games/couple-holding-hands.png',
          '/assets/games/couple-kissing.png',
          '/assets/games/couple-hugging.png',
          '/assets/games/couple-laughing.png',
          '/assets/games/couple-dancing.png',
          '/assets/games/couple-movie.png',
          '/assets/games/couple-dining.png',
          '/assets/games/couple-selfie.png',
          '/assets/games/couple-walking.png',
          '/assets/games/couple-travel.png',
          '/assets/games/couple-proposal.png',
          '/assets/games/couple-wedding.png'
        );
        break;
    }

    return images;
  };

  // Initialize the game
  const initializeGame = () => {
    const cardCount = getCardCount();
    const pairCount = cardCount / 2;
    const themeImages = getThemeImages();
    
    // Create pairs of cards
    const cardPairs: MemoryCard[] = [];
    for (let i = 0; i < pairCount; i++) {
      const imageUrl = themeImages[i % themeImages.length];
      // Create two cards with the same image (a pair)
      const card1 = {
        id: i * 2,
        imageUrl,
        isFlipped: false,
        isMatched: false,
        theme
      };
      
      const card2 = {
        id: i * 2 + 1,
        imageUrl,
        isFlipped: false,
        isMatched: false,
        theme
      };
      
      cardPairs.push(card1, card2);
    }
    
    // Shuffle the cards
    const shuffledCards = cardPairs.sort(() => Math.random() - 0.5);
    setCards(shuffledCards);
    
    // Reset game state
    setFlippedIds([]);
    setMatches(0);
    setMoves(0);
    setTimer(0);
    setGameStarted(true);
    setGameCompleted(false);
    
    // Start the timer
    if (intervalId) clearInterval(intervalId);
    const newIntervalId = setInterval(() => {
      setTimer(prevTime => prevTime + 1);
    }, 1000);
    
    setIntervalId(newIntervalId);
  };

  // Handle card click
  const handleCardClick = (id: number) => {
    // Ignore clicks if already matched or already flipped
    const clickedCard = cards.find(card => card.id === id);
    if (
      !gameStarted || 
      gameCompleted || 
      clickedCard?.isMatched || 
      clickedCard?.isFlipped ||
      flippedIds.length >= 2
    ) {
      return;
    }

    // Flip the card
    const newCards = cards.map(card => 
      card.id === id ? { ...card, isFlipped: true } : card
    );
    setCards(newCards);
    
    // Add to flipped cards
    const newFlippedIds = [...flippedIds, id];
    setFlippedIds(newFlippedIds);
    
    // Check if we have a pair
    if (newFlippedIds.length === 2) {
      // Increment moves counter
      setMoves(prev => prev + 1);
      
      // Get the two flipped cards
      const firstCard = newCards.find(card => card.id === newFlippedIds[0]);
      const secondCard = newCards.find(card => card.id === newFlippedIds[1]);
      
      // Check if they match
      if (firstCard && secondCard && firstCard.imageUrl === secondCard.imageUrl) {
        // Mark as matched
        const matchedCards = newCards.map(card => 
          card.id === firstCard.id || card.id === secondCard.id 
            ? { ...card, isMatched: true } 
            : card
        );
        setCards(matchedCards);
        setMatches(prev => prev + 1);
        setFlippedIds([]);
        
        // Check if game is complete
        const totalPairs = getCardCount() / 2;
        if (matches + 1 === totalPairs) {
          endGame();
        }
      } else {
        // If no match, flip them back after a delay
        setTimeout(() => {
          const resetFlippedCards = newCards.map(card => 
            card.id === newFlippedIds[0] || card.id === newFlippedIds[1] 
              ? { ...card, isFlipped: false } 
              : card
          );
          setCards(resetFlippedCards);
          setFlippedIds([]);
        }, 1000);
      }
    }
  };

  // End the game
  const endGame = () => {
    if (intervalId) clearInterval(intervalId);
    setGameCompleted(true);
    setGameStarted(false);
    
    // Calculate score based on moves and time
    const totalPairs = getCardCount() / 2;
    const score = Math.floor((totalPairs * 100) - (moves * 5) - (timer * 0.5));
    
    // Call the callback if provided
    if (onGameComplete) {
      onGameComplete(score > 0 ? score : 10, timer);
    }
  };

  // Format time display
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [intervalId]);

  // Create placeholder images for the cards (these would be replaced in a real implementation)
  useEffect(() => {
    // Create public/assets/games directory if it doesn't exist
    const createPlaceholderImages = async () => {
      // This is just a placeholder - in a real implementation we would use real images
      console.log("Card game initialized");
    };
    
    createPlaceholderImages();
  }, []);

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Game header */}
      <div className="w-full flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="px-3 py-1">
            <Heart className="h-4 w-4 mr-1 text-pink-500" />
            <span>Matches: {matches} / {getCardCount() / 2}</span>
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            <Trophy className="h-4 w-4 mr-1 text-yellow-500" />
            <span>Moves: {moves}</span>
          </Badge>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          <Timer className="h-4 w-4 mr-1 text-blue-500" />
          <span>{formatTime(timer)}</span>
        </Badge>
      </div>
      
      <Separator />

      {/* Game board */}
      <div className={cn(
        "grid gap-2 w-full max-w-3xl mx-auto",
        difficulty === 'easy' ? 'grid-cols-3 md:grid-cols-4' : 
        difficulty === 'medium' ? 'grid-cols-4' : 
        'grid-cols-4 md:grid-cols-6'
      )}>
        {cards.map(card => (
          <Card 
            key={card.id}
            className={cn(
              "aspect-square cursor-pointer transition-all duration-300 transform hover:scale-105",
              card.isFlipped && !card.isMatched && "border-primary",
              card.isMatched && "border-green-500 opacity-70"
            )}
            onClick={() => handleCardClick(card.id)}
          >
            <CardContent className="p-2 h-full flex items-center justify-center">
              {card.isFlipped || card.isMatched ? (
                <div className="w-full h-full flex items-center justify-center">
                  <img 
                    src={card.imageUrl} 
                    alt="Card" 
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-full h-full rounded-md bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">?</span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Game controls */}
      <div className="mt-4 flex gap-2">
        {!gameStarted && !gameCompleted && (
          <Button onClick={initializeGame}>Start Game</Button>
        )}
        {gameStarted && (
          <Button variant="outline" onClick={endGame}>End Game</Button>
        )}
        {gameCompleted && (
          <Button onClick={initializeGame}>Play Again</Button>
        )}
      </div>
      
      {/* Game completion message */}
      {gameCompleted && (
        <div className="mt-4 p-4 border rounded-md bg-gradient-to-r from-pink-50 to-purple-50">
          <h3 className="text-xl font-bold text-center">Game Complete!</h3>
          <p className="text-center">
            You completed the game in {formatTime(timer)} with {moves} moves.
          </p>
          <p className="text-center mt-2">
            Score: <span className="font-bold text-pink-600">
              {Math.floor((getCardCount() / 2 * 100) - (moves * 5) - (timer * 0.5)) > 0 
                ? Math.floor((getCardCount() / 2 * 100) - (moves * 5) - (timer * 0.5)) 
                : 10}
            </span>
          </p>
        </div>
      )}
    </div>
  );
};

export default MatchingCardGame;