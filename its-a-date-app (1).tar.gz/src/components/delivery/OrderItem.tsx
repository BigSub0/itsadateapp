import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Clock, MapPin, CheckCircle, Package } from 'lucide-react';
import { Order } from '@/lib/delivery/localStorage';

interface OrderItemProps {
  order: Order;
  onClick?: () => void;
}

export default function OrderItem({ order, onClick }: OrderItemProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
    }).format(date);
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'preparing':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'out-for-delivery':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'canceled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'confirmed':
        return 'Order Confirmed';
      case 'preparing':
        return 'Preparing';
      case 'out-for-delivery':
        return 'Out for Delivery';
      case 'delivered':
        return 'Delivered';
      case 'canceled':
        return 'Canceled';
      default:
        return status;
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle className="h-4 w-4 mr-1" />;
      case 'out-for-delivery':
        return <MapPin className="h-4 w-4 mr-1" />;
      case 'preparing':
        return <Package className="h-4 w-4 mr-1" />;
      default:
        return <Clock className="h-4 w-4 mr-1" />;
    }
  };

  return (
    <Card 
      className={`overflow-hidden hover:shadow-md transition-all ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h4 className="font-medium">{order.restaurantName}</h4>
            <p className="text-sm text-gray-500">{formatDate(order.placedAt)}</p>
          </div>
          <Badge 
            variant="outline" 
            className={`${getStatusColor(order.status)} flex items-center`}
          >
            {getStatusIcon(order.status)}
            {getStatusText(order.status)}
          </Badge>
        </div>
        
        <Separator className="my-3" />
        
        <div className="text-sm">
          <div className="flex justify-between mb-2">
            <span className="font-medium">Order #{order.id}</span>
            <span className="font-medium">${order.total.toFixed(2)}</span>
          </div>
          
          <div className="text-gray-500 mb-2">
            {order.items.length} {order.items.length === 1 ? 'item' : 'items'}:
            {' '}
            {order.items.slice(0, 2).map((item, i) => (
              <span key={i}>
                {i > 0 && ', '}
                {item.quantity} × {item.menuItem.name}
              </span>
            ))}
            {order.items.length > 2 && `, +${order.items.length - 2} more`}
          </div>
          
          {order.status !== 'delivered' && order.status !== 'canceled' && (
            <div className="flex items-center text-gray-500">
              <Clock className="h-4 w-4 mr-1" />
              <span>
                Estimated delivery by {formatDate(order.estimatedDelivery)}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}