import React, { useState } from 'react';
import { useDeliveryContext } from '@/contexts/DeliveryContext';
import { CartItem } from '@/lib/delivery/localStorage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { MinusIcon, PlusIcon, Trash2Icon, XIcon } from 'lucide-react';
import { DialogTrigger, DialogContent, DialogFooter, DialogClose, Dialog } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

interface CartPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartPanel({ isOpen, onClose }: CartPanelProps) {
  const { cart, cartSubtotal, cartTax, cartDeliveryFee, cartTotal, updateCartItem, removeFromCart, clearCart, addOrder } = useDeliveryContext();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [tip, setTip] = useState(0);
  const [tipPercentage, setTipPercentage] = useState(15);
  const [address, setAddress] = useState({
    street: '',
    city: '',
    state: '',
    zipCode: '',
  });
  const [paymentMethod, setPaymentMethod] = useState<'credit' | 'debit' | 'paypal' | 'cash'>('credit');

  if (!isOpen) return null;

  const handleQuantityChange = (index: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    const updatedItem = { ...cart[index], quantity: newQuantity };
    updateCartItem(index, updatedItem);
  };

  const tipOptions = [10, 15, 20, 25];

  const calculateTip = (percentage: number) => {
    setTipPercentage(percentage);
    setTip(cartSubtotal * (percentage / 100));
  };
  
  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Add items to your cart before checking out",
        variant: "destructive",
      });
      return;
    }
    
    setIsCheckingOut(true);
  };
  
  const handlePlaceOrder = () => {
    // Validate address fields
    if (!address.street || !address.city || !address.state || !address.zipCode) {
      toast({
        title: "Incomplete address",
        description: "Please fill in all address fields",
        variant: "destructive",
      });
      return;
    }
    
    // Create a new order
    const restaurantId = cart[0]?.menuItem.restaurantId || '';
    const restaurantName = "Restaurant Name"; // In a real app, we would get this from the restaurant data
    
    const newOrder = {
      id: `ORD-${Math.floor(Math.random() * 10000)}`,
      restaurantId,
      restaurantName,
      items: [...cart],
      subtotal: cartSubtotal,
      tax: cartTax,
      deliveryFee: cartDeliveryFee,
      tip,
      total: cartTotal + tip,
      status: 'confirmed' as const,
      placedAt: new Date().toISOString(),
      estimatedDelivery: new Date(Date.now() + 45 * 60000).toISOString(), // 45 minutes from now
      address,
      paymentMethod: {
        type: paymentMethod,
        last4: paymentMethod === 'cash' ? undefined : '4242',
      }
    };
    
    addOrder(newOrder);
    setIsCheckingOut(false);
    onClose();
    navigate(`/delivery/orders/${newOrder.id}`);
  };
  
  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex justify-end">
      <div className="bg-white w-full max-w-md flex flex-col h-full shadow-xl animate-in slide-in-from-right">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-semibold text-lg">Your Cart</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <XIcon className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="text-gray-400 mb-4 text-5xl">🛒</div>
              <h3 className="text-xl font-medium mb-2">Your cart is empty</h3>
              <p className="text-gray-500 mb-6">Add items from a restaurant to get started</p>
              <Button onClick={onClose}>Browse Restaurants</Button>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="flex p-4">
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h4 className="font-medium">{item.menuItem.name}</h4>
                        <p className="font-medium">${((item.menuItem.price * item.quantity) + 
                          ((item.options?.reduce((sum, opt) => sum + opt.choice.price, 0) || 0) * item.quantity)).toFixed(2)}</p>
                      </div>
                      
                      {/* Selected options */}
                      {item.options && item.options.length > 0 && (
                        <div className="mt-1 text-sm text-gray-500">
                          {item.options.map((option, i) => (
                            <div key={i}>
                              {option.name}: {option.choice.name}
                              {option.choice.price > 0 && ` (+$${option.choice.price.toFixed(2)})`}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Special instructions */}
                      {item.specialInstructions && (
                        <div className="mt-1 text-sm italic text-gray-500">
                          "{item.specialInstructions}"
                        </div>
                      )}
                      
                      <div className="mt-3 flex items-center">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => handleQuantityChange(index, item.quantity - 1)}
                        >
                          <MinusIcon className="h-3 w-3" />
                        </Button>
                        <span className="mx-2 w-6 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => handleQuantityChange(index, item.quantity + 1)}
                        >
                          <PlusIcon className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 ml-auto text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => removeFromCart(index)}
                        >
                          <Trash2Icon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
              
              <div className="flex justify-center">
                <Button variant="ghost" className="text-red-500" onClick={clearCart}>
                  Clear cart
                </Button>
              </div>
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t p-4 bg-gray-50">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${cartSubtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax</span>
                <span>${cartTax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>${cartDeliveryFee.toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-medium text-base pt-1">
                <span>Total</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
            </div>

            <Button 
              className="w-full mt-4" 
              size="lg"
              onClick={handleCheckout}
            >
              Checkout
            </Button>
          </div>
        )}

        {/* Checkout Dialog */}
        <Dialog open={isCheckingOut} onOpenChange={(open) => !open && setIsCheckingOut(false)}>
          <DialogContent className="max-w-md">
            <CardTitle className="text-xl mb-4">Checkout</CardTitle>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Delivery Address</h3>
                <div className="space-y-2">
                  <Input
                    placeholder="Street Address"
                    value={address.street}
                    onChange={(e) => setAddress({...address, street: e.target.value})}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="City"
                      value={address.city}
                      onChange={(e) => setAddress({...address, city: e.target.value})}
                    />
                    <Input
                      placeholder="State"
                      value={address.state}
                      onChange={(e) => setAddress({...address, state: e.target.value})}
                    />
                  </div>
                  <Input
                    placeholder="Zip Code"
                    value={address.zipCode}
                    onChange={(e) => setAddress({...address, zipCode: e.target.value})}
                  />
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Add a tip</h3>
                <div className="grid grid-cols-4 gap-2">
                  {tipOptions.map((percentage) => (
                    <Button
                      key={percentage}
                      type="button"
                      variant={tipPercentage === percentage ? "default" : "outline"}
                      onClick={() => calculateTip(percentage)}
                      className="w-full"
                    >
                      {percentage}%
                    </Button>
                  ))}
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  Tip amount: ${tip.toFixed(2)}
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Payment Method</h3>
                <RadioGroup
                  value={paymentMethod}
                  onValueChange={(value) => setPaymentMethod(value as 'credit' | 'debit' | 'paypal' | 'cash')}
                  className="space-y-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="credit" id="credit" />
                    <Label htmlFor="credit">Credit Card</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="debit" id="debit" />
                    <Label htmlFor="debit">Debit Card</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="paypal" id="paypal" />
                    <Label htmlFor="paypal">PayPal</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash">Cash on Delivery</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="bg-gray-50 p-3 rounded-md">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${cartSubtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>${cartTax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span>${cartDeliveryFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tip</span>
                    <span>${tip.toFixed(2)}</span>
                  </div>
                  <Separator className="my-1" />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${(cartTotal + tip).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={handlePlaceOrder}>
                Place Order
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}