import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { StarIcon, Clock3Icon, Heart, ArrowRight } from 'lucide-react';

interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: string;
  imageUrl: string;
  tags: string[];
}

interface RestaurantCardProps {
  restaurant: Restaurant;
}

export default function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-48 overflow-hidden relative">
        {restaurant.imageUrl ? (
          <img 
            src={restaurant.imageUrl} 
            alt={restaurant.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = 'https://placehold.co/600x400/orange/white?text=Restaurant+Image';
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500">
            {restaurant.name}
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white/80 hover:bg-white rounded-full shadow-sm"
        >
          <Heart className="h-4 w-4 text-orange-500" />
        </Button>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-bold text-lg">{restaurant.name}</h3>
            <p className="text-muted-foreground text-sm">{restaurant.cuisine}</p>
          </div>
          <div className="flex items-center bg-orange-50 text-orange-600 px-2 py-1 rounded">
            <StarIcon className="h-4 w-4 mr-1" />
            <span>{restaurant.rating}</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pb-3">
        <div className="flex flex-wrap gap-2 mb-3">
          {restaurant.tags.map((tag, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <div className="flex justify-between text-sm">
          <div className="flex items-center text-muted-foreground">
            <Clock3Icon className="h-4 w-4 mr-1" />
            <span>{restaurant.deliveryTime}</span>
          </div>
          <div className="text-muted-foreground">
            Delivery: {restaurant.deliveryFee}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="pt-0">
        <Button className="w-full bg-orange-500 hover:bg-orange-600">
          View Menu
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </CardFooter>
    </Card>
  );
}