import * as React from 'react';
import {
  Bar,
  BarChart as RechartsBarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';

export interface BarChartProps {
  data: Record<string, unknown>[];
  index: string;
  categories: string[];
  colors?: string[];
  valueFormatter?: (value: number) => string;
  yAxisWidth?: number;
  className?: string;
}

export function BarChart({
  data,
  index,
  categories,
  colors = ['blue'],
  valueFormatter = (value: number) => `${value}`,
  yAxisWidth = 50,
  className,
}: BarChartProps) {
  return (
    <ChartContainer
      className={className}
      config={{
        index,
        ...Object.fromEntries(
          categories.map((category, i) => [
            category,
            {
              label: category,
              color: `hsl(var(--${colors[i % colors.length]}-500))`,
            },
          ])
        ),
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <RechartsBarChart
          data={data}
          margin={{
            top: 10,
            right: 10,
            left: 10,
            bottom: 10,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} vertical={false} />
          <XAxis
            dataKey={index}
            tickLine={false}
            axisLine={false}
            tickMargin={10}
            fontSize={12}
          />
          <YAxis
            width={yAxisWidth}
            tickLine={false}
            axisLine={false}
            tickFormatter={valueFormatter}
            fontSize={12}
            tickMargin={10}
          />
          <ChartTooltip
            content={({ active, payload }) => (
              <ChartTooltipContent
                active={active}
                payload={payload}
                formatter={valueFormatter}
              />
            )}
          />
          {categories.map((category, i) => (
            <Bar
              key={category}
              dataKey={category}
              fill={`hsl(var(--${colors[i % colors.length]}-500))`}
              radius={[4, 4, 0, 0]}
              barSize={35}
              className="opacity-80 hover:opacity-100"
            />
          ))}
        </RechartsBarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}
