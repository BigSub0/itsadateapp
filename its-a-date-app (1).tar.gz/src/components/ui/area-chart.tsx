import * as React from 'react';
import {
  Area,
  AreaChart as RechartsAreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';

export interface AreaChartProps {
  data: Record<string, unknown>[];
  index: string;
  categories: string[];
  colors?: string[];
  valueFormatter?: (value: number) => string;
  yAxisWidth?: number;
  className?: string;
}

export function AreaChart({
  data,
  index,
  categories,
  colors = ['blue'],
  valueFormatter = (value: number) => `${value}`,
  yAxisWidth = 50,
  className,
}: AreaChartProps) {
  return (
    <ChartContainer
      className={className}
      config={{
        index,
        ...Object.fromEntries(
          categories.map((category, i) => [
            category,
            {
              label: category,
              color: `hsl(var(--${colors[i % colors.length]}-500))`,
            },
          ])
        ),
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <RechartsAreaChart
          data={data}
          margin={{
            top: 10,
            right: 10,
            left: 10,
            bottom: 10,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
          <XAxis
            dataKey={index}
            tickLine={false}
            axisLine={false}
            tickMargin={10}
            fontSize={12}
          />
          <YAxis
            width={yAxisWidth}
            tickLine={false}
            axisLine={false}
            tickFormatter={valueFormatter}
            fontSize={12}
            tickMargin={10}
          />
          <ChartTooltip
            content={({ active, payload }) => (
              <ChartTooltipContent
                active={active}
                payload={payload}
                formatter={valueFormatter}
              />
            )}
          />
          {categories.map((category, i) => (
            <Area
              key={category}
              type="monotone"
              dataKey={category}
              stackId="1"
              stroke={`hsl(var(--${colors[i % colors.length]}-500))`}
              fill={`hsl(var(--${colors[i % colors.length]}-500) / 0.2)`}
              activeDot={{
                r: 5,
                strokeWidth: 0,
                fill: `hsl(var(--${colors[i % colors.length]}-500))`,
              }}
            />
          ))}
        </RechartsAreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}
