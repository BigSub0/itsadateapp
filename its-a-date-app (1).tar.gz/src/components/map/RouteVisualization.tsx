import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet-routing-machine';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, Map, Route } from 'lucide-react';
import { DeliveryLocation, DriverLocation, optimizeRoute } from '@/lib/route-optimizer';

interface RouteVisualizationProps {
  driverLocation: DriverLocation | null;
  deliveryLocations: DeliveryLocation[];
  onRouteOptimized?: (route: DeliveryLocation[]) => void;
  className?: string;
}

const RouteVisualization: React.FC<RouteVisualizationProps> = ({
  driverLocation,
  deliveryLocations,
  onRouteOptimized,
  className
}) => {
  // Create refs for the map and map container elements
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const routingControlRef = useRef<L.Routing.Control | null>(null);
  
  // State for optimized route
  const [optimizedRoute, setOptimizedRoute] = useState<DeliveryLocation[]>([]);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);

  // Initialize map
  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      // Default to a central US location if no driver location is available yet
      const initialLocation = driverLocation 
        ? [driverLocation.lat, driverLocation.lng] 
        : [37.7749, -122.4194];
      
      // Create the map
      mapRef.current = L.map(mapContainerRef.current).setView(
        initialLocation as [number, number], 
        13
      );

      // Add the tile layer (map background)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(mapRef.current);
    }

    // Clean up function
    return () => {
      if (routingControlRef.current && mapRef.current) {
        mapRef.current.removeControl(routingControlRef.current);
        routingControlRef.current = null;
      }
      
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Function to optimize and visualize the route
  const handleOptimizeRoute = () => {
    if (!mapRef.current || !driverLocation) return;
    
    setIsOptimizing(true);
    
    // Optimize route
    const startLocation = {
      lat: driverLocation.lat,
      lng: driverLocation.lng
    };
    
    // Filter out completed deliveries
    const activeDeliveries = deliveryLocations.filter(
      delivery => delivery.status !== 'completed'
    );
    
    const route = optimizeRoute(startLocation, activeDeliveries);
    setOptimizedRoute(route);
    
    // Call the callback if provided
    if (onRouteOptimized) {
      onRouteOptimized(route);
    }
    
    // Remove existing routing control if it exists
    if (routingControlRef.current && mapRef.current) {
      mapRef.current.removeControl(routingControlRef.current);
      routingControlRef.current = null;
    }
    
    // Create waypoints for the route
    const waypoints = [
      L.latLng(driverLocation.lat, driverLocation.lng), // Start with driver's location
      ...route.map(location => L.latLng(location.lat, location.lng))
    ];
    
    // Create new routing control
    if (waypoints.length > 1) {
      routingControlRef.current = L.Routing.control({
        waypoints,
        routeWhileDragging: false,
        addWaypoints: false,
        fitSelectedRoutes: true,
        showAlternatives: false,
        lineOptions: {
          styles: [{ color: '#6366F1', opacity: 0.8, weight: 6 }]
        },
        createMarker: function(i, waypoint, n) {
          // Don't create markers for waypoints as we already have custom markers
          return null;
        }
      }).addTo(mapRef.current);
      
      // Hide the routing control container but keep the route visible
      const routingContainer = document.querySelector('.leaflet-routing-container');
      if (routingContainer) {
        routingContainer.classList.add('hidden');
      }
    }
    
    setIsOptimizing(false);
  };
  
  // Calculate total distance and estimated time for the route
  const routeSummary = React.useMemo(() => {
    if (optimizedRoute.length === 0 || !driverLocation) return null;
    
    // Calculate rough distance and time (more accurate calculation would be done by the routing machine)
    let totalDistance = 0;
    let totalTimeMinutes = 0;
    
    const waypoints = [
      { lat: driverLocation.lat, lng: driverLocation.lng },
      ...optimizedRoute.map(loc => ({ lat: loc.lat, lng: loc.lng }))
    ];
    
    // Simple distance calculation (in a real app, you'd use the actual route distance)
    for (let i = 0; i < waypoints.length - 1; i++) {
      const p1 = waypoints[i];
      const p2 = waypoints[i + 1];
      
      // Calculate distance in km using Haversine formula
      const R = 6371; // Earth radius in km
      const dLat = (p2.lat - p1.lat) * Math.PI / 180;
      const dLon = (p2.lng - p1.lng) * Math.PI / 180;
      const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distance = R * c;
      
      totalDistance += distance;
      
      // Rough time estimation (assuming 30 km/h average speed)
      totalTimeMinutes += (distance / 30) * 60;
      
      // Add 5 minutes for each stop for delivery time
      if (i > 0) {
        totalTimeMinutes += 5;
      }
    }
    
    return {
      distance: totalDistance.toFixed(1),
      time: Math.round(totalTimeMinutes)
    };
  }, [optimizedRoute, driverLocation]);

  return (
    <Card className={`w-full ${className}`}>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg flex justify-between items-center">
          <div className="flex items-center">
            <Route size={18} className="mr-2" /> 
            Optimized Route
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleOptimizeRoute} 
            disabled={isOptimizing || !driverLocation}
            className="h-8 gap-1"
          >
            <RefreshCw size={14} className={isOptimizing ? "animate-spin" : ""} />
            Optimize
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="w-full h-[300px]" ref={mapContainerRef}></div>
        
        {routeSummary && (
          <div className="p-3 border-t">
            <div className="flex justify-between text-sm">
              <span>Total stops: {optimizedRoute.length}</span>
              <span>Distance: ~{routeSummary.distance} km</span>
              <span>Est. time: ~{routeSummary.time} min</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RouteVisualization;