import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, CheckCircle, AlertCircle } from 'lucide-react';

// Define interfaces for our data types
interface DeliveryLocation {
  id: string;
  address: string;
  lat: number;
  lng: number;
  priority?: number;
  status?: 'pending' | 'in-progress' | 'completed';
}

interface DriverLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  lastUpdated: number;
}

interface SimpleTrackingMapProps {
  driverLocation?: { lat: number; lng: number } | null;
  deliveryLocations?: DeliveryLocation[];
  isOnline?: boolean;
  className?: string;
}

const SimpleTrackingMap: React.FC<SimpleTrackingMapProps> = ({
  driverLocation = null,
  deliveryLocations = [],
  isOnline = true,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Update canvas dimensions when component mounts or window resizes
  useEffect(() => {
    const updateDimensions = () => {
      if (canvasRef.current) {
        const { offsetWidth, offsetHeight } = canvasRef.current.parentElement as HTMLElement;
        setDimensions({
          width: offsetWidth || 300,
          height: offsetHeight || 200
        });
      }
    };

    window.addEventListener('resize', updateDimensions);
    // Initial dimension set
    setTimeout(updateDimensions, 100);

    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Draw map when dimensions change or locations update
  useEffect(() => {
    if (!canvasRef.current || !dimensions.width || !dimensions.height) return;

    const canvas = canvasRef.current;
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw simple map background
    ctx.fillStyle = '#f0f4f8';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid lines
    ctx.strokeStyle = '#d1dce8';
    ctx.lineWidth = 1;
    
    // Draw vertical lines
    for (let x = 0; x < canvas.width; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    
    // Draw horizontal lines
    for (let y = 0; y < canvas.height; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // If we don't have a driver location, just show the empty map
    if (!driverLocation) {
      // Draw a message indicating no driver data
      ctx.fillStyle = '#64748b';
      ctx.font = '14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('Waiting for driver location...', canvas.width / 2, canvas.height / 2);
      return;
    }

    // Get min/max coordinates to establish a bounding box
    let minLat = driverLocation.lat;
    let maxLat = driverLocation.lat;
    let minLng = driverLocation.lng;
    let maxLng = driverLocation.lng;

    deliveryLocations.forEach(location => {
      minLat = Math.min(minLat, location.lat);
      maxLat = Math.max(maxLat, location.lat);
      minLng = Math.min(minLng, location.lng);
      maxLng = Math.max(maxLng, location.lng);
    });

    // Add some padding
    const padding = 0.002; // ~200m in coordinates
    minLat -= padding;
    maxLat += padding;
    minLng -= padding;
    maxLng += padding;

    // Function to convert geo coordinates to canvas coordinates
    const toCanvasCoords = (lat: number, lng: number) => {
      const latRange = maxLat - minLat || 0.01;
      const lngRange = maxLng - minLng || 0.01;
      
      return {
        x: ((lng - minLng) / lngRange) * canvas.width,
        y: canvas.height - ((lat - minLat) / latRange) * canvas.height // Flip y-axis
      };
    };

    // Draw delivery locations
    deliveryLocations.forEach(delivery => {
      const { x, y } = toCanvasCoords(delivery.lat, delivery.lng);
      
      // Draw different markers based on status
      if (delivery.status === 'completed') {
        // Completed delivery - green checkmark
        ctx.fillStyle = '#10b981'; // Green
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, 2 * Math.PI);
        ctx.fill();
        
        // White checkmark
        ctx.strokeStyle = 'white';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x - 3, y);
        ctx.lineTo(x - 1, y + 2);
        ctx.lineTo(x + 3, y - 2);
        ctx.stroke();
      } else if (delivery.status === 'in-progress') {
        // In progress - blue marker
        ctx.fillStyle = '#3b82f6'; // Blue
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, 2 * Math.PI);
        ctx.fill();
      } else {
        // Pending - gray marker
        ctx.fillStyle = '#64748b'; // Gray
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, 2 * Math.PI);
        ctx.fill();
      }
      
      // Priority indicator
      if (delivery.priority === 1) {
        // High priority - red ring
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, 9, 0, 2 * Math.PI);
        ctx.stroke();
      }
    });

    // Draw driver location
    if (driverLocation) {
      const { x, y } = toCanvasCoords(driverLocation.lat, driverLocation.lng);
      
      // Draw truck icon (simplified as a circle with a triangle)
      ctx.fillStyle = '#1d4ed8'; // Dark blue
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, 2 * Math.PI);
      ctx.fill();
      
      // Truck "cab" in white
      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.moveTo(x, y - 4);
      ctx.lineTo(x + 4, y + 2);
      ctx.lineTo(x - 4, y + 2);
      ctx.closePath();
      ctx.fill();
      
      // Animated pulse effect
      ctx.strokeStyle = '#60a5fa'; // Light blue
      ctx.lineWidth = 2;
      const pulseRadius = 12 + (Date.now() % 2000) / 2000 * 8;
      ctx.globalAlpha = 1 - (pulseRadius - 12) / 8;
      ctx.beginPath();
      ctx.arc(x, y, pulseRadius, 0, 2 * Math.PI);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

  }, [canvasRef, dimensions, driverLocation, deliveryLocations]);

  return (
    <Card className={`overflow-hidden h-full ${className}`}>
      <div className="bg-muted px-4 py-2 flex justify-between items-center">
        <h3 className="font-semibold flex items-center">
          <Truck size={18} className="mr-2" /> Live Map View
        </h3>
        <div className="flex items-center gap-2">
          {isOnline ? (
            <Badge variant="outline" className="bg-green-100 text-green-800 flex items-center gap-1">
              <CheckCircle size={14} /> Online
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-amber-100 text-amber-800 flex items-center gap-1">
              <AlertCircle size={14} /> Offline
            </Badge>
          )}
        </div>
      </div>
      <CardContent className="p-0 h-full relative">
        <div className="w-full h-full min-h-[200px]">
          <canvas 
            ref={canvasRef} 
            className="w-full h-full" 
            style={{ display: 'block' }}
          />
        </div>
        <div className="absolute bottom-2 right-2 bg-white bg-opacity-80 rounded-sm px-2 py-1 text-xs flex items-center">
          <MapPin size={12} className="mr-1 text-primary" /> 
          {driverLocation ? `${driverLocation.lat.toFixed(5)}, ${driverLocation.lng.toFixed(5)}` : 'No location data'}
        </div>
      </CardContent>
    </Card>
  );
};

export default SimpleTrackingMap;