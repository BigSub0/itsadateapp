import React, { useEffect, useRef, useMemo, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, CheckCircle, AlertCircle, AlertTriangle } from 'lucide-react';
import { DriverLocation, DeliveryLocation } from '@/lib/route-optimizer';

// Define props for the LiveTrackingMap component
interface LiveTrackingMapProps {
  driverLocation: DriverLocation | null;
  deliveryLocations: DeliveryLocation[];
  selectedDelivery?: DeliveryLocation | null;
  isOnline?: boolean;
}

const LiveTrackingMap: React.FC<LiveTrackingMapProps> = ({
  driverLocation,
  deliveryLocations,
  selectedDelivery,
  isOnline = true,
}) => {
  // Create refs for the map and map container elements
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  
  // State for markers
  const [markers, setMarkers] = useState<{
    driver: L.Marker | null;
    deliveries: L.Marker[];
  }>({
    driver: null,
    deliveries: [],
  });

  // Custom icons for markers
  const markerIcons = useMemo(() => {
    return {
      driver: L.icon({
        iconUrl: '/assets/icons/driver-marker.png',
        iconSize: [38, 38],
        iconAnchor: [19, 38],
        popupAnchor: [0, -38],
        // Fallback to default marker if the image doesn't load
        className: 'driver-marker-icon',
      }),
      delivery: L.icon({
        iconUrl: '/assets/icons/delivery-marker.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
        // Fallback to default marker if the image doesn't load
        className: 'delivery-marker-icon',
      }),
      completed: L.icon({
        iconUrl: '/assets/icons/completed-marker.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
        // Fallback to default marker if the image doesn't load
        className: 'completed-marker-icon',
      }),
    };
  }, []);

  // Initialize map when component mounts
  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      // Default to a central US location if no driver location is available yet
      const initialLocation = driverLocation 
        ? [driverLocation.lat, driverLocation.lng] 
        : [37.7749, -122.4194];
      
      // Create the map
      mapRef.current = L.map(mapContainerRef.current).setView(
        initialLocation as [number, number], 
        13
      );

      // Add the tile layer (map background)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(mapRef.current);
    }

    // Clean up function to destroy map when component unmounts
    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Update driver marker when driver location changes
  useEffect(() => {
    if (!mapRef.current || !driverLocation) return;
    
    // Remove existing driver marker if it exists
    if (markers.driver) {
      markers.driver.remove();
    }

    // Create new driver marker
    const newDriverMarker = L.marker(
      [driverLocation.lat, driverLocation.lng],
      { icon: markerIcons.driver }
    )
      .addTo(mapRef.current)
      .bindPopup(`Driver: ${driverLocation.name}<br>Last updated: ${new Date(driverLocation.lastUpdated).toLocaleTimeString()}`);
    
    // Update the markers state
    setMarkers(prev => ({
      ...prev,
      driver: newDriverMarker,
    }));

    // Center map on driver if no delivery is selected
    if (!selectedDelivery) {
      mapRef.current.setView([driverLocation.lat, driverLocation.lng], 13);
    }
  }, [driverLocation, markerIcons.driver]);

  // Update delivery markers when delivery locations change
  useEffect(() => {
    if (!mapRef.current) return;
    
    // Remove existing delivery markers
    markers.deliveries.forEach(marker => marker.remove());
    
    // Create new delivery markers
    const newDeliveryMarkers = deliveryLocations.map(delivery => {
      const isSelected = selectedDelivery && selectedDelivery.id === delivery.id;
      const isCompleted = delivery.status === 'completed';
      
      // Choose marker icon based on delivery status
      const icon = isCompleted ? markerIcons.completed : markerIcons.delivery;
      
      // Create marker
      const marker = L.marker([delivery.lat, delivery.lng], { icon })
        .addTo(mapRef.current!)
        .bindPopup(`
          <b>${delivery.address}</b><br>
          Status: ${delivery.status || 'pending'}<br>
          ${delivery.priority ? `Priority: ${delivery.priority}` : ''}
        `);
      
      // Highlight selected delivery
      if (isSelected) {
        marker.openPopup();
      }
      
      return marker;
    });
    
    // Update the markers state
    setMarkers(prev => ({
      ...prev,
      deliveries: newDeliveryMarkers,
    }));
    
    // If there's a selected delivery, center on it
    if (selectedDelivery) {
      mapRef.current.setView([selectedDelivery.lat, selectedDelivery.lng], 14);
    }
    // Otherwise fit bounds to include all markers if we have any
    else if (deliveryLocations.length > 0) {
      const bounds = L.latLngBounds(
        deliveryLocations.map(loc => [loc.lat, loc.lng])
      );
      
      // Add driver location to bounds if available
      if (driverLocation) {
        bounds.extend([driverLocation.lat, driverLocation.lng]);
      }
      
      // Only adjust bounds if we have valid locations
      if (bounds.isValid()) {
        mapRef.current.fitBounds(bounds, { 
          padding: [30, 30],
          maxZoom: 15 
        });
      }
    }
  }, [deliveryLocations, selectedDelivery, markerIcons.delivery, markerIcons.completed]);

  return (
    <Card className="w-full h-[85vh] overflow-hidden">
      <div className="bg-muted px-4 py-2 flex justify-between items-center">
        <h3 className="font-semibold flex items-center">
          <Truck size={18} className="mr-2" /> Live Tracking
        </h3>
        <div className="flex items-center gap-2">
          {isOnline ? (
            <Badge variant="outline" className="bg-green-100 text-green-800 flex items-center gap-1">
              <CheckCircle size={14} /> Online
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-amber-100 text-amber-800 flex items-center gap-1">
              <AlertTriangle size={14} /> Offline
            </Badge>
          )}
        </div>
      </div>
      <CardContent className="p-0 h-full">
        <div className="w-full h-full" ref={mapContainerRef}></div>
      </CardContent>
    </Card>
  );
};

export default LiveTrackingMap;