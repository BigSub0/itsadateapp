import React from "react";
import { Cell, Position } from "@/hooks/useSnakeGame";

interface GameBoardProps {
  board: Cell[][];
  snake: Position[];
  food: Position | null;
  isPaused: boolean;
}

const GameBoard: React.FC<GameBoardProps> = ({ board, snake, food }) => {
  const getCellColor = (cell: Cell, row: number, col: number): string => {
    // Head of the snake
    if (snake.length > 0 && snake[0].row === row && snake[0].col === col) {
      return "bg-green-700";
    }
    
    switch (cell) {
      case "SNAKE":
        return "bg-green-500";
      case "FOOD":
        return "bg-red-500";
      default:
        return "bg-gray-100";
    }
  };

  return (
    <div className="w-full aspect-square max-w-[600px] mx-auto border-2 border-gray-400 rounded-md overflow-hidden select-none">
      <div className="grid grid-cols-20 h-full w-full">
        {board.map((row, rowIndex) => (
          row.map((cell, colIndex) => (
            <div 
              key={`${rowIndex}-${colIndex}`} 
              className={`${getCellColor(cell, rowIndex, colIndex)} border border-gray-200`}
              style={{
                borderRadius: cell === "FOOD" ? "50%" : "",
                transition: "background-color 0.1s ease-in-out",
              }}
            />
          ))
        ))}
      </div>
    </div>
  );
};

export default GameBoard;