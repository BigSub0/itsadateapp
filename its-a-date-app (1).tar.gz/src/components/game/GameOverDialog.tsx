import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface GameOverDialogProps {
  score: number;
  highScore: number;
  onRestart: () => void;
  isOpen: boolean;
}

const GameOverDialog: React.FC<GameOverDialogProps> = ({
  score,
  highScore,
  onRestart,
  isOpen,
}) => {
  // Generate motivational message based on performance
  const getMessage = () => {
    if (score === 0) {
      return "That was quick! Let's try again.";
    } else if (score === highScore && score > 5) {
      return "New high score! Impressive!";
    } else if (score > 10) {
      return "Great job! You're getting good at this.";
    } else if (score > 5) {
      return "Nice try! Keep going, you're improving.";
    } else {
      return "Good effort! Practice makes perfect.";
    }
  };

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Game Over</DialogTitle>
          <DialogDescription className="text-lg">
            {getMessage()}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex justify-center gap-8 py-4">
          <div className="text-center">
            <p className="font-medium text-muted-foreground">Score</p>
            <p className="text-4xl font-bold">{score}</p>
          </div>
          
          <div className="text-center">
            <p className="font-medium text-muted-foreground">Best</p>
            <p className="text-4xl font-bold">{highScore}</p>
          </div>
        </div>
        
        <DialogFooter>
          <Button onClick={onRestart} className="w-full bg-green-600 hover:bg-green-700">
            Play Again
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default GameOverDialog;