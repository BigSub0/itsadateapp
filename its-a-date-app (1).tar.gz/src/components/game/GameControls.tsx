import React from "react";
import { Button } from "@/components/ui/button";
import { Direction } from "@/hooks/useSnakeGame";

interface GameControlsProps {
  onDirectionChange: (direction: Direction) => void;
  direction: Direction;
  isPaused: boolean;
  onPause: () => void;
  onResume: () => void;
}

const GameControls: React.FC<GameControlsProps> = ({ 
  onDirectionChange,
  direction,
  isPaused,
  onPause,
  onResume
}) => {
  return (
    <div className="w-full max-w-[400px] mx-auto">
      {/* Touch controls for mobile devices */}
      <div className="grid grid-cols-3 gap-2 mt-4">
        <div className="col-start-2">
          <Button
            variant="outline"
            size="lg"
            className="w-full aspect-square text-2xl"
            onClick={() => onDirectionChange("UP")}
            disabled={isPaused}
          >
            ↑
          </Button>
        </div>
        
        <div className="col-start-1 col-end-2 row-start-2">
          <Button
            variant="outline"
            size="lg"
            className="w-full aspect-square text-2xl"
            onClick={() => onDirectionChange("LEFT")}
            disabled={isPaused}
          >
            ←
          </Button>
        </div>
        
        <div className="col-start-2 row-start-2">
          <Button
            variant={isPaused ? "default" : "outline"}
            size="lg"
            className="w-full aspect-square text-2xl"
            onClick={isPaused ? onResume : onPause}
          >
            {isPaused ? "▶" : "❙❙"}
          </Button>
        </div>
        
        <div className="col-start-3 row-start-2">
          <Button
            variant="outline"
            size="lg"
            className="w-full aspect-square text-2xl"
            onClick={() => onDirectionChange("RIGHT")}
            disabled={isPaused}
          >
            →
          </Button>
        </div>
        
        <div className="col-start-2 row-start-3">
          <Button
            variant="outline"
            size="lg"
            className="w-full aspect-square text-2xl"
            onClick={() => onDirectionChange("DOWN")}
            disabled={isPaused}
          >
            ↓
          </Button>
        </div>
      </div>
      
      <div className="text-center mt-6 text-sm text-muted-foreground">
        <p>Use arrow keys to move and space bar to pause/resume.</p>
      </div>
    </div>
  );
};

export default GameControls;