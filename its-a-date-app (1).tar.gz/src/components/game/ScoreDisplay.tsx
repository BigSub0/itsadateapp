import React from "react";
import { Card, CardContent } from "@/components/ui/card";

interface ScoreDisplayProps {
  score: number;
  highScore: number;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ score, highScore }) => {
  return (
    <div className="flex space-x-4">
      <Card className="w-32">
        <CardContent className="pt-4">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Score</p>
            <p className="text-3xl font-bold">{score}</p>
          </div>
        </CardContent>
      </Card>
      
      <Card className="w-32">
        <CardContent className="pt-4">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Best</p>
            <p className="text-3xl font-bold">{highScore}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ScoreDisplay;