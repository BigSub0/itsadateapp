import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Heart, MessageSquare, User, Sparkles, 
  Calendar, LogOut, Menu, X, 
  GamepadIcon 
} from 'lucide-react';
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';

export interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
  activeIcon?: React.ReactNode;
}

const DatingNavigation: React.FC = () => {
  const [open, setOpen] = React.useState(false);
  const { logout, isAuthenticated } = useAuth();

  const navItems: NavItem[] = [
    {
      path: '/dating',
      label: 'Home',
      icon: <Heart className="h-5 w-5" />,
      activeIcon: <Heart className="h-5 w-5 fill-pink-500 text-pink-500" />,
    },
    {
      path: '/dating/matches',
      label: 'Matches',
      icon: <Sparkles className="h-5 w-5" />,
      activeIcon: <Sparkles className="h-5 w-5 text-yellow-500" />,
    },
    {
      path: '/dating/messages',
      label: 'Messages',
      icon: <MessageSquare className="h-5 w-5" />,
      activeIcon: <MessageSquare className="h-5 w-5 text-blue-500" />,
    },
    {
      path: '/dating/date-ideas',
      label: 'Date Ideas',
      icon: <Calendar className="h-5 w-5" />,
      activeIcon: <Calendar className="h-5 w-5 text-purple-500" />,
    },
    {
      path: '/dating/profile',
      label: 'Profile',
      icon: <User className="h-5 w-5" />,
      activeIcon: <User className="h-5 w-5 text-green-500" />,
    },
    {
      path: '/games/memory',
      label: 'Games',
      icon: <GamepadIcon className="h-5 w-5" />,
      activeIcon: <GamepadIcon className="h-5 w-5 text-orange-500" />,
    }
  ];

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* Mobile Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border md:hidden">
        <div className="flex items-center justify-around h-16 px-4">
          {navItems.slice(0, 5).map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center flex-1 h-full text-muted-foreground transition-colors",
                  isActive && "text-primary"
                )
              }
            >
              {({ isActive }) => (
                <>
                  {isActive ? item.activeIcon || item.icon : item.icon}
                  <span className="text-xs mt-1">{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
          
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-full flex-1">
                <Menu className="h-5 w-5" />
                <span className="text-xs mt-1">More</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-auto pb-8">
              <div className="flex items-center justify-between pb-4">
                <h2 className="text-lg font-medium">Menu</h2>
                <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <Separator className="my-2" />
              <div className="grid grid-cols-3 gap-4 py-4">
                <NavLink
                  to={navItems[5].path}
                  onClick={() => setOpen(false)}
                  className="flex flex-col items-center gap-2 p-3 rounded-md hover:bg-accent"
                >
                  {navItems[5].icon}
                  <span className="text-sm">{navItems[5].label}</span>
                </NavLink>
                
                <Button
                  variant="ghost"
                  className="flex flex-col items-center h-auto p-3 gap-2 hover:bg-accent"
                  onClick={() => {
                    logout();
                    setOpen(false);
                  }}
                >
                  <LogOut className="h-5 w-5" />
                  <span className="text-sm">Logout</span>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Desktop Navigation */}
      <div className="hidden md:flex flex-col fixed h-screen w-56 border-r border-border p-4">
        <div className="flex items-center gap-2 mb-8">
          <Heart className="h-6 w-6 fill-pink-500 text-pink-500" />
          <h1 className="font-bold text-lg">It's A Date</h1>
        </div>

        <div className="space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-accent transition-colors",
                  isActive && "bg-accent text-primary"
                )
              }
            >
              {({ isActive }) => (
                <>
                  {isActive ? item.activeIcon || item.icon : item.icon}
                  <span>{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>
        
        <div className="mt-auto">
          <Separator className="my-4" />
          <Button
            variant="ghost"
            className="w-full justify-start gap-3"
            onClick={logout}
          >
            <LogOut className="h-5 w-5" />
            Logout
          </Button>
        </div>
      </div>
    </>
  );
};

export default DatingNavigation;