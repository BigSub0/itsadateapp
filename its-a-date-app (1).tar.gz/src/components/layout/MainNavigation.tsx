import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { HomeIcon, ShoppingBagIcon, HeartIcon, UserIcon } from 'lucide-react';

interface MainNavigationProps {
  currentApp?: 'delivery' | 'dating';
}

export default function MainNavigation({ currentApp }: MainNavigationProps) {
  const location = useLocation();
  const isHomePage = location.pathname === '/';
  
  const getLogoColor = () => {
    if (currentApp === 'delivery') return 'text-orange-500';
    if (currentApp === 'dating') return 'text-pink-500';
    return 'text-blue-600';
  };

  const getBackgroundColor = () => {
    if (currentApp === 'delivery') return 'bg-orange-50';
    if (currentApp === 'dating') return 'bg-pink-50';
    return 'bg-white';
  };
  
  return (
    <header className={`border-b ${getBackgroundColor()} sticky top-0 z-10`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link to="/" className={`font-bold text-xl ${getLogoColor()}`}>
            {currentApp ? (
              currentApp === 'delivery' ? 'QuickBite' : 'Connect+'
            ) : (
              'MGX Platform'
            )}
          </Link>
          
          {!isHomePage && (
            <Button asChild variant="outline" size="sm">
              <Link to="/">
                <HomeIcon className="h-4 w-4 mr-2" />
                Back to Home
              </Link>
            </Button>
          )}
        </div>
        
        {currentApp === 'delivery' && (
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/delivery" className="text-orange-900 hover:text-orange-600 transition-colors">Restaurants</Link>
            <Link to="/delivery/orders" className="text-orange-900 hover:text-orange-600 transition-colors">My Orders</Link>
            <Link to="/delivery/favorites" className="text-orange-900 hover:text-orange-600 transition-colors">Favorites</Link>
          </nav>
        )}
        
        {currentApp === 'dating' && (
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/dating" className="text-pink-900 hover:text-pink-600 transition-colors">Discover</Link>
            <Link to="/dating/matches" className="text-pink-900 hover:text-pink-600 transition-colors">Matches</Link>
            <Link to="/dating/messages" className="text-pink-900 hover:text-pink-600 transition-colors">Messages</Link>
            <Link to="/dating/profile" className="text-pink-900 hover:text-pink-600 transition-colors">Profile</Link>
          </nav>
        )}
        
        <div className="flex items-center space-x-4">
          {currentApp && (
            <Button 
              variant="outline"
              size="sm"
              className={currentApp === 'delivery' ? 'text-orange-600' : 'text-pink-600'}
            >
              <UserIcon className="h-4 w-4 mr-2" />
              Sign In
            </Button>
          )}
          
          {currentApp && (
            <Button 
              variant="default" 
              size="sm"
              className={`${currentApp === 'delivery' ? 'bg-orange-500 hover:bg-orange-600' : 'bg-pink-500 hover:bg-pink-600'}`}
            >
              {currentApp === 'delivery' 
                ? <ShoppingBagIcon className="h-4 w-4 mr-2" /> 
                : <HeartIcon className="h-4 w-4 mr-2" />
              }
              {currentApp === 'delivery' ? 'Cart' : 'Likes'}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}