import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  PackageSearch,
  Users,
  TrendingUp,
  Settings,
  Bell,
  Search,
  HelpCircle,
  LogOut,
  User,
  ChevronDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';

const navItems = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
  },
  {
    name: 'Automated System',
    href: '/dashboard/automated',
    icon: <TrendingUp className="h-5 w-5" />,
  },
  {
    name: 'Load Board',
    href: '/dashboard/loadboard',
    icon: <PackageSearch className="h-5 w-5" />,
  },
  {
    name: 'Driver Management',
    href: '/dashboard/drivers',
    icon: <Users className="h-5 w-5" />,
  },
  {
    name: 'Bidding History',
    href: '/dashboard/bids',
    icon: <TrendingUp className="h-5 w-5" />,
  },
  {
    name: 'Settings',
    href: '/dashboard/settings',
    icon: <Settings className="h-5 w-5" />,
  }
];

export default function DashboardNavigation() {
  const location = useLocation();
  
  const isActive = (path: string) => {
    if (path === '/dashboard' && location.pathname === '/dashboard') {
      return true;
    }
    if (path !== '/dashboard' && location.pathname.startsWith(path)) {
      return true;
    }
    return false;
  };

  return (
    <div className="bg-white border-b">
      {/* Top Navigation */}
      <div className="flex h-16 items-center px-4 md:px-6 border-b">
        <div className="flex items-center gap-2 lg:gap-4 w-full">
          {/* Logo */}
          <Link to="/dashboard" className="hidden lg:flex items-center gap-2">
            <div className="bg-blue-600 text-white p-1 rounded">
              <span className="font-bold">VX</span>
            </div>
            <span className="font-bold text-xl">Vital Xpress</span>
          </Link>
          
          {/* Mobile Logo */}
          <Link to="/dashboard" className="lg:hidden">
            <div className="bg-blue-600 text-white p-1 rounded">
              <span className="font-bold">VX</span>
            </div>
          </Link>
          
          {/* Search */}
          <div className="relative w-full max-w-sm hidden md:flex">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search..."
              className="w-full pl-8 bg-white"
            />
          </div>
          
          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-600 font-medium">JD</span>
                  </div>
                  <div className="hidden md:block text-sm font-medium mr-2">
                    John Doe
                  </div>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100">
                    <span className="text-sm font-medium text-blue-600">JD</span>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium">John Doe</p>
                    <p className="text-xs text-muted-foreground">john@vitalxpress.com</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Account</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <HelpCircle className="mr-2 h-4 w-4" />
                  <span>Help</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Horizontal Navigation */}
      <nav className="flex justify-center border-b bg-gray-50 overflow-auto">
        <div className="flex h-12">
          {navItems.map((item, index) => (
            <Link
              key={index}
              to={item.href}
              className={`flex h-full items-center px-4 text-sm font-medium transition-colors hover:text-primary ${
                isActive(item.href)
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                {item.icon}
                <span>{item.name}</span>
              </div>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}