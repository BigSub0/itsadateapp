import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CalendarPlus, CircleDollarSign, MapPin } from 'lucide-react';
import { DateIdea } from '@/lib/dating-local-storage';

interface DateIdeaCardProps {
  dateIdea: DateIdea;
  onSelect?: () => void;
}

export default function DateIdeaCard({ dateIdea, onSelect }: DateIdeaCardProps) {
  // Display cost as $ symbols
  const renderCost = () => {
    return Array(dateIdea.cost).fill('$').join('');
  };

  return (
    <Card className="w-full max-w-md overflow-hidden hover:shadow-md transition-shadow">
      <div className="h-48 w-full overflow-hidden bg-muted">
        {dateIdea.imageUrl ? (
          <img
            src={dateIdea.imageUrl}
            alt={dateIdea.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-pink-100 to-blue-100">
            {dateIdea.title}
          </div>
        )}
      </div>
      
      <CardContent className="pt-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold">{dateIdea.title}</h3>
          <Badge className={`
            ${dateIdea.category === 'Outdoors' && 'bg-green-600'} 
            ${dateIdea.category === 'Food' && 'bg-amber-600'}
            ${dateIdea.category === 'Culture' && 'bg-indigo-600'}
            ${dateIdea.category === 'Entertainment' && 'bg-purple-600'}
          `}>
            {dateIdea.category}
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">{dateIdea.description}</p>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center">
            <CircleDollarSign className="h-4 w-4 mr-1 text-green-600" />
            <span>{renderCost()}</span>
          </div>
          {dateIdea.location && (
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-1 text-slate-500" />
              <span>{dateIdea.location}</span>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="pt-0 pb-4">
        <Button 
          onClick={onSelect} 
          className="w-full bg-pink-600 hover:bg-pink-700"
        >
          <CalendarPlus className="h-4 w-4 mr-2" />
          Plan This Date
        </Button>
      </CardFooter>
    </Card>
  );
}