import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Deal } from '@/lib/dating-api';
import { CalendarIcon, MapPinIcon } from 'lucide-react';
import { toast } from 'sonner';

interface DateSuggestionCardProps {
  deal: Deal;
  delay?: number;
}

export default function DateSuggestionCard({ deal, delay = 0 }: DateSuggestionCardProps) {
  const { title, price, description, imageUrl } = deal;
  
  const handleReserve = () => {
    toast.success(`Date idea "${title}" saved! You would be redirected to booking in a real app.`);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="overflow-hidden h-full flex flex-col">
        <div className="h-48 bg-muted relative">
          {imageUrl ? (
            <img 
              src={imageUrl}
              alt={title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-gradient-to-br from-pink-100 to-purple-100">
              <span className="text-4xl">💕</span>
            </div>
          )}
          <Badge className="absolute top-4 right-4 bg-pink-500">
            ${price.toFixed(2)}
          </Badge>
        </div>
        
        <CardHeader className="pb-2">
          <h3 className="font-semibold text-xl">{title}</h3>
        </CardHeader>
        
        <CardContent className="pb-2 flex-grow">
          <p className="text-muted-foreground text-sm">{description || "No description available"}</p>
          
          <div className="flex items-center gap-4 mt-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <CalendarIcon className="h-3 w-3" />
              <span>Available Today</span>
            </div>
            <div className="flex items-center gap-1">
              <MapPinIcon className="h-3 w-3" />
              <span>Nearby</span>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="pt-2">
          <Button 
            onClick={handleReserve}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
          >
            Reserve This Date
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}