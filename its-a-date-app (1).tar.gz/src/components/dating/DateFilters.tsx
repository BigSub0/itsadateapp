import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { X } from 'lucide-react';

const interestCategories = [
  {
    name: 'Atmosphere',
    options: ['Romantic', 'Casual', 'Upscale', 'Cozy', 'Trendy', 'Quiet']
  },
  {
    name: 'Activity Type',
    options: ['Food', 'Drinks', 'Outdoors', 'Arts', 'Adventure', 'Relaxation', 'Entertainment']
  },
  {
    name: 'Special Features',
    options: ['Live Music', 'Water View', 'Pet Friendly', 'Kid Friendly', 'Late Night', 'Historic']
  }
];

interface DateFiltersProps {
  onFilterChange: (filters: {
    priceRange: string[];
    maxDistance: number;
    selectedTags: string[];
  }) => void;
}

export default function DateFilters({ onFilterChange }: DateFiltersProps) {
  const [priceRange, setPriceRange] = useState<string[]>([]);
  const [maxDistance, setMaxDistance] = useState<number>(20);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Update parent component with filter changes
  useEffect(() => {
    onFilterChange({
      priceRange,
      maxDistance,
      selectedTags
    });
  }, [priceRange, maxDistance, selectedTags, onFilterChange]);

  const handlePriceToggle = (price: string) => {
    setPriceRange(
      priceRange.includes(price)
        ? priceRange.filter(p => p !== price)
        : [...priceRange, price]
    );
  };

  const handleTagToggle = (tag: string) => {
    setSelectedTags(
      selectedTags.includes(tag)
        ? selectedTags.filter(t => t !== tag)
        : [...selectedTags, tag]
    );
  };

  const handleReset = () => {
    setPriceRange([]);
    setMaxDistance(20);
    setSelectedTags([]);
  };

  return (
    <Card className="sticky top-24">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium">Filters</CardTitle>
          {(priceRange.length > 0 || maxDistance < 20 || selectedTags.length > 0) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReset}
              className="h-8 text-xs"
            >
              Reset All
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Selected Tags */}
        {selectedTags.length > 0 && (
          <div>
            <div className="text-sm font-medium mb-2">Selected Filters:</div>
            <div className="flex flex-wrap gap-1">
              {selectedTags.map(tag => (
                <Badge
                  key={tag}
                  variant="secondary"
                  className="pl-2 pr-1 py-0 h-6 text-xs gap-1 flex items-center"
                >
                  {tag}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={(e) => {
                      e.preventDefault();
                      handleTagToggle(tag);
                    }}
                  />
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Price Range */}
        <div>
          <h3 className="text-sm font-medium mb-2">Price Range</h3>
          <div className="grid grid-cols-2 gap-2">
            <div
              className={`flex items-center justify-center px-3 py-1.5 rounded-md border cursor-pointer text-sm ${
                priceRange.includes('$')
                  ? 'bg-pink-50 border-pink-200 text-pink-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => handlePriceToggle('$')}
            >
              $ (Under $25)
            </div>
            <div
              className={`flex items-center justify-center px-3 py-1.5 rounded-md border cursor-pointer text-sm ${
                priceRange.includes('$$')
                  ? 'bg-pink-50 border-pink-200 text-pink-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => handlePriceToggle('$$')}
            >
              $$ ($25-$75)
            </div>
            <div
              className={`flex items-center justify-center px-3 py-1.5 rounded-md border cursor-pointer text-sm ${
                priceRange.includes('$$$')
                  ? 'bg-pink-50 border-pink-200 text-pink-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => handlePriceToggle('$$$')}
            >
              $$$ ($75-$150)
            </div>
            <div
              className={`flex items-center justify-center px-3 py-1.5 rounded-md border cursor-pointer text-sm ${
                priceRange.includes('$$$$')
                  ? 'bg-pink-50 border-pink-200 text-pink-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => handlePriceToggle('$$$$')}
            >
              $$$$ ($150+)
            </div>
          </div>
        </div>

        {/* Distance */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium">Distance</h3>
            <span className="text-sm text-gray-500">{maxDistance} miles</span>
          </div>
          <Slider
            defaultValue={[maxDistance]}
            max={50}
            min={1}
            step={1}
            onValueChange={(values) => setMaxDistance(values[0])}
          />
          <div className="flex justify-between mt-1 text-xs text-gray-500">
            <span>1mi</span>
            <span>25mi</span>
            <span>50mi</span>
          </div>
        </div>

        <Separator />

        {/* Categories Accordion */}
        <Accordion type="multiple" defaultValue={['category-0']} className="w-full">
          {interestCategories.map((category, index) => (
            <AccordionItem key={index} value={`category-${index}`}>
              <AccordionTrigger className="text-sm py-2">
                {category.name}
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-2 gap-2 pt-2">
                  {category.options.map((option, optionIndex) => (
                    <div
                      key={optionIndex}
                      className="flex items-center space-x-2"
                    >
                      <Checkbox
                        id={`${category.name}-${optionIndex}`}
                        checked={selectedTags.includes(option)}
                        onCheckedChange={() => handleTagToggle(option)}
                      />
                      <label
                        htmlFor={`${category.name}-${optionIndex}`}
                        className="text-sm cursor-pointer"
                      >
                        {option}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="pt-2">
          <Button
            className="w-full bg-pink-500 hover:bg-pink-600"
            onClick={() => onFilterChange({ priceRange, maxDistance, selectedTags })}
          >
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}