import React, { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { User, Camera } from 'lucide-react';
import { motion } from 'framer-motion';

interface ImageUploadProps {
  initialImage?: string;
  onImageChange: (imageUrl: string) => void;
}

export default function ImageUpload({ initialImage, onImageChange }: ImageUploadProps) {
  const [previewImage, setPreviewImage] = useState<string | undefined>(initialImage);

  useEffect(() => {
    if (initialImage) {
      setPreviewImage(initialImage);
    }
  }, [initialImage]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, we would upload this file to a server
      // For now, just create a local object URL
      const imageUrl = URL.createObjectURL(file);
      setPreviewImage(imageUrl);
      onImageChange(imageUrl);
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="relative"
      >
        <Avatar className="w-32 h-32 border-2 border-pink-500">
          {previewImage ? (
            <AvatarImage src={previewImage} alt="Profile" className="object-cover" />
          ) : (
            <AvatarFallback className="bg-muted">
              <User className="h-16 w-16 text-muted-foreground" />
            </AvatarFallback>
          )}
        </Avatar>
        <Label
          htmlFor="picture"
          className="absolute bottom-0 right-0 bg-pink-600 text-white p-2 rounded-full cursor-pointer hover:bg-pink-700 transition-colors"
        >
          <Camera className="h-4 w-4" />
        </Label>
      </motion.div>
      <Label htmlFor="picture" className="cursor-pointer text-pink-600 hover:text-pink-700">
        {previewImage ? 'Change profile picture' : 'Upload a profile picture'}
      </Label>
      <Input
        id="picture"
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />
    </div>
  );
}