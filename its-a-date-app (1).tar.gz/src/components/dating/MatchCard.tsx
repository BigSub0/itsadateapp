import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, X, MessageCircle, Star, User } from 'lucide-react';
import { Profile, Match } from '@/lib/dating-local-storage';
import { cn } from '@/lib/utils';

interface MatchCardProps {
  profile: Profile;
  matchScore: number;
  match?: Match;
  onAccept?: (matchId: string) => void;
  onReject?: (matchId: string) => void;
  onMessage?: (userId: string) => void;
  isAccepted?: boolean;
}

export default function MatchCard({
  profile,
  matchScore,
  match,
  onAccept,
  onReject,
  onMessage,
  isAccepted = false
}: MatchCardProps) {
  return (
    <Card className={cn(
      "w-full max-w-md overflow-hidden transition-all duration-300",
      isAccepted ? "border-pink-400 shadow-md" : ""
    )}>
      <div className="relative">
        <div className="h-60 w-full overflow-hidden bg-muted">
          {profile.imageUrl ? (
            <img
              src={profile.imageUrl}
              alt={`${profile.name}'s profile`}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-pink-100 to-purple-100">
              <User className="h-20 w-20 text-muted-foreground opacity-20" />
            </div>
          )}
        </div>
        
        <div className="absolute top-4 right-4">
          <Badge className="bg-pink-600">
            {matchScore}% Match
          </Badge>
        </div>
      </div>
      
      <CardContent className="pt-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xl font-semibold">{profile.name}</h3>
            <p className="text-muted-foreground">
              {profile.age} • {profile.location}
            </p>
          </div>
          <Avatar className="h-10 w-10 border-2 border-pink-500">
            {profile.imageUrl ? (
              <AvatarImage src={profile.imageUrl} alt={profile.name} />
            ) : (
              <AvatarFallback>{profile.name[0]}</AvatarFallback>
            )}
          </Avatar>
        </div>
        
        {profile.bio && (
          <p className="text-sm line-clamp-2 mb-3">{profile.bio}</p>
        )}
        
        {profile.interests && profile.interests.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {profile.interests.slice(0, 4).map((interest, i) => (
              <Badge key={i} variant="outline" className="bg-muted text-xs">
                {interest}
              </Badge>
            ))}
            {profile.interests.length > 4 && (
              <Badge variant="outline" className="bg-muted text-xs">
                +{profile.interests.length - 4} more
              </Badge>
            )}
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between gap-2 pt-0 pb-4">
        {!isAccepted && onAccept && onReject && match && (
          <>
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full w-12 h-12 border-pink-200 hover:border-pink-500 hover:bg-pink-50"
              onClick={() => onReject(match.id)}
            >
              <X className="h-5 w-5 text-slate-500" />
            </Button>
            
            <Button 
              variant="outline"
              size="icon" 
              className="rounded-full w-12 h-12 border-pink-200 hover:border-pink-500 hover:bg-pink-50"
              onClick={() => onAccept(match.id)}
            >
              <Heart className="h-5 w-5 text-pink-500" />
            </Button>
          </>
        )}
        
        {isAccepted && onMessage && (
          <Button 
            className="w-full bg-pink-600 hover:bg-pink-700"
            onClick={() => onMessage(profile.userId)}
          >
            <MessageCircle className="h-5 w-5 mr-2" />
            Message
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}