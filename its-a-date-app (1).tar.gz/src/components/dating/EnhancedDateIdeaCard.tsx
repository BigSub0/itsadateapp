import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DateIdea } from '@/lib/dating-local-storage';
import { Heart, Share2, Calendar, MapPin, DollarSign, Info } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface EnhancedDateIdeaCardProps {
  dateIdea: DateIdea;
  onSelect: (dateIdea: DateIdea) => void;
  isFavorited?: boolean;
  onToggleFavorite?: (dateIdea: DateIdea) => void;
}

export default function EnhancedDateIdeaCard({
  dateIdea,
  onSelect,
  isFavorited = false,
  onToggleFavorite = () => {},
}: EnhancedDateIdeaCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [favorite, setFavorite] = useState(isFavorited);

  // Cost display helper
  const renderCost = (cost: number) => {
    return Array(cost)
      .fill(0)
      .map((_, i) => <DollarSign key={i} className="h-4 w-4 inline" />);
  };

  // Handle favorite toggle with animation
  const handleFavoriteToggle = () => {
    setFavorite(!favorite);
    onToggleFavorite(dateIdea);
  };

  // Share functionality
  const handleShare = () => {
    // In a real app, this would open a share dialog
    if (navigator.share) {
      navigator
        .share({
          title: dateIdea.title,
          text: `Check out this date idea: ${dateIdea.title}`,
          url: window.location.href,
        })
        .catch((error) => console.log('Error sharing', error));
    } else {
      // Fallback for browsers that don't support the Web Share API
      alert(`In a real app, you would be able to share "${dateIdea.title}" with others.`);
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        whileHover={{ y: -5, transition: { duration: 0.2 } }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
      >
        <Card className="h-full overflow-hidden border-2 hover:border-pink-300 transition-all duration-300 shadow-sm hover:shadow-md">
          <div className="relative overflow-hidden" style={{ height: '180px' }}>
            {dateIdea.imageUrl && (
              <img
                src={dateIdea.imageUrl}
                alt={dateIdea.title}
                className="w-full h-full object-cover transition-transform duration-300"
                style={{
                  transform: isHovered ? 'scale(1.05)' : 'scale(1)',
                }}
              />
            )}
            
            {!dateIdea.imageUrl && (
              <div 
                className="w-full h-full flex items-center justify-center bg-gradient-to-br from-pink-100 to-purple-100"
              >
                <Calendar className="h-16 w-16 text-pink-300" />
              </div>
            )}
            
            <div className="absolute top-2 right-2 flex gap-2">
              <motion.button
                whileTap={{ scale: 1.4 }}
                className={`p-2 rounded-full backdrop-blur-md ${
                  favorite ? 'bg-pink-500 text-white' : 'bg-white/60 text-pink-500'
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  handleFavoriteToggle();
                }}
              >
                <Heart className={`h-4 w-4 ${favorite ? 'fill-current' : ''}`} />
              </motion.button>
            </div>
            
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
              <Badge className="bg-pink-500 hover:bg-pink-600">
                {dateIdea.category}
              </Badge>
            </div>
          </div>

          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-bold line-clamp-1">{dateIdea.title}</h3>
              <div className="flex items-center text-muted-foreground">
                {renderCost(dateIdea.cost)}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pb-2">
            <p className="text-muted-foreground text-sm line-clamp-2">{dateIdea.description}</p>
            
            <div className="mt-2 flex items-center text-xs text-muted-foreground">
              <MapPin className="h-3 w-3 mr-1" />
              <span>{dateIdea.location}</span>
            </div>
          </CardContent>
          
          <CardFooter className="pt-2 flex justify-between">
            <Button
              size="sm"
              onClick={() => onSelect(dateIdea)}
              className="bg-pink-500 hover:bg-pink-600"
            >
              Plan This Date
            </Button>
            
            <TooltipProvider>
              <div className="flex gap-1">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={() => setShowDetails(true)}
                    >
                      <Info className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>View details</TooltipContent>
                </Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShare();
                      }}
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Share this idea</TooltipContent>
                </Tooltip>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                        <circle cx="12" cy="12" r="1" />
                        <circle cx="19" cy="12" r="1" />
                        <circle cx="5" cy="12" r="1" />
                      </svg>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setShowDetails(true)}>
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleFavoriteToggle}>
                      {favorite ? 'Remove from Favorites' : 'Add to Favorites'}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleShare}>
                      Share
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </TooltipProvider>
          </CardFooter>
        </Card>
      </motion.div>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{dateIdea.title}</DialogTitle>
            <div className="flex items-center mt-1 space-x-2">
              <Badge className="bg-pink-500 hover:bg-pink-600">
                {dateIdea.category}
              </Badge>
              <span className="text-muted-foreground">
                {renderCost(dateIdea.cost)}
              </span>
            </div>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            {dateIdea.imageUrl && (
              <img
                src={dateIdea.imageUrl}
                alt={dateIdea.title}
                className="w-full h-64 object-cover rounded-md"
              />
            )}
            
            <div>
              <h4 className="font-semibold mb-1">Description</h4>
              <p className="text-muted-foreground">{dateIdea.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-1">Location</h4>
                <p className="text-muted-foreground flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {dateIdea.location}
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold mb-1">Best Time</h4>
                <p className="text-muted-foreground flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {dateIdea.bestTime || "Anytime"}
                </p>
              </div>
            </div>
            
            {dateIdea.tips && (
              <div>
                <h4 className="font-semibold mb-1">Tips</h4>
                <ul className="list-disc ml-5 text-muted-foreground space-y-1">
                  {dateIdea.tips.map((tip, i) => (
                    <li key={i}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setShowDetails(false)}
            >
              Close
            </Button>
            <Button
              className="bg-pink-500 hover:bg-pink-600"
              onClick={() => {
                onSelect(dateIdea);
                setShowDetails(false);
              }}
            >
              Plan This Date
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}