import React, { useRef, useEffect } from 'react';
import { Message } from '@/contexts/MessagesContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion } from 'framer-motion';

interface MessageListProps {
  messages: Message[];
  loading: boolean;
  currentUserId: string;
}

export default function MessageList({ messages, loading, currentUserId }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="animate-pulse flex space-x-2 items-center">
          <div className="h-3 w-3 bg-pink-400 rounded-full animate-bounce"></div>
          <div className="h-3 w-3 bg-pink-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
          <div className="h-3 w-3 bg-pink-600 rounded-full animate-bounce [animation-delay:0.4s]"></div>
          <span className="text-muted-foreground ml-2">Loading messages...</span>
        </div>
      </div>
    );
  }

  return (
    <ScrollArea className="flex-1 p-4">
      {messages.length === 0 ? (
        <div className="flex items-center justify-center h-full text-muted-foreground">
          No messages yet. Start the conversation!
        </div>
      ) : (
        <div className="space-y-4">
          {messages.map((message, index) => {
            const isMine = message.senderId === currentUserId;
            
            return (
              <motion.div 
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    isMine 
                      ? 'bg-pink-600 text-white rounded-br-none' 
                      : 'bg-muted rounded-bl-none'
                  }`}
                >
                  <p>{message.content}</p>
                  <div className={`text-xs mt-1 ${isMine ? 'text-pink-200' : 'text-muted-foreground'}`}>
                    {new Date(message.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                    {isMine && (
                      <span className="ml-1">
                        {message.read ? '• Read' : '• Sent'}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      )}
    </ScrollArea>
  );
}