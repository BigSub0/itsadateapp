import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { surveyService, surveyQuestions } from '@/lib/dating-local-storage';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function SurveyQuestions() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const totalQuestions = surveyQuestions.length;
  const currentQuestion = surveyQuestions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;
  
  const handleAnswer = (answer: string) => {
    setAnswers({
      ...answers,
      [currentQuestion.id]: answer,
    });
  };
  
  const handleNext = async () => {
    if (!user) {
      navigate('/dating/auth');
      return;
    }
    
    // Save the current answer
    if (answers[currentQuestion.id]) {
      surveyService.saveAnswer(
        user.id,
        currentQuestion.id,
        answers[currentQuestion.id]
      );
    }
    
    if (isLastQuestion) {
      setIsSubmitting(true);
      try {
        // Find matches based on survey answers
        await surveyService.findMatches(user.id);
        navigate('/dating/matches');
      } finally {
        setIsSubmitting(false);
      }
    } else {
      // Move to next question
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };
  
  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  // Load existing answers for the user
  React.useEffect(() => {
    if (user) {
      const userAnswers = surveyService.getUserAnswers(user.id);
      const answersMap: Record<number, string> = {};
      
      userAnswers.forEach(a => {
        answersMap[a.questionId] = a.answer;
      });
      
      setAnswers(answersMap);
    }
  }, [user]);
  
  if (!currentQuestion) {
    return null;
  }
  
  return (
    <Card className="w-full max-w-xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl text-center">Compatibility Survey</CardTitle>
        <CardDescription className="text-center">
          Answer a few questions to find your perfect match
        </CardDescription>
        <Progress value={progress} className="h-2 mt-4" />
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="text-xl font-medium">
            {currentQuestion.question}
          </div>
          
          <RadioGroup 
            value={answers[currentQuestion.id] || ''} 
            onValueChange={handleAnswer}
            className="space-y-3"
          >
            {currentQuestion.options.map((option, index) => (
              <div 
                key={index} 
                className={cn(
                  "flex items-center space-x-2 rounded-lg border p-4 cursor-pointer transition-all",
                  answers[currentQuestion.id] === option 
                    ? "border-pink-500 bg-pink-50" 
                    : "hover:border-muted-foreground"
                )}
                onClick={() => handleAnswer(option)}
              >
                <RadioGroupItem 
                  value={option} 
                  id={`option-${index}`} 
                  className="text-pink-600"
                />
                <Label htmlFor={`option-${index}`} className="flex-grow cursor-pointer">
                  {option}
                </Label>
                {answers[currentQuestion.id] === option && (
                  <CheckCircle2 className="h-5 w-5 text-pink-600" />
                )}
              </div>
            ))}
          </RadioGroup>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={currentQuestionIndex === 0}
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        
        <Button
          onClick={handleNext}
          className="bg-pink-600 hover:bg-pink-700"
          disabled={!answers[currentQuestion.id] || isSubmitting}
        >
          {isLastQuestion ? (
            isSubmitting ? 'Finding matches...' : 'Find matches'
          ) : (
            <>
              Next
              <ChevronRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}