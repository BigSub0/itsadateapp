import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Heart, X, MessageCircle } from 'lucide-react';

type ProfileCardProps = {
  profile: {
    id: string;
    name: string;
    bio: string;
    location: string;
    distance: string;
    interests: string[];
    photoUrl: string;
    match: number;
  };
  isMatch?: boolean;
};

export default function ProfileCard({ profile, isMatch = false }: ProfileCardProps) {
  // Default profile image if the provided URL is not valid
  const defaultImage = "/assets/images/profile-placeholder.jpg";
  
  return (
    <Card className="overflow-hidden transition-all hover:shadow-lg">
      <div className="relative">
        {/* Profile Image */}
        <div className="aspect-[3/4] w-full overflow-hidden">
          <img
            src={profile.photoUrl || defaultImage}
            alt={profile.name}
            className="h-full w-full object-cover transition-transform hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = defaultImage;
            }}
          />
        </div>

        {/* Match Percentage Badge */}
        {profile.match > 0 && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-pink-500 text-white font-medium">
              {profile.match}% Match
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{profile.name}</h3>
          <div className="flex items-center gap-1 text-sm text-gray-500">
            <span>{profile.distance}</span>
          </div>
        </div>

        <p className="mb-4 text-sm text-gray-600 line-clamp-3">{profile.bio}</p>

        <div className="flex flex-wrap gap-1.5">
          {profile.interests.slice(0, 4).map((interest, index) => (
            <Badge key={index} variant="outline" className="bg-gray-50">
              {interest}
            </Badge>
          ))}
          {profile.interests.length > 4 && (
            <Badge variant="outline" className="bg-gray-50">
              +{profile.interests.length - 4} more
            </Badge>
          )}
        </div>
      </CardContent>

      <CardFooter className="flex justify-between p-3 border-t">
        {isMatch ? (
          <Button className="w-full flex items-center justify-center gap-2 bg-pink-500 hover:bg-pink-600">
            <MessageCircle className="h-4 w-4" />
            Message
          </Button>
        ) : (
          <>
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full border-gray-200 hover:bg-gray-100 hover:text-gray-900"
            >
              <X className="h-5 w-5" />
            </Button>
            <Button 
              size="icon" 
              className="rounded-full bg-pink-500 hover:bg-pink-600"
            >
              <Heart className="h-5 w-5" />
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  );
}