import React, { useEffect } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useProfile } from '@/contexts/ProfileContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Profile } from '@/lib/dating-local-storage';
import ImageUpload from '@/components/dating/ImageUpload';
import { motion } from 'framer-motion';
import { fadeInUp } from '@/lib/transitions';

const profileSchema = z.object({
  name: z.string().min(2, {
    message: 'Name must be at least 2 characters.',
  }),
  age: z.preprocess(
    (a) => parseInt(z.string().parse(a), 10),
    z.number().min(18, { message: 'You must be at least 18 years old.' }).max(120)
  ),
  gender: z.string().min(1, { message: 'Please select your gender.' }),
  interestedIn: z.array(z.string()).min(1, { message: 'Please select at least one gender you are interested in.' }),
  bio: z.string().max(500, { message: 'Bio must not exceed 500 characters.' }),
  location: z.string().min(1, { message: 'Please enter your location.' }),
  interests: z.array(z.string()),
  imageUrl: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

const availableInterests = [
  'Music', 'Movies', 'Reading', 'Travel', 'Sports', 'Cooking', 'Art', 
  'Photography', 'Gaming', 'Fitness', 'Nature', 'Technology', 'Dancing'
];

export default function ProfileForm() {
  const { profile, updateProfile, loading, error } = useProfile();
  const navigate = useNavigate();
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: '',
      age: 18,
      gender: '',
      interestedIn: [],
      bio: '',
      location: '',
      interests: [],
      imageUrl: '',
    },
  });

  useEffect(() => {
    if (profile) {
      form.reset({
        name: profile.name,
        age: profile.age || 18,
        gender: profile.gender || '',
        interestedIn: profile.interestedIn || [],
        bio: profile.bio || '',
        location: profile.location || '',
        interests: profile.interests || [],
        imageUrl: profile.imageUrl || '',
      });
    }
  }, [profile, form]);

  const onSubmit = async (values: ProfileFormValues) => {
    // Extract only the fields we want to update
    const updatedProfile: Partial<Profile> = {
      name: values.name,
      age: values.age,
      gender: values.gender,
      interestedIn: values.interestedIn,
      bio: values.bio,
      location: values.location,
      interests: values.interests,
      imageUrl: values.imageUrl || profile?.imageUrl || '',
      completed: true,
    };

    const success = await updateProfile(updatedProfile);
    if (success) {
      navigate('/dating/survey');
    }
  };

  const handleImageChange = (imageUrl: string) => {
    form.setValue('imageUrl', imageUrl);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl text-center">Complete Your Profile</CardTitle>
        <CardDescription className="text-center">
          Tell us about yourself to find better matches
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <motion.div 
              variants={fadeInUp}
              initial="hidden"
              animate="visible"
              className="flex flex-col items-center space-y-4 mb-6"
            >
              <ImageUpload 
                initialImage={profile?.imageUrl} 
                onImageChange={handleImageChange} 
              />
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age</FormLabel>
                    <FormControl>
                      <Input type="number" min={18} placeholder="Your age" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="gender"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gender</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your gender" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Male">Male</SelectItem>
                        <SelectItem value="Female">Female</SelectItem>
                        <SelectItem value="Non-binary">Non-binary</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="Your city/town" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="interestedIn"
              render={() => (
                <FormItem>
                  <div className="mb-2">
                    <FormLabel>Interested In</FormLabel>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {['Male', 'Female', 'Non-binary'].map((option) => (
                      <FormField
                        key={option}
                        control={form.control}
                        name="interestedIn"
                        render={({ field }) => {
                          return (
                            <FormItem key={option} className="flex flex-row items-center space-x-2">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(option)}
                                  onCheckedChange={(checked) => {
                                    const updatedValue = checked
                                      ? [...field.value, option]
                                      : field.value?.filter(
                                          (value) => value !== option
                                        );
                                    field.onChange(updatedValue);
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="cursor-pointer">{option}</FormLabel>
                            </FormItem>
                          );
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>About Me</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Tell potential matches about yourself..."
                      className="resize-none"
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="interests"
              render={() => (
                <FormItem>
                  <div className="mb-2">
                    <FormLabel>Interests</FormLabel>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {availableInterests.map((interest) => (
                      <FormField
                        key={interest}
                        control={form.control}
                        name="interests"
                        render={({ field }) => {
                          return (
                            <FormItem key={interest} className="flex items-center space-x-2 bg-muted rounded-full px-3 py-1">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(interest)}
                                  onCheckedChange={(checked) => {
                                    const updatedValue = checked
                                      ? [...field.value, interest]
                                      : field.value?.filter(
                                          (value) => value !== interest
                                        );
                                    field.onChange(updatedValue);
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="cursor-pointer text-sm">{interest}</FormLabel>
                            </FormItem>
                          );
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full bg-pink-600 hover:bg-pink-700"
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save Profile & Continue'}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="text-sm text-muted-foreground text-center">
        <p className="w-full">
          This information will be used to find your matches. You can edit your profile anytime.
        </p>
      </CardFooter>
    </Card>
  );
}