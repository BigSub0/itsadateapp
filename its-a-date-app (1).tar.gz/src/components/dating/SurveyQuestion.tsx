import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { SurveyQuestion as SurveyQuestionType } from '@/lib/dating-api';

interface SurveyQuestionProps {
  question: SurveyQuestionType;
  onAnswer: (questionId: string, answer: string) => void;
  selectedAnswer?: string;
}

export default function SurveyQuestion({ question, onAnswer, selectedAnswer }: SurveyQuestionProps) {
  const [localSelection, setLocalSelection] = useState<string | undefined>(selectedAnswer);
  
  const handleChange = (value: string) => {
    setLocalSelection(value);
    onAnswer(question.id, value);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      <h3 className="text-xl font-medium text-center mb-6">{question.text}</h3>
      
      <RadioGroup
        value={localSelection}
        onValueChange={handleChange}
        className="space-y-3"
      >
        {question.options.map((option, index) => (
          <motion.div
            key={option}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
            className="flex items-center"
          >
            <div className="flex items-center space-x-3 w-full rounded-lg border p-4 cursor-pointer hover:bg-muted transition-colors duration-150">
              <RadioGroupItem value={option.toLowerCase()} id={`option-${option}`} className="border-pink-500" />
              <Label htmlFor={`option-${option}`} className="flex-1 cursor-pointer">
                {option}
              </Label>
            </div>
          </motion.div>
        ))}
      </RadioGroup>
    </motion.div>
  );
}