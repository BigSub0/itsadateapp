import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Add meta tag for PWA display
const metaViewport = document.createElement('meta');
metaViewport.name = 'viewport';
metaViewport.content = 'width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=no';
document.head.appendChild(metaViewport);

// Add Web App Manifest
const manifestLink = document.createElement('link');
manifestLink.rel = 'manifest';
manifestLink.href = '/manifest.json';
document.head.appendChild(manifestLink);

// Add Apple touch icon for iOS devices
const appleIcon = document.createElement('link');
appleIcon.rel = 'apple-touch-icon';
appleIcon.href = '/assets/icons/icon-192x192.png';
document.head.appendChild(appleIcon);

// Add theme-color meta for PWA
const themeColor = document.createElement('meta');
themeColor.name = 'theme-color';
themeColor.content = '#ff3880';
document.head.appendChild(themeColor);

// Add Apple mobile web app capable meta tag
const appleMobileWebAppCapable = document.createElement('meta');
appleMobileWebAppCapable.name = 'apple-mobile-web-app-capable';
appleMobileWebAppCapable.content = 'yes';
document.head.appendChild(appleMobileWebAppCapable);

// Add Apple mobile web app status bar style meta tag
const appleMobileWebAppStatusBarStyle = document.createElement('meta');
appleMobileWebAppStatusBarStyle.name = 'apple-mobile-web-app-status-bar-style';
appleMobileWebAppStatusBarStyle.content = 'black-translucent';
document.head.appendChild(appleMobileWebAppStatusBarStyle);

// Add single Apple touch startup image instead of multiple sizes
const appleTouchStartupImage = document.createElement('link');
appleTouchStartupImage.rel = 'apple-touch-startup-image';
appleTouchStartupImage.href = '/assets/icons/icon-512x512.png';
document.head.appendChild(appleTouchStartupImage);

// Set page title
document.title = "It's A Date";

createRoot(document.getElementById('root')!).render(<App />);

// Register service worker for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('Service Worker registered with scope:', registration.scope);
      })
      .catch(error => {
        console.error('Service Worker registration failed:', error);
      });
  });
}

// Add user prompt to install the PWA
let deferredPrompt: Event | null = null;

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent Chrome from automatically showing the prompt
  e.preventDefault();
  // Stash the event so it can be triggered later
  deferredPrompt = e;
  
  // Show install button or notification after user has used the app
  setTimeout(() => {
    if (deferredPrompt && !localStorage.getItem('pwaInstalled')) {
      // This would normally show a custom UI element to prompt installation
      console.log('PWA can be installed! Showing install prompt...');
    }
  }, 60000); // Show after 1 minute of app usage
});

window.addEventListener('appinstalled', () => {
  // App has been installed
  localStorage.setItem('pwaInstalled', 'true');
  deferredPrompt = null;
});

// Add iOS specific PWA install check
const isIOS = () => {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as Window & typeof globalThis & { MSStream?: unknown }).MSStream;
};

const isInStandaloneMode = () => {
  return ('standalone' in window.navigator) && ((window.navigator as Navigator & { standalone?: boolean }).standalone);
};

// Check if app is being used in standalone mode (installed PWA)
if (isIOS() && isInStandaloneMode()) {
  localStorage.setItem('pwaInstalled', 'true');
}