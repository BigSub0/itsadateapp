import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Index from './pages/Index';
import NotFound from './pages/NotFound';
import MemoryGame from './pages/games/MemoryGame';
import { HelmetProvider } from 'react-helmet-async';
import IOSInstallPrompt from './components/mobile/IOSInstallPrompt';
import { AuthProvider } from './contexts/AuthContext';
import { ProfileProvider } from './contexts/ProfileContext';
import { MatchingProvider } from './contexts/MatchingContext';
import { MessagesProvider } from './contexts/MessagesContext';
import { AnimatePresence } from 'framer-motion';
import InstallPwaPrompt from './components/mobile/InstallPwaPrompt';

// Dating App Pages
import DatingHome from './pages/dating/Home';
import Auth from './pages/dating/Auth';
import Profile from './pages/dating/Profile';
import Survey from './pages/dating/Survey';
import Matches from './pages/dating/Matches';
import DateIdeas from './pages/dating/DateIdeas';
import Messages from './pages/dating/Messages';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <ProfileProvider>
          <MatchingProvider>
            <MessagesProvider>
              <Toaster />
              <InstallPwaPrompt />
              <IOSInstallPrompt />
              <BrowserRouter>
                <AnimatePresence mode="wait">
                  <Routes>
                <Route path="/" element={<Index />} />
                
                {/* Dating App Routes */}
                <Route path="/dating" element={<DatingHome />} />
                <Route path="/dating/auth" element={<Auth />} />
                <Route path="/dating/profile" element={<Profile />} />
                <Route path="/dating/survey" element={<Survey />} />
                <Route path="/dating/matches" element={<Matches />} />
                <Route path="/dating/date-ideas" element={<DateIdeas />} />
                <Route path="/dating/messages" element={<Messages />} />
                
                {/* Games */}
                <Route path="/games/memory" element={<HelmetProvider><MemoryGame /></HelmetProvider>} />
                
                <Route path="*" element={<NotFound />} />
              </Routes>
                </AnimatePresence>
              </BrowserRouter>
            </MessagesProvider>
          </MatchingProvider>
        </ProfileProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;