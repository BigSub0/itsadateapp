// CACHE_NAME is the key under which we'll save our cache
const CACHE_NAME = 'its-a-date-cache-v1';

// List of URLs to cache immediately when the service worker is installed
const STATIC_CACHE_URLS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/assets/icons/icon-192x192.png',
  '/assets/icons/icon-512x512.png'
];

// URLs that contain these strings will use cache-first strategy
const CACHE_FIRST_URLS = [
  '/assets/',
  '.png',
  '.jpg',
  '.jpeg',
  '.svg',
  '.gif',
  '.webp',
  '.css',
  '.js'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      
      // Special handling for iOS Safari - pre-cache with no-cors for cross-origin assets
      const iOSUserAgent = /iPad|iPhone|iPod/.test(navigator.userAgent);
      
      for (const url of STATIC_CACHE_URLS) {
        try {
          // Use no-cors mode for external assets on iOS
          const options = iOSUserAgent && url.includes('http') ? 
            { mode: 'no-cors' } : undefined;
          
          await cache.add(new Request(url, options));
        } catch (error) {
          console.error(`Failed to cache: ${url}`, error);
        }
      }
      
      // Immediately activate this service worker
      self.skipWaiting();
    })()
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
      
      // Take control of all pages immediately
      await self.clients.claim();
    })()
  );
});

// Helper function to determine which caching strategy to use
const shouldUseCacheFirst = (url) => {
  return CACHE_FIRST_URLS.some(cacheUrl => url.includes(cacheUrl));
};

// Fetch event - handle requests with appropriate strategies
self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin) && 
      !/fonts.(googleapis|gstatic).com/.test(event.request.url)) {
    return;
  }
  
  // Handle only GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  const url = new URL(event.request.url);
  
  // Special handling for navigation requests (HTML)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          // Try network first for navigation requests
          const networkResponse = await fetch(event.request);
          const cache = await caches.open(CACHE_NAME);
          cache.put(event.request, networkResponse.clone());
          return networkResponse;
        } catch (error) {
          // If offline, try to get from cache
          const cachedResponse = await caches.match(event.request);
          if (cachedResponse) {
            return cachedResponse;
          }
          
          // If not in cache, return the offline page
          return caches.match('/offline.html');
        }
      })()
    );
    return;
  }

  // For assets, use cache-first strategy
  if (shouldUseCacheFirst(url.pathname)) {
    event.respondWith(
      (async () => {
        const cachedResponse = await caches.match(event.request);
        
        if (cachedResponse) {
          // Return cached response immediately
          return cachedResponse;
        }
        
        // If not in cache, fetch from network
        try {
          const networkResponse = await fetch(event.request);
          
          // Cache the response for future use if it's a successful response
          if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(event.request, networkResponse.clone());
          }
          
          return networkResponse;
        } catch (error) {
          // For image requests that fail, you could return a placeholder image
          if (url.pathname.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
            return caches.match('/assets/icons/placeholder.png');
          }
          
          // For other failed requests, just throw the error
          throw error;
        }
      })()
    );
  } else {
    // For API requests or other dynamic content, use network-first strategy
    event.respondWith(
      (async () => {
        try {
          // Try to get from network first
          const networkResponse = await fetch(event.request);
          
          // Save a copy in cache
          const cache = await caches.open(CACHE_NAME);
          cache.put(event.request, networkResponse.clone());
          
          return networkResponse;
        } catch (error) {
          // If network fails, try cache
          const cachedResponse = await caches.match(event.request);
          if (cachedResponse) {
            return cachedResponse;
          }
          
          // If not in cache either, throw error
          throw error;
        }
      })()
    );
  }
});

// Handle push notifications (for future implementation)
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    
    const options = {
      body: data.body || 'New notification',
      icon: '/assets/icons/icon-192x192.png',
      badge: '/assets/icons/notification-badge.png',
      vibrate: [100, 50, 100],
      data: {
        url: data.url || '/'
      }
    };
    
    event.waitUntil(
      self.registration.showNotification(data.title || "It's A Date", options)
    );
  }
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  if (event.notification.data && event.notification.data.url) {
    event.waitUntil(
      clients.openWindow(event.notification.data.url)
    );
  }
});

// Special handling for iOS offline detection
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  // For iOS specific offline detection
  if (event.data && event.data.type === 'CHECK_ONLINE_STATUS') {
    fetch('/ping')
      .then(() => {
        event.ports[0].postMessage({ online: true });
      })
      .catch(() => {
        event.ports[0].postMessage({ online: false });
      });
  }
});