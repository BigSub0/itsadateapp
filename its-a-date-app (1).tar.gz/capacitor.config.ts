import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.itsadate.app',
  appName: 'Its A Date',
  webDir: 'dist'
};

export default config;
